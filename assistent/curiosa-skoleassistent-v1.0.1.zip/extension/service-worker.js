// Curiosa Skoleassistent - Service Worker (Manifest V3)

// 1. Enable Side Panel opening on action icon click
chrome.sidePanel
  .setPanelBehavior({ openPanelOnActionClick: true })
  .catch((error) => console.error('[CURIOSA-SW] setPanelBehavior error:', error));

// 2. Setup Context Menus on install/startup
chrome.runtime.onInstalled.addListener(() => {
  setupContextMenus();
});

function setupContextMenus() {
  chrome.contextMenus.removeAll(() => {
    // Teacher Menu 1: Generate Tasks from page or selection
    chrome.contextMenus.create({
      id: 'curiosa_generate_tasks',
      title: 'Lag Curiosa-oppgaver fra denne siden',
      contexts: ['page', 'selection', 'link']
    });

    // Teacher Menu 2: Send PDF/Article to Fagstoff
    chrome.contextMenus.create({
      id: 'curiosa_send_fagstoff',
      title: 'Legg til som Fagstoff i Curiosa',
      contexts: ['page', 'selection', 'link']
    });

    // Student / General: Open Companion
    chrome.contextMenus.create({
      id: 'curiosa_open_companion',
      title: 'Apne Curiosa Laringsassistent',
      contexts: ['all']
    });
  });
}

// 3. Handle Context Menu Clicks
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  // Open side panel in current window safely
  try {
    let targetWindowId = tab?.windowId;
    if (!targetWindowId || targetWindowId === -1) {
      const currentWin = await chrome.windows.getCurrent();
      targetWindowId = currentWin?.id;
    }
    if (targetWindowId && targetWindowId !== -1) {
      await chrome.sidePanel.open({ windowId: targetWindowId });
    }
  } catch (err) {
    console.error('[CURIOSA-SW] Could not open side panel:', err);
  }

  // Pass context data to Side Panel
  setTimeout(() => {
    chrome.runtime.sendMessage({
      type: 'CONTEXT_MENU_CLICKED',
      menuItemId: info.menuItemId,
      selectionText: info.selectionText || '',
      pageUrl: info.pageUrl || tab.url || '',
      tabTitle: tab.title || '',
      tabId: tab.id
    }).catch(() => {
      // Side panel might still be initializing, which is normal
    });
  }, 400);
});

// 4. Default Whitelisted Domains during Kiosk / Exam Mode
const DEFAULT_EXAM_WHITELIST = [
  'curiosa.no',
  'voxkunnskapeuropa.web.app',
  'localhost',
  'feide.no',
  '*.feide.no',
  'dataporten.no',
  '*.dataporten.no',
  'ordbokene.no',
  '*.ordbokene.no',
  'snl.no',
  '*.snl.no',
  'lingit.no',
  '*.lingit.no',
  'lingdys.no',
  '*.lingdys.no',
  'texthelp.com',
  '*.texthelp.com'
];

// 5. Manage Kiosk / Test Focus Rules via DeclarativeNetRequest
async function enableExamFocusMode(customWhitelist = []) {
  const allowedDomains = Array.from(new Set([...DEFAULT_EXAM_WHITELIST, ...(customWhitelist || [])]));
  
  console.log('[CURIOSA-SW] Enabling Exam Focus Mode with whitelist:', allowedDomains);

  // Declarative Net Request: Block all external navigation except whitelisted domains
  const blockRule = {
    id: 1001,
    priority: 1,
    action: {
      type: 'block'
    },
    condition: {
      urlFilter: '|http*',
      resourceTypes: ['main_frame', 'sub_frame', 'websocket'],
      excludedInitiatorDomains: allowedDomains,
      excludedRequestDomains: allowedDomains
    }
  };

  try {
    await chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: [1001],
      addRules: [blockRule]
    });

    // Notify user
    chrome.notifications.create('curiosa_exam_active', {
      type: 'basic',
      iconUrl: 'icons/icon-128.png',
      title: 'Prøvemodus aktivert',
      message: 'Nettleseren er nå låst til Curiosa og godkjente hjelpemidler.',
      priority: 2
    });

    // Save state
    await chrome.storage.local.set({ isExamFocusActive: true, examWhitelist: allowedDomains });
  } catch (err) {
    console.error('[CURIOSA-SW] Failed to enable exam mode:', err);
  }
}

async function disableExamFocusMode() {
  console.log('[CURIOSA-SW] Disabling Exam Focus Mode');
  try {
    await chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: [1001]
    });
    await chrome.storage.local.set({ isExamFocusActive: false });
    chrome.notifications.clear('curiosa_exam_active');
  } catch (err) {
    console.error('[CURIOSA-SW] Failed to disable exam mode:', err);
  }
}

// 6. Message Listener (from content scripts & webapp)
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || !message.type) {
    return false;
  }

  if (message.type === 'AUTH_STATE_SYNC') {
    const { user, role, school, classes, topics, hasReadWriteSupport } = message.payload || {};
    chrome.storage.local.set({
      curiosaAuth: {
        isLoggedIn: !!user,
        user: user || null,
        role: role || (user?.email ? 'teacher' : 'student'),
        school: school || null,
        classes: classes || [],
        topics: topics || [],
        hasReadWriteSupport: !!hasReadWriteSupport,
        lastSyncedAt: Date.now()
      }
    }).then(() => {
      sendResponse({ status: 'ok' });
    }).catch((e) => {
      sendResponse({ status: 'error', message: e.message });
    });
    return true;
  }

  if (message.type === 'START_EXAM_FOCUS') {
    enableExamFocusMode(message.whitelist || []).then(() => {
      sendResponse({ status: 'ok', active: true });
    }).catch((e) => {
      sendResponse({ status: 'error', message: e.message });
    });
    return true;
  }

  if (message.type === 'STOP_EXAM_FOCUS') {
    disableExamFocusMode().then(() => {
      sendResponse({ status: 'ok', active: false });
    }).catch((e) => {
      sendResponse({ status: 'error', message: e.message });
    });
    return true;
  }

  if (message.type === 'GET_ACTIVE_TAB_CONTENT') {
    chrome.tabs.query({ active: true, currentWindow: true }).then(([activeTab]) => {
      if (!activeTab || !activeTab.id) {
        sendResponse({ success: false, error: 'No active tab' });
        return;
      }
      chrome.scripting.executeScript({
        target: { tabId: activeTab.id },
        func: () => {
          try {
            const selection = window.getSelection()?.toString()?.trim();
            const title = document.title || '';
            const metaDesc = document.querySelector('meta[name="description"]')?.content || '';
            
            const clone = document.body.cloneNode(true);
            const elementsToRemove = clone.querySelectorAll('script, style, noscript, nav, footer, header, svg, iframe, form');
            elementsToRemove.forEach(el => el.remove());
            const cleanText = clone.innerText?.replace(/\s+/g, ' ')?.trim() || '';

            const images = [];
            const imgElements = document.querySelectorAll('article img, main img, .article img, [role="main"] img, img');
            imgElements.forEach(img => {
              const src = img.src || img.currentSrc;
              if (src && !src.startsWith('data:') && (img.naturalWidth > 180 || img.width > 180 || !img.width)) {
                if (!images.some(existing => existing.src === src) && images.length < 5) {
                  images.push({
                    src: src,
                    alt: img.alt || 'Artikkelbilde'
                  });
                }
              }
            });

            return {
              title,
              url: window.location.href,
              selection,
              metaDesc,
              images,
              text: selection || cleanText.slice(0, 30000)
            };
          } catch (e) {
            return {
              title: document.title || '',
              url: window.location.href,
              selection: '',
              metaDesc: '',
              images: [],
              text: document.body.innerText?.slice(0, 30000) || ''
            };
          }
        }
      }).then((results) => {
        if (results && results[0]?.result) {
          sendResponse({ success: true, data: results[0].result });
        } else {
          sendResponse({ success: false, error: 'Could not extract text' });
        }
      }).catch(err => {
        sendResponse({ success: false, error: err.message });
      });
    }).catch(err => {
      sendResponse({ success: false, error: err.message });
    });
    return true;
  }

  return false;
});
