// Curiosa Skoleassistent - Service Worker (Manifest V3)

// 1. Enable Side Panel opening on action icon click
chrome.sidePanel
  .setPanelBehavior({ openPanelOnActionClick: true })
  .catch((error) => console.error('[CURIOSA-SW] setPanelBehavior error:', error));

// 2. Setup Context Menus on install/startup
chrome.runtime.onInstalled.addListener(() => {
  setupContextMenus();
});

function setupContextMenus() {
  chrome.contextMenus.removeAll(() => {
    // Teacher Menu 1: Generate Tasks from page or selection
    chrome.contextMenus.create({
      id: 'curiosa_generate_tasks',
      title: 'Lag Curiosa-oppgaver fra denne siden',
      contexts: ['page', 'selection', 'link']
    });

    // Teacher Menu 2: Send PDF/Article to Fagstoff
    chrome.contextMenus.create({
      id: 'curiosa_send_fagstoff',
      title: 'Legg til som Fagstoff i Curiosa',
      contexts: ['page', 'selection', 'link']
    });

    // Student / General: Open Companion
    chrome.contextMenus.create({
      id: 'curiosa_open_companion',
      title: 'Apne Curiosa Laringsassistent',
      contexts: ['all']
    });
  });
}

// 3. Handle Context Menu Clicks
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  // Open side panel in current window safely
  try {
    let targetWindowId = tab?.windowId;
    if (!targetWindowId || targetWindowId === -1) {
      const currentWin = await chrome.windows.getCurrent();
      targetWindowId = currentWin?.id;
    }
    if (targetWindowId && targetWindowId !== -1) {
      await chrome.sidePanel.open({ windowId: targetWindowId });
    }
  } catch (err) {
    console.error('[CURIOSA-SW] Could not open side panel:', err);
  }

  // Pass context data to Side Panel
  setTimeout(() => {
    chrome.runtime.sendMessage({
      type: 'CONTEXT_MENU_CLICKED',
      menuItemId: info.menuItemId,
      selectionText: info.selectionText || '',
      pageUrl: info.pageUrl || tab.url || '',
      tabTitle: tab.title || '',
      tabId: tab.id
    }).catch(() => {
      // Side panel might still be initializing, which is normal
    });
  }, 400);
});

// 4. Default Whitelisted Domains during Kiosk / Exam Mode
const DEFAULT_EXAM_WHITELIST = [
  'curiosa.no',
  'voxkunnskapeuropa.web.app',
  'localhost',
  'feide.no',
  '*.feide.no',
  'dataporten.no',
  '*.dataporten.no',
  'ordbokene.no',
  '*.ordbokene.no',
  'snl.no',
  '*.snl.no',
  'lingit.no',
  '*.lingit.no',
  'lingdys.no',
  '*.lingdys.no',
  'texthelp.com',
  '*.texthelp.com'
];

// 5. Manage Kiosk / Test Focus Rules via DeclarativeNetRequest
async function enableExamFocusMode(customWhitelist = []) {
  const allowedDomains = Array.from(new Set([...DEFAULT_EXAM_WHITELIST, ...(customWhitelist || [])]));
  
  console.log('[CURIOSA-SW] Enabling Exam Focus Mode with whitelist:', allowedDomains);

  // Declarative Net Request: Block all external navigation except whitelisted domains
  const blockRule = {
    id: 1001,
    priority: 1,
    action: {
      type: 'block'
    },
    condition: {
      urlFilter: '|http*',
      resourceTypes: ['main_frame', 'sub_frame', 'websocket'],
      excludedInitiatorDomains: allowedDomains,
      excludedRequestDomains: allowedDomains
    }
  };

  try {
    await chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: [1001],
      addRules: [blockRule]
    });

    // Notify user
    chrome.notifications.create('curiosa_exam_active', {
      type: 'basic',
      iconUrl: 'icons/icon-128.png',
      title: 'Prøvemodus aktivert',
      message: 'Nettleseren er nå låst til Curiosa og godkjente hjelpemidler.',
      priority: 2
    });

    // Save state
    await chrome.storage.local.set({ isExamFocusActive: true, examWhitelist: allowedDomains });
  } catch (err) {
    console.error('[CURIOSA-SW] Failed to enable exam mode:', err);
  }
}

async function disableExamFocusMode() {
  console.log('[CURIOSA-SW] Disabling Exam Focus Mode');
  try {
    await chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: [1001]
    });
    await chrome.storage.local.set({ isExamFocusActive: false });
    chrome.notifications.clear('curiosa_exam_active');
  } catch (err) {
    console.error('[CURIOSA-SW] Failed to disable exam mode:', err);
  }
}

// 6. Message Listener (from content scripts & webapp)
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || !message.type) {
    return false;
  }

  if (message.type === 'AUTH_STATE_SYNC') {
    const { user, role, school, classes, topics, hasReadWriteSupport } = message.payload || {};
    chrome.storage.local.set({
      curiosaAuth: {
        isLoggedIn: !!user,
        user: user || null,
        role: role || (user?.email ? 'teacher' : 'student'),
        school: school || null,
        classes: classes || [],
        topics: topics || [],
        hasReadWriteSupport: !!hasReadWriteSupport,
        lastSyncedAt: Date.now()
      }
    }).then(() => {
      sendResponse({ status: 'ok' });
    }).catch((e) => {
      sendResponse({ status: 'error', message: e.message });
    });
    return true;
  }

  if (message.type === 'START_EXAM_FOCUS') {
    enableExamFocusMode(message.whitelist || []).then(() => {
      sendResponse({ status: 'ok', active: true });
    }).catch((e) => {
      sendResponse({ status: 'error', message: e.message });
    });
    return true;
  }

  if (message.type === 'STOP_EXAM_FOCUS') {
    disableExamFocusMode().then(() => {
      sendResponse({ status: 'ok', active: false });
    }).catch((e) => {
      sendResponse({ status: 'error', message: e.message });
    });
    return true;
  }

  if (message.type === 'GET_ACTIVE_TAB_CONTENT') {
    chrome.tabs.query({ active: true, currentWindow: true }).then(([activeTab]) => {
      if (!activeTab || !activeTab.id) {
        sendResponse({ success: false, error: 'No active tab' });
        return;
      }
      chrome.scripting.executeScript({
        target: { tabId: activeTab.id },
        func: () => {
          try {
            const selection = window.getSelection()?.toString()?.trim();
            const rawTitle = (document.querySelector('h1')?.innerText || document.title || '')
              .replace(/\s*-\s*Wikipedia.*$/i, '')
              .replace(/\s*-\s*NRK.*$/i, '')
              .replace(/\s*\|\s*.*$/i, '')
              .trim();
            const metaDesc = document.querySelector('meta[name="description"]')?.content || '';

            // Find primary content container
            const containerCandidates = [
              '.mw-parser-output',
              'article',
              'main',
              '[role="main"]',
              '#main-content',
              '.article-body',
              '.article-content',
              '#article-body',
              '.story-body',
              '.post-content',
              '.entry-content'
            ];
            let mainEl = null;
            for (const sel of containerCandidates) {
              const el = document.querySelector(sel);
              if (el && el.innerText && el.innerText.length > 200) {
                mainEl = el;
                break;
              }
            }
            if (!mainEl) mainEl = document.body;

            // Extract high-quality images from main content
            const images = [];
            const imgElements = mainEl.querySelectorAll('figure img, .thumbimage, img');
            imgElements.forEach(img => {
              const src = img.currentSrc || img.src;
              if (src && !src.startsWith('data:') && !src.includes('/static/images/') && !src.includes('badge') && !src.includes('icon')) {
                const w = img.naturalWidth || img.width || 0;
                const h = img.naturalHeight || img.height || 0;
                if ((w >= 160 && h >= 120) || (!w && !src.endsWith('.svg'))) {
                  if (!images.some(existing => existing.src === src) && images.length < 5) {
                    const caption = img.closest('figure')?.querySelector('figcaption')?.innerText?.trim() 
                      || img.closest('.thumb')?.querySelector('.thumbcaption')?.innerText?.trim()
                      || img.alt 
                      || '';
                    images.push({
                      src: src,
                      alt: caption.replace(/\[\d+\]/g, '').trim()
                    });
                  }
                }
              }
            });

            // Clone and clean DOM
            const clone = mainEl.cloneNode(true);
            const noiseSelectors = [
              'script', 'style', 'noscript', 'nav', 'footer', 'header', 'svg', 'iframe', 'form', 'button',
              'table', '.sidebar', '.vertical-navbox', '.navbox', '.seriesbox', '.series', '.portal',
              '.infobox', '.infobox-v2', '.ambox', '.metadata', '.vector-toc', '.mw-editsection',
              '.mw-jump-link', '.noprint', '.reflist', '.reference', '.citation', 'aside', '.advertisement',
              '.ad', '.social-share', '.cookie-banner', '.site-header', '.site-footer', '.mw-empty-elt',
              '#toc', '.toc', '.vector-page-toolbar', '.mw-indicators', '.IPA', '.IPA-label', '.phonetic',
              '.pronunciation', '.audiolink', '.catlinks', '[role="navigation"]'
            ];
            clone.querySelectorAll(noiseSelectors.join(', ')).forEach(el => el.remove());

            // Helper to sanitize phonetic / broken Unicode characters for clean reading
            const cleanString = (str) => {
              if (!str) return '';
              return str
                .replace(/\(\s*\/[^/)]+\/\s*[,;]?\s*(\/[^/)]+\/)?\s*;/g, '(')
                .replace(/\(\s*\/[^)]+\/\s*\)/g, '')
                .replace(/\/[\u0250-\u02AF\u1D00-\u1D7F\u02B0-\u02FFˈˌːˑ˘. ]+\//g, '')
                .replace(/\[\s*(edit|\d+|[a-z])\s*\]/gi, '')
                .replace(/[\u0370-\u03FF\u1F00-\u1FFF]/g, '') // remove raw Greek symbols that corrupt standard PDF fonts
                .replace(/[\u0000-\u001F\u007F-\u009F]/g, '')
                .replace(/[“”]/g, '"')
                .replace(/[‘’`]/g, "'")
                .replace(/[–—]/g, '-')
                .replace(/\(\s*[,;:]+\s*/g, '(')
                .replace(/\s*[,;:]+\s*\)/g, ')')
                .replace(/\(\s*\)/g, '')
                .replace(/[^\S\r\n]+/g, ' ') // Preserve newlines!
                .trim();
            };

            // Extract sequential paragraphs and headings
            const structuredSections = [];
            const blocks = clone.querySelectorAll('h2, h3, h4, p, blockquote, ul, ol');
            let reachedEndSection = false;
            
            if (blocks && blocks.length > 0) {
              for (const block of blocks) {
                if (reachedEndSection) break;

                // Don't extract from nested tables or sidebars that might have slipped through
                if (block.closest('table, .sidebar, .navbox, [role="navigation"]')) {
                  continue;
                }

                const tag = block.tagName.toLowerCase();
                let text = cleanString(block.innerText || '');
                if (!text) continue;

                // Detect bibliography, notes, references, or external links sections to STOP extraction
                if (tag.startsWith('h')) {
                  if (/^(notes|references|further reading|bibliography|external links|see also|sources|footnotes|citations|noter|referanser|litteratur|kilder|se også|bakgrunnsstoff|relatert)/i.test(text)) {
                    reachedEndSection = true;
                    break;
                  }
                  structuredSections.push(`## ${text}`);
                  continue;
                }
                
                // Skip citation lines, notes, and category items
                if (/^(jump to|coordinates:|see also|references|external links|further reading|kilder|se også|noter|notes|litteratur)/i.test(text)) {
                  continue;
                }
                if (/^(cite|cs1 maint|doi:|isbn|issn|jstor|pmid|s2cid|bibcode|oclc)/i.test(text)) {
                  continue;
                }
                if (/^(articles with|short description|hidden categories|categories:|kategori:)/i.test(text)) {
                  continue;
                }

                if (tag === 'p') {
                  if (text.length > 25) {
                    structuredSections.push(text);
                  }
                } else if (tag === 'ul' || tag === 'ol') {
                  const items = Array.from(block.querySelectorAll('li'))
                    .map(li => cleanString(li.innerText || ''))
                    .filter(t => t.length > 15 && !/^(cite|cs1|doi:|isbn|jstor|articles with|short description)/i.test(t))
                    .map(t => `• ${t}`);
                  if (items.length > 0 && items.length <= 10) {
                    structuredSections.push(items.join('\n'));
                  }
                }
              }
            }

            const cleanText = structuredSections.length > 0 
              ? structuredSections.join('\n\n')
              : cleanString(clone.innerText || '');

            return {
              title: cleanString(rawTitle),
              url: window.location.href,
              selection: cleanString(selection),
              metaDesc: cleanString(metaDesc),
              images,
              text: selection ? cleanString(selection) : cleanText.slice(0, 30000)
            };
          } catch (e) {
            return {
              title: document.title || '',
              url: window.location.href,
              selection: '',
              metaDesc: '',
              images: [],
              text: document.body.innerText?.slice(0, 30000) || ''
            };
          }
        }
      }).then((results) => {
        if (results && results[0]?.result) {
          sendResponse({ success: true, data: results[0].result });
        } else {
          sendResponse({ success: false, error: 'Could not extract text' });
        }
      }).catch(err => {
        sendResponse({ success: false, error: err.message });
      });
    }).catch(err => {
      sendResponse({ success: false, error: err.message });
    });
    return true;
  }

  return false;
});
