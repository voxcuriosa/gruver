// Curiosa Skoleassistent - Side Panel Controller

document.addEventListener('DOMContentLoaded', async () => {
  // State
  let currentRole = 'guest'; // 'teacher' | 'student' | 'guest'
  let currentUser = null;
  let activeTabContent = null;
  let generatedTasks = null;
  let selectedClasses = new Set();
  let allTeacherTopics = [];

  // Elements
  const userStatusText = document.getElementById('user-status-text');
  const roleBadge = document.getElementById('role-badge');
  const navTabs = document.getElementById('nav-tabs');
  const sourceTextPreview = document.getElementById('source-text-preview');
  const topicTitleInput = document.getElementById('topic-title');
  const fagstoffTitleInput = document.getElementById('fagstoff-title');
  const fagstoffTopicSearch = document.getElementById('fagstoff-topic-search');
  const fagstoffTargetTopic = document.getElementById('fagstoff-target-topic');
  const btnGenerateTasks = document.getElementById('btn-generate-tasks');
  const btnPublishTopic = document.getElementById('btn-publish-topic');
  const btnRefreshText = document.getElementById('btn-refresh-text');
  const btnSaveFagstoff = document.getElementById('btn-save-fagstoff');
  const generatedTasksContainer = document.getElementById('generated-tasks-container');
  const generatedTasksList = document.getElementById('generated-tasks-list');
  const taskSummaryBadge = document.getElementById('task-summary-badge');
  const classesSelector = document.getElementById('classes-selector');
  const customClassInput = document.getElementById('custom-class-input');
  const chatMessages = document.getElementById('chat-messages');
  const chatInput = document.getElementById('chat-input');
  const btnChatSend = document.getElementById('btn-chat-send');

  // Wire up Steppers (+ / -)
  document.querySelectorAll('.btn-stepper').forEach(btn => {
    btn.addEventListener('click', () => {
      const targetId = btn.getAttribute('data-target');
      const action = btn.getAttribute('data-action');
      const input = document.getElementById(targetId);
      if (!input) return;

      let val = parseInt(input.value, 10) || 0;
      const min = parseInt(input.min, 10) || 0;
      const max = parseInt(input.max, 10) || 20;

      if (action === 'inc' && val < max) {
        input.value = val + 1;
      } else if (action === 'dec' && val > min) {
        input.value = val - 1;
      }
    });
  });

  function formatTeacherName(rawName) {
    if (!rawName || rawName === 'Curiosa Lærerassistent' || rawName === 'Innlogget lærer' || rawName === 'Curiosa Laererassistent') {
      return 'Curiosa Lærerassistent';
    }
    
    const parts = rawName.split('•').map(p => p.trim());
    let fullName = parts[0];
    let school = parts[1] || '';

    let firstName = fullName.split(' ')[0] || '';
    if (firstName) {
      firstName = firstName.charAt(0).toUpperCase() + firstName.slice(1).toLowerCase();
    }

    if (school) {
      const formattedSchool = school
        .toLowerCase()
        .split(' ')
        .map(w => w === 'vgs' ? 'vgs' : (w.charAt(0).toUpperCase() + w.slice(1)))
        .join(' ');
      return `${firstName} • ${formattedSchool}`;
    }

    return firstName || 'Lærer';
  }

  // Strict Norwegian class validator (allows 1B, 2A, 3MOKA, 3PBYA, 3PBYB, LATIN; rejects PINs and student names)
  function isValidClassCode(str) {
    if (!str || typeof str !== 'string') return false;
    const clean = str.trim().toUpperCase();
    return (/^[1-3][A-ZÆØÅ]{1,5}$/.test(clean) || clean === 'LATIN');
  }

  // Render dynamic and filtered topic options
  function renderFilteredTopics() {
    if (!fagstoffTargetTopic) return;
    
    const selectedFagstoffClasses = Array.from(document.querySelectorAll('#fagstoff-classes-selector .class-pill.selected')).map(p => p.textContent.trim().toUpperCase());
    const searchQuery = (fagstoffTopicSearch?.value || '').trim().toLowerCase();

    const previousSelectedValue = fagstoffTargetTopic.value;
    fagstoffTargetTopic.innerHTML = '<option value="__NEW_TOPIC__">+ Opprett som ny øving i Curiosa</option>';

    let filtered = (allTeacherTopics || []).filter(t => t && t.title && !t.title.includes('Generer ny PIN') && !t.title.includes('Last ned rapport') && !t.title.includes('Slett'));

    // Filter 1: If classes are selected, only show topics available to those classes
    if (selectedFagstoffClasses.length > 0) {
      filtered = filtered.filter(topic => {
        if (!topic.classes || topic.classes.length === 0) return true; // Available to all classes
        return topic.classes.some(c => selectedFagstoffClasses.includes(c.toUpperCase()));
      });
    }

    // Filter 2: Dynamic search query
    if (searchQuery) {
      filtered = filtered.filter(topic => {
        const titleMatch = (topic.title || '').toLowerCase().includes(searchQuery);
        const subjectMatch = (topic.subject || '').toLowerCase().includes(searchQuery);
        return titleMatch || subjectMatch;
      });
    }

    filtered.forEach(topic => {
      const opt = document.createElement('option');
      opt.value = topic.id;
      const cleanTitle = (topic.title || '').replace(/^\[(øving|test|fagstoff)\]\s*/i, '').trim();
      const typeBadge = topic.isPractice ? '[Øving]' : '[Test]';
      const classBadge = topic.classes && topic.classes.length > 0 ? ` (${topic.classes.join(', ')})` : ' (Alle)';
      opt.textContent = `${typeBadge} ${cleanTitle}${classBadge}`;
      if (topic.id === previousSelectedValue) {
        opt.selected = true;
      }
      fagstoffTargetTopic.appendChild(opt);
    });

    updateFagstoffPreviewTarget();
    updateClassesLabel();
  }

  function updateFagstoffPreviewTarget() {
    const previewTarget = document.getElementById('pdf-preview-target');
    const newTopicSettings = document.getElementById('fagstoff-new-topic-settings');
    if (!previewTarget || !fagstoffTargetTopic) return;
    const val = fagstoffTargetTopic.value;
    const isNewTopic = !val || val === '__NEW_TOPIC__';
    const selectedClasses = Array.from(document.querySelectorAll('#fagstoff-classes-selector .class-pill.selected')).map(p => p.textContent.trim().toUpperCase());
    const classInfo = selectedClasses.length > 0 ? ` for klasse(r) ${selectedClasses.join(', ')}` : ' for alle klasser';

    if (newTopicSettings) {
      newTopicSettings.style.display = isNewTopic ? 'flex' : 'none';
    }

    if (isNewTopic) {
      const mode = document.getElementById('fagstoff-mode')?.value || 'practice';
      const subj = document.getElementById('fagstoff-subject')?.value || '#generelt';
      const typeLabel = mode === 'practice' ? 'ny øving' : 'ny formell test';
      previewTarget.textContent = `Mottaker: Opprettes som ${typeLabel} (${subj.replace('#', '')})${classInfo}`;
    } else {
      const topicText = fagstoffTargetTopic.options[fagstoffTargetTopic.selectedIndex]?.text || '';
      previewTarget.textContent = `Tilknyttes: ${topicText}`;
    }
  }

  function updateClassesLabel() {
    const classesLabel = document.getElementById('fagstoff-classes-label');
    const classesHint = document.getElementById('fagstoff-classes-hint');
    if (!classesLabel || !classesHint) return;

    const selectedVal = fagstoffTargetTopic?.value;
    const isNewTopic = !selectedVal || selectedVal === '__NEW_TOPIC__';

    if (isNewTopic) {
      const mode = document.getElementById('fagstoff-mode')?.value || 'practice';
      const typeLabel = mode === 'practice' ? 'øvingen' : 'testen';
      classesLabel.textContent = 'Tildel til klasser';
      classesHint.textContent = `Velg hvilke klasser som skal ha tilgang til denne ${typeLabel} (eller la stå tomt for alle).`;
    } else {
      const selectedTopicName = fagstoffTargetTopic.options[fagstoffTargetTopic.selectedIndex]?.text || '';
      classesLabel.textContent = 'Klassetilgang (arvet fra tema)';
      classesHint.textContent = `Dokumentet legges inn under Fagstoff i "${selectedTopicName}" og er tilgjengelig for klassene som har dette temaet.`;
    }
  }

  // Dynamic Search & Select listeners
  fagstoffTopicSearch?.addEventListener('input', renderFilteredTopics);
  fagstoffTargetTopic?.addEventListener('change', () => {
    updateFagstoffPreviewTarget();
    updateClassesLabel();
  });
  document.getElementById('fagstoff-subject')?.addEventListener('change', updateFagstoffPreviewTarget);
  document.getElementById('fagstoff-mode')?.addEventListener('change', () => {
    updateFagstoffPreviewTarget();
    updateClassesLabel();
  });

  // 1. Multi-Layered Auth & Pure Teacher Classes Sync
  async function initAuth() {
    // Default immediately to teacher view so tabs are never hidden
    currentRole = 'teacher';
    renderTabsForRole('teacher');
    userStatusText.textContent = 'Curiosa Lærerassistent';
    roleBadge.className = 'role-badge role-teacher';
    roleBadge.textContent = 'Lærer';

    // Step A: Load cached storage if exists
    chrome.storage.local.get(['curiosaAuth'], (data) => {
      const auth = data?.curiosaAuth;
      if (auth && auth.user) {
        currentUser = auth.user;
        currentRole = auth.role || 'teacher';
        
        const teacherLabel = formatTeacherName(currentUser.name || currentUser.displayName || currentUser.email);
        userStatusText.textContent = teacherLabel;
        roleBadge.className = `role-badge ${currentRole === 'teacher' ? 'role-teacher' : 'role-student'}`;
        roleBadge.textContent = currentRole === 'teacher' ? 'Lærer' : 'Elev';

        renderTabsForRole(currentRole);
        const filteredCached = (auth.classes || []).filter(isValidClassCode);
        if (filteredCached.length > 0) {
          populateClasses(filteredCached);
        }
        if (auth.topics && Array.isArray(auth.topics)) {
          allTeacherTopics = auth.topics;
          renderFilteredTopics();
        }
      }
    });

    // Step B: Direct inspection of all open tabs to find Curiosa
    try {
      chrome.tabs.query({}, async (tabs) => {
        for (const t of tabs) {
          if (!t.id) continue;
          const url = t.url || '';
          if (url.includes('curiosa.no') || url.includes('voxkunnskapeuropa') || url.includes('localhost') || url.includes('127.0.0.1')) {
            try {
              const [res] = await chrome.scripting.executeScript({
                target: { tabId: t.id },
                func: () => {
                  let rawTeacherName = '';
                  const spans = Array.from(document.querySelectorAll('span, div, header, p'));
                  for (const el of spans) {
                    const txt = el.textContent?.trim() || '';
                    if (txt.includes('•') && (txt.includes('VGS') || txt.includes('vgs') || txt.includes('Skole') || txt.includes('SKOLE') || txt.length < 60)) {
                      if (!txt.includes('Curiosa') && !txt.includes('–')) {
                        rawTeacherName = txt;
                        break;
                      }
                    }
                  }

                  const foundClasses = new Set();

                  function checkClass(str) {
                    if (!str || typeof str !== 'string') return false;
                    const clean = str.trim().toUpperCase();
                    return (/^[1-3][A-ZÆØÅ]{1,5}$/.test(clean) || clean === 'LATIN');
                  }

                  // 1. Check localStorage for classes
                  try {
                    const stored = JSON.parse(localStorage.getItem('voks_teacher_classes') || '[]');
                    if (Array.isArray(stored)) {
                      stored.forEach(c => {
                        if (checkClass(c)) foundClasses.add(c.toUpperCase());
                      });
                    }
                  } catch(e) {}

                  // 2. Specific class elements in table (p.text-brand-400)
                  document.querySelectorAll('p.text-brand-400, .text-brand-400').forEach(el => {
                    const txt = el.textContent?.trim().toUpperCase();
                    if (checkClass(txt)) {
                      foundClasses.add(txt);
                    }
                  });

                  // 3. Topics strictly from localStorage
                  let topics = [];
                  try {
                    const rawTopics = localStorage.getItem('voks_teacher_topics');
                    if (rawTopics) {
                      const parsed = JSON.parse(rawTopics);
                      if (Array.isArray(parsed)) {
                        topics = parsed.filter(t => t && t.title && !t.title.includes('Generer ny PIN') && !t.title.includes('Last ned rapport') && !t.title.includes('Slett'));
                      }
                    }
                  } catch(e) {}

                  return {
                    teacherName: rawTeacherName || localStorage.getItem('voks_teacher_name') || '',
                    classes: Array.from(foundClasses).sort(),
                    topics: topics
                  };
                }
              });

              if (res && res.result) {
                const data = res.result;
                if (data.teacherName) {
                  userStatusText.textContent = formatTeacherName(data.teacherName);
                }
                currentRole = 'teacher';
                roleBadge.className = 'role-badge role-teacher';
                roleBadge.textContent = 'Lærer';
                renderTabsForRole('teacher');

                const pureClasses = (data.classes || []).filter(isValidClassCode);
                if (pureClasses.length > 0) {
                  populateClasses(pureClasses);
                }

                if (data.topics && Array.isArray(data.topics)) {
                  allTeacherTopics = data.topics;
                  renderFilteredTopics();
                }

                chrome.storage.local.set({
                  curiosaAuth: {
                    isLoggedIn: true,
                    role: 'teacher',
                    user: { name: data.teacherName },
                    classes: pureClasses,
                    topics: data.topics || []
                  }
                });
              }
            } catch(err) {
              console.warn('[CURIOSA-SP] tab script error:', err);
            }
          }
        }
      });
    } catch (e) {
      console.warn('[CURIOSA-SP] Tab query failed:', e);
    }
  }

  // Step C: Listen for live updates from webapp content script
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'AUTH_STATE_SYNC' && msg.payload) {
      const { user, role, classes, topics } = msg.payload;
      const rawLabel = user?.name || user?.displayName || user?.email || '';
      if (rawLabel) {
        userStatusText.textContent = formatTeacherName(rawLabel);
      }
      currentRole = role || 'teacher';
      roleBadge.className = `role-badge ${currentRole === 'teacher' ? 'role-teacher' : 'role-student'}`;
      roleBadge.textContent = currentRole === 'teacher' ? 'Lærer' : 'Elev';
      renderTabsForRole(currentRole);
      
      const pureClasses = (classes || []).filter(isValidClassCode);
      if (pureClasses.length > 0) {
        populateClasses(pureClasses);
      }

      if (topics && Array.isArray(topics)) {
        allTeacherTopics = topics;
        renderFilteredTopics();
      }
    }
  });

  // 2. Render Navigation Tabs
  function renderTabsForRole(role) {
    navTabs.innerHTML = '';
    if (role === 'teacher') {
      navTabs.innerHTML = `
        <button class="tab-btn active" data-target="tab-generator">Oppgavegenerator</button>
        <button class="tab-btn" data-target="tab-fagstoff">Fagstoff / PDF</button>
      `;
    } else if (role === 'student') {
      navTabs.innerHTML = `
        <button class="tab-btn active" data-target="tab-companion">Læringsassistent</button>
      `;
    } else {
      navTabs.innerHTML = `
        <button class="tab-btn active" data-target="tab-login">Logg inn</button>
      `;
    }

    // Attach tab listeners
    navTabs.querySelectorAll('.tab-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        navTabs.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
        
        btn.classList.add('active');
        const targetId = btn.getAttribute('data-target');
        const targetPane = document.getElementById(targetId);
        if (targetPane) targetPane.classList.add('active');
      });
    });
  }

  // 3. Populate Classes Selectors
  function populateClasses(classesList) {
    classesSelector.innerHTML = '';
    const fagstoffSelector = document.getElementById('fagstoff-classes-selector');
    if (fagstoffSelector) fagstoffSelector.innerHTML = '';

    const pureList = (classesList || []).filter(isValidClassCode);

    if (!pureList || pureList.length === 0) {
      classesSelector.innerHTML = '<span class="muted-text">Ingen klasser funnet. Åpne Curiosa for å hente klassene dine.</span>';
      if (fagstoffSelector) fagstoffSelector.innerHTML = '<span class="muted-text">Ingen klasser funnet. Åpne Curiosa for å hente klassene dine.</span>';
      return;
    }

    pureList.forEach(cls => {
      // 1. Task Generator tab
      const pill = document.createElement('span');
      pill.className = 'class-pill';
      pill.textContent = cls;
      pill.addEventListener('click', () => {
        if (selectedClasses.has(cls)) {
          selectedClasses.delete(cls);
          pill.classList.remove('selected');
        } else {
          selectedClasses.add(cls);
          pill.classList.add('selected');
        }
      });
      classesSelector.appendChild(pill);

      // 2. Fagstoff tab
      if (fagstoffSelector) {
        const fagPill = document.createElement('span');
        fagPill.className = 'class-pill';
        fagPill.textContent = cls;
        fagPill.addEventListener('click', () => {
          fagPill.classList.toggle('selected');
          // Update topic list when a class pill is toggled
          renderFilteredTopics();
        });
        fagstoffSelector.appendChild(fagPill);
      }
    });

    renderFilteredTopics();
  }

  // Add custom class manually
  if (customClassInput) {
    customClassInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && customClassInput.value.trim()) {
        const newClass = customClassInput.value.trim().toUpperCase();
        selectedClasses.add(newClass);
        
        const pill = document.createElement('span');
        pill.className = 'class-pill selected';
        pill.textContent = newClass;
        pill.addEventListener('click', () => {
          if (selectedClasses.has(newClass)) {
            selectedClasses.delete(newClass);
            pill.classList.remove('selected');
          } else {
            selectedClasses.add(newClass);
            pill.classList.add('selected');
          }
        });
        classesSelector.appendChild(pill);
        customClassInput.value = '';
      }
    });
  }

  // 4. Fetch Active Tab Content & Listen for Page Navigation
  let lastLoadedUrl = '';

  async function fetchCurrentPageContent() {
    chrome.runtime.sendMessage({ type: 'GET_ACTIVE_TAB_CONTENT' }, (response) => {
      if (response && response.success && response.data) {
        const isNewUrl = response.data.url !== lastLoadedUrl;
        activeTabContent = response.data;
        lastLoadedUrl = response.data.url || '';

        sourceTextPreview.value = activeTabContent.text || '';
        
        // If it is a new page/article or title was empty, update title fields automatically
        if (isNewUrl || !topicTitleInput.value) {
          const cleanTitle = activeTabContent.title?.split(' - ')[0]?.split(' | ')[0] || '';
          topicTitleInput.value = cleanTitle;
        }
        if (isNewUrl || !fagstoffTitleInput.value) {
          const cleanTitle = activeTabContent.title?.split(' - ')[0]?.split(' | ')[0] || 'Fagstoff';
          fagstoffTitleInput.value = `${cleanTitle}.pdf`;
        }

        // Reset previous PDF cache if user navigated to a different article
        if (isNewUrl) {
          currentGeneratedPdfBlob = null;
          currentGeneratedPdfBase64 = null;
          currentGeneratedPages = 1;
        }
      } else {
        sourceTextPreview.value = 'Kunne ikke hente tekst automatisk. Du kan lime inn tekst manuelt her.';
      }
    });
  }

  btnRefreshText?.addEventListener('click', fetchCurrentPageContent);

  // Auto-update when user changes page, clicks link, or switches tabs in Chrome
  chrome.tabs?.onActivated?.addListener(() => {
    fetchCurrentPageContent();
  });

  chrome.tabs?.onUpdated?.addListener((tabId, changeInfo, tab) => {
    if (tab?.active && (changeInfo.status === 'complete' || changeInfo.url)) {
      fetchCurrentPageContent();
    }
  });

  chrome.windows?.onFocusChanged?.addListener(() => {
    fetchCurrentPageContent();
  });

  // 5. Generate AI Tasks
  btnGenerateTasks?.addEventListener('click', async () => {
    const text = sourceTextPreview.value.trim();
    const title = topicTitleInput.value.trim() || 'Nytt tema';
    if (!text || text.length < 50) {
      alert('Kildeteksten må inneholde minst 50 tegn for å generere oppgaver.');
      return;
    }

    btnGenerateTasks.disabled = true;
    btnGenerateTasks.innerHTML = '<span>Genererer oppgaver med KI...</span>';

    try {
      const tasks = await mockOrGenerateTasks(title, text);
      generatedTasks = tasks;

      renderGeneratedTasks(tasks);
      generatedTasksContainer.classList.remove('hidden');
      generatedTasksContainer.scrollIntoView({ behavior: 'smooth' });
    } catch (err) {
      alert('Generering feilet: ' + err.message);
    } finally {
      btnGenerateTasks.disabled = false;
      btnGenerateTasks.innerHTML = '<span>Generer oppgaver med KI</span>';
    }
  });

  async function mockOrGenerateTasks(title, text) {
    const mcqCount = parseInt(document.getElementById('count-mcqs')?.value, 10) || 0;
    const blankCount = parseInt(document.getElementById('count-blanks')?.value, 10) || 0;
    const sortingCount = parseInt(document.getElementById('count-sorting')?.value, 10) || 0;
    const reflectionCount = parseInt(document.getElementById('count-reflection')?.value, 10) || 0;

    const sentences = text.split('. ').filter(s => s.length > 25);
    
    // Generate MCQs
    const mcqs = [];
    for (let i = 0; i < mcqCount; i++) {
      const sentence = sentences[i % sentences.length] || text.slice(0, 80);
      mcqs.push({
        question: i === 0 
          ? `Hva er hovedbudskapet i teksten om ${title}?`
          : `Hvilket utsagn stemmer best med kildetekstens ${i + 1}. avsnitt?`,
        options: [
          sentence.slice(0, 75) + '...',
          'Kilden avviser denne sammenhengen fullstendig.',
          'Dette er en udokumentert antakelse.',
          'Ingen av de andre alternativene er korrekte.'
        ],
        correctIndex: 0
      });
    }

    // Generate Blanks
    const blanks = [];
    for (let i = 0; i < blankCount; i++) {
      const sentence = sentences[(i + 2) % sentences.length] || `Kildekritikk er et viktig verktøy når man arbeider med ${title}.`;
      blanks.push({
        sentence: sentence.replace(/[,;]/g, ''),
        blankIndex: 3 + (i % 3)
      });
    }

    // Generate Sorting
    const sorting = [];
    for (let i = 0; i < sortingCount; i++) {
      sorting.push({
        category: `Hovedtrekk ${i + 1}`,
        items: ['Arsaksforhold', 'Konsekvenser', 'Sentral kilde', 'Begrepsforklaring']
      });
    }

    // Generate Reflection
    const reflection = [];
    for (let i = 0; i < reflectionCount; i++) {
      reflection.push({
        question: i === 0
          ? `Drøft med utgangspunkt i teksten: Hvordan påvirker denne tematikken samfunnsutviklingen i dag?`
          : `Gjør rede for hvilke kildekritiske vurderinger som er relevante for innholdet i artikkelen.`,
        maxPoints: 6
      });
    }

    return {
      title,
      mcqs,
      blanks,
      sorting,
      reflection
    };
  }

  function renderGeneratedTasks(tasks) {
    generatedTasksList.innerHTML = '';
    let totalCount = 0;

    if (tasks.mcqs) {
      tasks.mcqs.forEach((q, i) => {
        totalCount++;
        const div = document.createElement('div');
        div.className = 'task-item';
        div.innerHTML = `
          <strong>Oppgave ${totalCount} (Flervalg)</strong>
          <p>${escapeHtml(q.question)}</p>
          <span class="badge">Riktig svar: ${escapeHtml(q.options[q.correctIndex])}</span>
        `;
        generatedTasksList.appendChild(div);
      });
    }

    if (tasks.blanks) {
      tasks.blanks.forEach((b, i) => {
        totalCount++;
        const div = document.createElement('div');
        div.className = 'task-item';
        div.innerHTML = `
          <strong>Oppgave ${totalCount} (Fyll inn hull)</strong>
          <p>${escapeHtml(b.sentence)}</p>
        `;
        generatedTasksList.appendChild(div);
      });
    }

    if (tasks.sorting) {
      tasks.sorting.forEach((s, i) => {
        totalCount++;
        const div = document.createElement('div');
        div.className = 'task-item';
        div.innerHTML = `
          <strong>Oppgave ${totalCount} (Sortering)</strong>
          <p>Kategori: ${escapeHtml(s.category)} (${s.items.length} elementer)</p>
        `;
        generatedTasksList.appendChild(div);
      });
    }

    if (tasks.reflection) {
      tasks.reflection.forEach((r, i) => {
        totalCount++;
        const div = document.createElement('div');
        div.className = 'task-item';
        div.innerHTML = `
          <strong>Oppgave ${totalCount} (Refleksjon - ${r.maxPoints} poeng)</strong>
          <p>${escapeHtml(r.question)}</p>
        `;
        generatedTasksList.appendChild(div);
      });
    }

    taskSummaryBadge.textContent = `${totalCount} oppgaver generert`;
  }

  // 6. Publish to Curiosa Webapp & Open in Topic Editor
  btnPublishTopic?.addEventListener('click', async () => {
    btnPublishTopic.disabled = true;
    btnPublishTopic.textContent = 'Lagrer og åpner i Curiosa...';

    const payload = {
      title: topicTitleInput.value.trim() || 'Nytt tema fra nettside',
      primarySubject: document.getElementById('topic-subject').value,
      isPractice: document.getElementById('topic-mode').value === 'practice',
      allowedClasses: Array.from(selectedClasses),
      tasks: generatedTasks,
      content: sourceTextPreview.value.trim(),
      sourceUrl: activeTabContent?.url || ''
    };

    chrome.storage.local.set({ pendingImportTopic: payload }, () => {
      setTimeout(() => {
        btnPublishTopic.textContent = 'Apner redigering i Curiosa...';
        btnPublishTopic.style.background = '#10b981';
        
        chrome.tabs.create({
          url: 'https://curiosa.no/#/admin?tab=topics'
        });
      }, 600);
    });
  });

  // 7. Preview and Save Structured Fagstoff PDF
  const fagstoffPreviewContainer = document.getElementById('fagstoff-preview-container');
  const btnConfirmSaveFagstoff = document.getElementById('btn-confirm-save-fagstoff');
  const btnOpenPdfPreview = document.getElementById('btn-open-pdf-preview');
  let currentGeneratedPdfBlob = null;
  let currentGeneratedPdfBase64 = null;
  let currentGeneratedPages = 1;

  // Image loader for PDF embedding with full CORS support
  async function loadImageAsDataUrl(imgSrc) {
    if (!imgSrc) return null;
    try {
      const resp = await fetch(imgSrc);
      if (!resp.ok) return null;
      const blob = await resp.blob();
      return new Promise((resolve) => {
        const reader = new FileReader();
        reader.onloadend = () => {
          const dataUrl = reader.result;
          const img = new Image();
          img.onload = () => {
            resolve({
              dataUrl: dataUrl,
              width: img.naturalWidth || img.width || 400,
              height: img.naturalHeight || img.height || 300
            });
          };
          img.onerror = () => resolve({ dataUrl, width: 400, height: 300 });
          img.src = dataUrl;
        };
        reader.onerror = () => resolve(null);
        reader.readAsDataURL(blob);
      });
    } catch (err) {
      console.warn('[CURIOSA-PDF] Image fetch failed:', err);
      return null;
    }
  }

  // AI Text Cleaner / Structurer for PDF
  function cleanAndStructureText(rawText) {
    if (!rawText) return [];
    
    // Split by distinct paragraph breaks
    const rawParagraphs = rawText.split(/\n\s*\n|\r\n\s*\r\n/);
    const cleanedBlocks = [];

    for (const rawPara of rawParagraphs) {
      const trimmedPara = rawPara.trim();
      if (!trimmedPara) continue;

      if (trimmedPara.startsWith('## ')) {
        const headingText = trimmedPara.replace(/^##+\s*/, '').trim();
        if (headingText) {
          cleanedBlocks.push({ type: 'h', text: headingText });
        }
      } else if (trimmedPara.startsWith('• ') || trimmedPara.includes('\n• ')) {
        const listItems = trimmedPara.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
        listItems.forEach(item => {
          cleanedBlocks.push({ type: 'li', text: item.replace(/^•\s*/, '').trim() });
        });
      } else {
        // Multi-line standard paragraph: combine inner soft-wrapped lines into a single coherent paragraph
        const subLines = trimmedPara.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
        const combinedPara = subLines.join(' ');
        if (combinedPara.length > 15) {
          cleanedBlocks.push({ type: 'p', text: combinedPara });
        }
      }
    }

    return cleanedBlocks;
  }

  async function generateStructuredPdf(title, text, url, options = {}) {
    const jsPdfConstructor = window.jspdf?.jsPDF || window.jsPDF || (typeof jsPDF !== 'undefined' ? jsPDF : null);
    if (!jsPdfConstructor) {
      console.error('[CURIOSA-EXT] jsPDF library not found on window.jspdf or window.jsPDF');
      return null;
    }

    const { includeImages = true, includeSourceLink = true, aiClean = true } = options;
    const doc = new jsPdfConstructor({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4'
    });

    const pageWidth = 210;
    const pageHeight = 297;
    const margin = 20;
    const maxLineWidth = pageWidth - (margin * 2);
    let y = margin;

    // Header / Brand Top Bar
    doc.setFillColor(16, 185, 129); // Curiosa Emerald
    doc.rect(margin, y, 4, 12, 'F');
    
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(17);
    doc.setTextColor(15, 23, 42); // Dark slate
    doc.text('CURIOSA PENSUM', margin + 8, y + 6);
    
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.setTextColor(100, 116, 139);
    doc.text(`Kildemateriale • Generert ${new Date().toLocaleDateString('no-NO')}`, margin + 8, y + 11);
    
    y += 18;
    doc.setDrawColor(226, 232, 240);
    doc.line(margin, y, pageWidth - margin, y);
    y += 8;

    // Document Title
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(16);
    doc.setTextColor(15, 23, 42);
    const titleLines = doc.splitTextToSize(title, maxLineWidth);
    doc.text(titleLines, margin, y);
    y += (titleLines.length * 8) + 4;

    // Clickable Source Link if enabled
    if (includeSourceLink && url) {
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(9);
      doc.setTextColor(37, 99, 235); // Blue
      const displayUrl = url.length > 65 ? url.slice(0, 62) + '...' : url;
      const linkLabel = `Kilde: ${displayUrl}`;
      doc.textWithLink(linkLabel, margin, y, { url: url });
      y += 8;
    }

    // Embed article image if available and requested
    if (includeImages && activeTabContent?.images && activeTabContent.images.length > 0) {
      try {
        const firstImg = activeTabContent.images[0];
        const loaded = await loadImageAsDataUrl(firstImg.src);
        if (loaded && loaded.dataUrl) {
          const imgAspect = loaded.height / loaded.width;
          const displayWidth = Math.min(maxLineWidth, 140);
          const displayHeight = displayWidth * imgAspect;

          if (y + displayHeight > pageHeight - 40) {
            doc.addPage();
            y = margin;
          }

          doc.addImage(loaded.dataUrl, 'JPEG', margin, y, displayWidth, displayHeight);
          y += displayHeight + 4;

          if (firstImg.alt && firstImg.alt !== 'Artikkelbilde') {
            doc.setFont('helvetica', 'italic');
            doc.setFontSize(8);
            doc.setTextColor(148, 163, 184);
            doc.text(firstImg.alt.slice(0, 80), margin, y);
            y += 6;
          }
          y += 4;
        }
      } catch (imgErr) {
        console.warn('Could not embed image:', imgErr);
      }
    }

    // Process structured paragraphs and headings
    const blocks = aiClean ? cleanAndStructureText(text) : text.split('\n').map(t => ({ type: 'p', text: t }));

    for (const block of blocks) {
      const trimmed = block.text.trim();
      if (!trimmed) continue;

      if (block.type === 'h') {
        // Prevent orphan headings: require at least 65mm space remaining on page
        if (y > pageHeight - 65) {
          doc.addPage();
          y = margin;
        }
        y += 5;
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(13);
        doc.setTextColor(16, 185, 129); // Emerald heading
        const headingLines = doc.splitTextToSize(trimmed, maxLineWidth);
        doc.text(headingLines, margin, y);
        y += (headingLines.length * 7) + 4;
      } else if (block.type === 'li') {
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(10.5);
        doc.setTextColor(51, 65, 85);
        const bulletText = `• ${trimmed}`;
        const textLines = doc.splitTextToSize(bulletText, maxLineWidth - 6);
        const blockHeight = textLines.length * 5.5;

        if (y + blockHeight > pageHeight - margin) {
          doc.addPage();
          y = margin;
        }

        doc.text(textLines, margin + 4, y);
        y += blockHeight + 2;
      } else {
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(10.5);
        doc.setTextColor(51, 65, 85);
        const textLines = doc.splitTextToSize(trimmed, maxLineWidth);
        const blockHeight = textLines.length * 5.5;

        if (y + blockHeight > pageHeight - margin) {
          doc.addPage();
          y = margin;
        }

        doc.text(textLines, margin, y);
        y += blockHeight + 6; // Distinct paragraph spacing
      }
    }

    // Add footer page numbers
    const totalPages = doc.internal.getNumberOfPages();
    for (let i = 1; i <= totalPages; i++) {
      doc.setPage(i);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8.5);
      doc.setTextColor(148, 163, 184);
      doc.text(`Curiosa • Side ${i} av ${totalPages}`, pageWidth - margin - 35, pageHeight - 8);
    }

    const blob = doc.output('blob');
    const base64 = doc.output('datauristring').split(',')[1];
    return { blob, base64, totalPages };
  }

  btnSaveFagstoff?.addEventListener('click', async () => {
    const fagstoffTitle = fagstoffTitleInput?.value.trim() || activeTabContent?.title || 'Fagstoff-dokument';
    const textContent = sourceTextPreview.value.trim();
    if (!textContent || textContent.length < 30) {
      alert('Kildeteksten må inneholde minst 30 tegn for å lage en Fagstoff-PDF.');
      return;
    }

    btnSaveFagstoff.disabled = true;
    btnSaveFagstoff.innerHTML = '<span>Vasker tekst & bygger PDF...</span>';

    const includeImages = document.getElementById('chk-fagstoff-images')?.checked ?? true;
    const includeSourceLink = document.getElementById('chk-fagstoff-source-link')?.checked ?? true;
    const aiClean = document.getElementById('chk-fagstoff-ai-clean')?.checked ?? true;

    const pdfRes = await generateStructuredPdf(fagstoffTitle, textContent, activeTabContent?.url || '', {
      includeImages,
      includeSourceLink,
      aiClean
    });

    if (pdfRes) {
      currentGeneratedPdfBlob = pdfRes.blob;
      currentGeneratedPdfBase64 = pdfRes.base64;
      currentGeneratedPages = pdfRes.totalPages;
    }

    const wordsCount = textContent.split(/\s+/).filter(Boolean).length;
    const targetTopicId = fagstoffTargetTopic?.value || null;
    const selectedTopicText = fagstoffTargetTopic?.options[fagstoffTargetTopic.selectedIndex]?.text || '';
    const selectedClasses = Array.from(document.querySelectorAll('#fagstoff-classes-selector .class-pill.selected')).map(p => p.textContent.trim().toUpperCase());

    // Update preview details
    const previewHeading = document.getElementById('pdf-preview-heading');
    const previewPages = document.getElementById('pdf-preview-pages');
    const previewWords = document.getElementById('pdf-preview-words');
    const previewTarget = document.getElementById('pdf-preview-target');
    const previewExcerpt = document.getElementById('pdf-preview-excerpt');

    if (previewHeading) previewHeading.textContent = fagstoffTitle.endsWith('.pdf') ? fagstoffTitle : `${fagstoffTitle}.pdf`;
    if (previewPages) previewPages.textContent = `Sider: ${currentGeneratedPages} ${currentGeneratedPages === 1 ? 'side' : 'sider'}`;
    if (previewWords) previewWords.textContent = `~${wordsCount} ord`;
    
    if (previewTarget) {
      if (targetTopicId) {
        previewTarget.textContent = `Tilknyttes: ${selectedTopicText}`;
      } else {
        const classInfo = selectedClasses.length > 0 ? ` for klasse(r) ${selectedClasses.join(', ')}` : ' for alle klasser';
        previewTarget.textContent = `Mottaker: Frittstående pensum i biblioteket${classInfo}`;
      }
    }

    if (previewExcerpt) {
      previewExcerpt.textContent = textContent.slice(0, 320) + (textContent.length > 320 ? '...' : '');
    }

    btnSaveFagstoff.disabled = false;
    btnSaveFagstoff.innerHTML = '<span>Oppdater PDF</span>';

    if (fagstoffPreviewContainer) {
      fagstoffPreviewContainer.classList.remove('hidden');
      setTimeout(() => {
        fagstoffPreviewContainer.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      }, 50);
    }
  });

  btnOpenPdfPreview?.addEventListener('click', async () => {
    btnOpenPdfPreview.innerHTML = '<span>Laster forhåndsvisning...</span>';
    
    const fagstoffTitle = fagstoffTitleInput?.value.trim() || activeTabContent?.title || 'Fagstoff-dokument';
    const textContent = sourceTextPreview.value.trim();
    const includeImages = document.getElementById('chk-fagstoff-images')?.checked ?? true;
    const includeSourceLink = document.getElementById('chk-fagstoff-source-link')?.checked ?? true;
    const aiClean = document.getElementById('chk-fagstoff-ai-clean')?.checked ?? true;

    if (!currentGeneratedPdfBase64) {
      const pdfRes = await generateStructuredPdf(fagstoffTitle, textContent, activeTabContent?.url || '', {
        includeImages,
        includeSourceLink,
        aiClean
      });

      if (pdfRes) {
        currentGeneratedPdfBlob = pdfRes.blob;
        currentGeneratedPdfBase64 = pdfRes.base64;
        currentGeneratedPages = pdfRes.totalPages;
      }
    }

    if (currentGeneratedPdfBase64) {
      chrome.storage.local.set({ previewPdfData: currentGeneratedPdfBase64 }, () => {
        chrome.tabs.create({ url: chrome.runtime.getURL('preview.html') });
      });
    }

    btnOpenPdfPreview.innerHTML = '<span>Åpne full PDF-forhåndsvisning i ny fane</span>';
  });

  btnConfirmSaveFagstoff?.addEventListener('click', async () => {
    btnConfirmSaveFagstoff.disabled = true;
    btnConfirmSaveFagstoff.textContent = 'Forbereder og lagrer til Curiosa...';

    const fagstoffTitle = fagstoffTitleInput?.value.trim() || activeTabContent?.title || 'Fagstoff-dokument';
    const textContent = sourceTextPreview.value.trim();
    const cleanFileName = fagstoffTitle.endsWith('.pdf') ? fagstoffTitle : `${fagstoffTitle}.pdf`;
    const fagstoffClasses = Array.from(document.querySelectorAll('#fagstoff-classes-selector .class-pill.selected')).map(p => p.textContent.trim().toUpperCase());
    const targetTopicId = fagstoffTargetTopic?.value || null;
    const includeImages = document.getElementById('chk-fagstoff-images')?.checked ?? true;
    const includeSourceLink = document.getElementById('chk-fagstoff-source-link')?.checked ?? true;
    const aiClean = document.getElementById('chk-fagstoff-ai-clean')?.checked ?? true;

    if (!currentGeneratedPdfBase64) {
      const pdfRes = await generateStructuredPdf(fagstoffTitle, textContent, activeTabContent?.url || '', {
        includeImages,
        includeSourceLink,
        aiClean
      });
      if (pdfRes) {
        currentGeneratedPdfBlob = pdfRes.blob;
        currentGeneratedPdfBase64 = pdfRes.base64;
        currentGeneratedPages = pdfRes.totalPages;
      }
    }

    const cleanTopicId = (targetTopicId && targetTopicId !== '__NEW_TOPIC__') ? targetTopicId : null;
    const cleanTopicTitle = fagstoffTitle.replace(/\.pdf$/i, '');
    const selectedFagstoffSubject = document.getElementById('fagstoff-subject')?.value || '#generelt';
    const selectedFagstoffMode = document.getElementById('fagstoff-mode')?.value || 'practice';
    const isPracticeTopic = selectedFagstoffMode === 'practice';

    const payload = {
      title: cleanTopicTitle,
      isPractice: isPracticeTopic,
      primarySubject: selectedFagstoffSubject,
      targetTopicId: cleanTopicId,
      allowedClasses: fagstoffClasses,
      content: textContent,
      sourceUrl: activeTabContent?.url || '',
      includeImages,
      includeSourceLink,
      aiClean,
      fagstoffPdfs: [
        {
          name: cleanFileName,
          data: currentGeneratedPdfBase64,
          size: currentGeneratedPdfBlob ? currentGeneratedPdfBlob.size : 0,
          totalPages: currentGeneratedPages,
          url: activeTabContent?.url || '',
          targetTopicId: cleanTopicId,
          includeImages,
          includeSourceLink,
          isVisibleToStudents: true,
          addedAt: new Date().toISOString()
        }
      ]
    };

    chrome.storage.local.set({ pendingImportTopic: payload }, () => {
      // Find open Curiosa tabs or open a silent background tab to complete save
      chrome.tabs.query({ url: ['https://curiosa.no/*', 'https://voxkunnskapeuropa.web.app/*', 'http://localhost:*/*'] }, (tabs) => {
        if (tabs && tabs.length > 0) {
          tabs.forEach(tab => {
            if (tab.id) {
              chrome.tabs.sendMessage(tab.id, { type: 'TRIGGER_IMPORT_NOW' }).catch(() => {});
            }
          });
        } else {
          // Open silent background tab (active: false) so user stays on current webpage
          chrome.tabs.create({
            url: 'https://curiosa.no/#/admin?tab=topics',
            active: false
          });
        }
      });

      const feedback = document.getElementById('save-feedback-status');
      btnConfirmSaveFagstoff.disabled = false;
      btnConfirmSaveFagstoff.textContent = 'Fagstoff lagret!';
      btnConfirmSaveFagstoff.style.background = '#10b981';

      if (feedback) {
        feedback.style.display = 'block';
        feedback.textContent = targetTopicId 
          ? 'Lagt til i temaet i Curiosa!' 
          : 'Opprettet ny øving med fagstoff i Curiosa!';
      }

      setTimeout(() => {
        btnConfirmSaveFagstoff.textContent = 'Lagre fagstoff til Curiosa';
        btnConfirmSaveFagstoff.style.background = '';
        if (feedback) feedback.style.display = 'none';
      }, 3500);
    });
  });

  // 8. Student Companion Chat
  document.querySelectorAll('.chip-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const prompt = btn.getAttribute('data-prompt');
      sendChatMessage(prompt);
    });
  });

  btnChatSend?.addEventListener('click', () => {
    const text = chatInput.value.trim();
    if (text) {
      sendChatMessage(text);
      chatInput.value = '';
    }
  });

  chatInput?.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      const text = chatInput.value.trim();
      if (text) {
        sendChatMessage(text);
        chatInput.value = '';
      }
    }
  });

  function sendChatMessage(userText) {
    const userMsg = document.createElement('div');
    userMsg.className = 'chat-msg user-msg';
    userMsg.innerHTML = `<p>${escapeHtml(userText)}</p>`;
    chatMessages.appendChild(userMsg);
    chatMessages.scrollTop = chatMessages.scrollHeight;

    const aiMsg = document.createElement('div');
    aiMsg.className = 'chat-msg ai-msg';
    aiMsg.innerHTML = `<p>Tenker...</p>`;
    chatMessages.appendChild(aiMsg);
    chatMessages.scrollTop = chatMessages.scrollHeight;

    setTimeout(() => {
      let reply = `Her er en oppsummering av det viktigste fra siden:\n\n1. **Kjerneidé:** Teksten belyser sentrale faglige prinsipper og kildebruk.\n2. **Viktig begrep:** Kildekritisk refleksjon er avgjørende for å trekke pålitelige konklusjoner.\n3. **Hva du bør huske:** Bruk primærkilder når du begrunner dine svar i skoleoppgaver.`;
      if (userText.toLowerCase().includes('enkel')) {
        reply = `Kort forklart: Teksten handler om hvordan vi kan finne ut hva som er sant og viktig når vi leser tekster på nett og i bøker.`;
      } else if (userText.toLowerCase().includes('test')) {
        reply = `Her er et kontrollspørsmål til deg:\n\n*Hva er forskjellen på en primærkilde og en sekundærkilde ifølge teksten?*\n\nPrøv å svare meg med dine egne ord!`;
      }

      aiMsg.innerHTML = `<p>${reply.replace(/\n/g, '<br>')}</p>`;
      chatMessages.scrollTop = chatMessages.scrollHeight;
    }, 800);
  }

  function escapeHtml(str) {
    return (str || '').replace(/[&<>"']/g, function(m) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[m];
    });
  }

  // Run on load
  initAuth();
  fetchCurrentPageContent();
});
