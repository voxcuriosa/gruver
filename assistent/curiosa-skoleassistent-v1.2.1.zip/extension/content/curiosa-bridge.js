// Curiosa Skoleassistent - Webapp Bridge Content Script
// Runs on curiosa.no / voxkunnskapeuropa.web.app / localhost

(function() {
  console.log('[CURIOSA-EXT] Bridge initialized on Curiosa webapp.');
  document.documentElement.setAttribute('data-curiosa-extension', 'true');
  window.postMessage({ type: 'CURIOSA_EXTENSION_INSTALLED', version: '1.0.0' }, '*');

  function formatCuriosaDisplayName(rawName) {
    if (!rawName || rawName === 'Curiosa Lærerassistent') return 'Curiosa Lærerassistent';
    
    // If it is an email like "fornavn.etternavn@skole.no" or "fornavn_gmail_com"
    if (rawName.includes('@') || rawName.includes('_')) {
      const prefix = rawName.split('@')[0].split('_')[0];
      const parts = prefix.split('.');
      const cleanParts = parts.map(p => p.charAt(0).toUpperCase() + p.slice(1).toLowerCase());
      return cleanParts.join(' ');
    }
    
    // Normal name
    return rawName.trim();
  }

  function extractFirstName(rawName) {
    if (!rawName) return 'Lærer';
    const formatted = formatCuriosaDisplayName(rawName);
    const firstName = formatted.split(' ')[0];
    return firstName || 'Lærer';
  }

  // Strict validator for Norwegian school classes (e.g. 1B, 2A, 3MOKA, 3PBYA, 3PBYB, LATIN)
  function isValidClassCode(str) {
    if (!str || typeof str !== 'string') return false;
    const clean = str.trim().toUpperCase();
    return (/^[1-3][A-ZÆØÅ]{1,5}$/.test(clean) || clean === 'LATIN');
  }

  // Extract ONLY pure school classes (excludes student names and PIN codes)
  function extractClassesFromDom() {
    const classes = new Set();

    // 1. Try localStorage first (populated by Admin.jsx)
    try {
      const stored = JSON.parse(localStorage.getItem('voks_teacher_classes') || '[]');
      if (Array.isArray(stored)) {
        stored.forEach(cls => {
          if (isValidClassCode(cls)) {
            classes.add(cls.trim().toUpperCase());
          }
        });
      }
    } catch(e) {}

    // 2. Specific class elements in the student table (p.text-brand-400)
    document.querySelectorAll('p.text-brand-400, .text-brand-400').forEach(el => {
      const txt = el.textContent?.trim().toUpperCase();
      if (isValidClassCode(txt)) {
        classes.add(txt);
      }
    });

    return Array.from(classes).sort();
  }

  // Scrape teacher profile directly from Curiosa Admin DOM
  function extractTeacherFromDom() {
    const headerEl = document.querySelector('header') || document.querySelector('.header') || document.body;
    const textAll = headerEl?.innerText || '';
    const nameMatch = textAll.match(/([A-ZÆØÅ\s\-]{4,50}\s*•\s*[A-ZÆØÅ\s\-]{3,50})/i);
    if (nameMatch) {
      return nameMatch[1].trim();
    }
    return '';
  }

  function safeSendMessage(message) {
    try {
      if (!chrome?.runtime?.id) return;
      chrome.runtime.sendMessage(message, () => {
        if (chrome.runtime.lastError) {
          // Handled safely to avoid unchecked runtime.lastError
        }
      });
    } catch (e) {
      // Extension context invalidated / updated
    }
  }

  // Sync auth state from webapp to extension storage
  function syncAuthFromDom() {
    try {
      if (!chrome?.runtime?.id) return;
      const storedAuth = localStorage.getItem('voks_auth_user') || localStorage.getItem('voks_user') || localStorage.getItem('curiosa_session') || localStorage.getItem('voks_user_email');
      const teacherName = localStorage.getItem('voks_teacher_name') || extractTeacherFromDom();
      const storedRole = localStorage.getItem('voks_role') || (storedAuth?.includes('@') || teacherName || window.location.hash.includes('admin') ? 'teacher' : 'student');
      const studentClass = localStorage.getItem('voks_student_class') || '';
      
      const domClasses = extractClassesFromDom();
      let teacherTopics = [];
      try {
        const storedTopicsRaw = localStorage.getItem('voks_teacher_topics');
        if (storedTopicsRaw) teacherTopics = JSON.parse(storedTopicsRaw);
      } catch (e) {}

      if (domClasses.length > 0) {
        localStorage.setItem('voks_teacher_classes', JSON.stringify(domClasses));
      }
      if (teacherName) {
        localStorage.setItem('voks_teacher_name', teacherName);
      }

      if (storedAuth || domClasses.length > 0 || teacherName || teacherTopics.length > 0) {
        const formattedLabel = formatCuriosaDisplayName(teacherName || (typeof storedAuth === 'string' && storedAuth.startsWith('{') ? JSON.parse(storedAuth).name : storedAuth));
        
        safeSendMessage({
          type: 'AUTH_STATE_SYNC',
          payload: {
            user: {
              name: formattedLabel,
              displayName: formattedLabel,
              email: localStorage.getItem('voks_user_email') || localStorage.getItem('voks_teacher_email') || ''
            },
            role: storedRole,
            classes: domClasses.length > 0 ? domClasses : (studentClass ? [studentClass] : []),
            topics: teacherTopics,
            hasReadWriteSupport: localStorage.getItem('voks_read_write_support') === 'true'
          }
        });
      }
    } catch (e) {
      console.warn('[CURIOSA-EXT] Error syncing auth:', e);
    }
  }

  // Initial and periodic sync
  syncAuthFromDom();
  setTimeout(syncAuthFromDom, 500);
  setTimeout(syncAuthFromDom, 1500);
  setTimeout(syncAuthFromDom, 3000);

  // Observe DOM for dynamic route changes or class list loads
  let syncTimeout = null;
  const observer = new MutationObserver(() => {
    if (syncTimeout) clearTimeout(syncTimeout);
    syncTimeout = setTimeout(syncAuthFromDom, 600);
  });
  observer.observe(document.body, { childList: true, subtree: true });

  // Listen for explicit webapp auth events
  window.addEventListener('CURIOSA_AUTH_UPDATE', (event) => {
    if (event.detail) {
      safeSendMessage({
        type: 'AUTH_STATE_SYNC',
        payload: event.detail
      });
    }
  });

  // Listen for Exam Focus events from Dashboard.jsx
  window.addEventListener('CURIOSA_EXAM_START', (event) => {
    const whitelist = event.detail?.whitelist || [];
    console.log('[CURIOSA-EXT] Received exam start event. Whitelist:', whitelist);
    safeSendMessage({
      type: 'START_EXAM_FOCUS',
      whitelist
    });
  });

  window.addEventListener('CURIOSA_EXAM_STOP', () => {
    console.log('[CURIOSA-EXT] Received exam stop event.');
    safeSendMessage({
      type: 'STOP_EXAM_FOCUS'
    });
  });

  // Check for pending imported topic or PDF from extension with handshake ACK
  function dispatchPendingImport() {
    try {
      chrome.storage.local.get(['pendingImportTopic'], (data) => {
        if (data && data.pendingImportTopic) {
          console.log('[CURIOSA-EXT] Found pendingImportTopic, dispatching event to webapp:', data.pendingImportTopic);
          window.dispatchEvent(new CustomEvent('CURIOSA_IMPORT_TOPIC', {
            detail: data.pendingImportTopic
          }));
        }
      });
    } catch (e) {}
  }

  // Admin acknowledged import -> safe to delete from storage
  window.addEventListener('CURIOSA_IMPORT_ACK', () => {
    console.log('[CURIOSA-EXT] Admin acknowledged import receipt. Clearing storage.');
    try {
      chrome.storage.local.remove(['pendingImportTopic']);
    } catch (e) {}
  });

  // Admin announced it is ready -> dispatch immediately
  window.addEventListener('CURIOSA_WEBAPP_READY', () => {
    console.log('[CURIOSA-EXT] Received CURIOSA_WEBAPP_READY event.');
    dispatchPendingImport();
  });

  // Listen for direct background triggers from sidepanel
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg && msg.type === 'TRIGGER_IMPORT_NOW') {
      console.log('[CURIOSA-EXT] Received TRIGGER_IMPORT_NOW in Curiosa tab');
      dispatchPendingImport();
      sendResponse({ status: 'ok' });
      return false;
    }

    if (msg && msg.type === 'EXECUTE_AI_TASK_GENERATION') {
      const requestId = 'ai_gen_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);
      
      let replied = false;
      const sendOnce = (res) => {
        if (replied) return;
        replied = true;
        window.removeEventListener('CURIOSA_AI_GENERATE_RESPONSE', customEventListener);
        document.removeEventListener('CURIOSA_AI_GENERATE_RESPONSE', customEventListener);
        window.removeEventListener('message', messageListener);
        sendResponse(res);
      };

      const customEventListener = (event) => {
        if (event.detail?.requestId === requestId) {
          sendOnce(event.detail);
        }
      };

      const messageListener = (event) => {
        if (event.data?.type === 'CURIOSA_AI_GENERATE_RESPONSE' && event.data.detail?.requestId === requestId) {
          sendOnce(event.data.detail);
        }
      };

      window.addEventListener('CURIOSA_AI_GENERATE_RESPONSE', customEventListener);
      document.addEventListener('CURIOSA_AI_GENERATE_RESPONSE', customEventListener);
      window.addEventListener('message', messageListener);

      const payload = {
        requestId,
        ...msg.payload
      };

      window.dispatchEvent(new CustomEvent('CURIOSA_AI_GENERATE_REQUEST', { detail: payload }));
      document.dispatchEvent(new CustomEvent('CURIOSA_AI_GENERATE_REQUEST', { detail: payload }));
      window.postMessage({ type: 'CURIOSA_AI_GENERATE_REQUEST', payload }, '*');

      setTimeout(() => {
        sendOnce({ success: false, error: 'Tidsavbrudd ved KI-generering' });
      }, 50000);

      return true; // Keep message port open for async response
    }
  });

  // Check periodically until acknowledged
  let checkCount = 0;
  const intervalId = setInterval(() => {
    checkCount++;
    try {
      chrome.storage.local.get(['pendingImportTopic'], (data) => {
        if (data && data.pendingImportTopic) {
          dispatchPendingImport();
        } else {
          clearInterval(intervalId);
        }
      });
    } catch (e) {
      clearInterval(intervalId);
    }
    if (checkCount > 15) {
      clearInterval(intervalId);
    }
  }, 700);
})();
