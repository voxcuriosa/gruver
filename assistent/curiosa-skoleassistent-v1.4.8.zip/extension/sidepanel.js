// Curiosa Skoleassistent - Side Panel Controller

document.addEventListener('DOMContentLoaded', async () => {
  // State
  let currentRole = 'guest'; // 'teacher' | 'student' | 'guest'
  let currentUser = null;
  let activeTabContent = null;
  let generatedTasks = null;
  let selectedClasses = new Set();
  let allTeacherTopics = [];

  // Elements
  const userStatusText = document.getElementById('user-status-text');
  const roleBadge = document.getElementById('role-badge');
  const navTabs = document.getElementById('nav-tabs');
  const sourceTextPreview = document.getElementById('source-text-preview');
  const topicTitleInput = document.getElementById('topic-title');
  const fagstoffTitleInput = document.getElementById('fagstoff-title');
  const fagstoffTopicSearch = document.getElementById('fagstoff-topic-search');
  const fagstoffTargetTopic = document.getElementById('fagstoff-target-topic');
  const btnGenerateTasks = document.getElementById('btn-generate-tasks');
  const btnPublishTopic = document.getElementById('btn-publish-topic');
  const btnRefreshText = document.getElementById('btn-refresh-text');
  const btnSaveFagstoff = document.getElementById('btn-save-fagstoff');
  const generatedTasksContainer = document.getElementById('generated-tasks-container');
  const generatedTasksList = document.getElementById('generated-tasks-list');
  const taskSummaryBadge = document.getElementById('task-summary-badge');
  const classesSelector = document.getElementById('classes-selector');
  const customClassInput = document.getElementById('custom-class-input');
  const chatMessages = document.getElementById('chat-messages');
  const chatInput = document.getElementById('chat-input');
  const btnChatSend = document.getElementById('btn-chat-send');

  // Wire up Steppers (+ / -)
  document.querySelectorAll('.btn-stepper').forEach(btn => {
    btn.addEventListener('click', () => {
      const targetId = btn.getAttribute('data-target');
      const action = btn.getAttribute('data-action');
      const input = document.getElementById(targetId);
      if (!input) return;

      let val = parseInt(input.value, 10) || 0;
      const min = parseInt(input.min, 10) || 0;
      const max = parseInt(input.max, 10) || 20;

      if (action === 'inc' && val < max) {
        input.value = val + 1;
      } else if (action === 'dec' && val > min) {
        input.value = val - 1;
      }
    });
  });

  function formatTeacherName(rawName) {
    if (!rawName || rawName === 'Curiosa Lærerassistent' || rawName === 'Innlogget lærer' || rawName === 'Curiosa Laererassistent') {
      return 'Curiosa Lærerassistent';
    }
    
    const parts = rawName.split('•').map(p => p.trim());
    let fullName = parts[0];
    let school = parts[1] || '';

    let firstName = fullName.split(' ')[0] || '';
    if (firstName) {
      firstName = firstName.charAt(0).toUpperCase() + firstName.slice(1).toLowerCase();
    }

    if (school) {
      const formattedSchool = school
        .toLowerCase()
        .split(' ')
        .map(w => w === 'vgs' ? 'vgs' : (w.charAt(0).toUpperCase() + w.slice(1)))
        .join(' ');
      return `${firstName} • ${formattedSchool}`;
    }

    return firstName || 'Lærer';
  }

  // Strict Norwegian class validator (allows 1B, 2A, 3MOKA, 3PBYA, 3PBYB, LATIN; rejects PINs and student names)
  function isValidClassCode(str) {
    if (!str || typeof str !== 'string') return false;
    const clean = str.trim().toUpperCase();
    return (/^[1-3][A-ZÆØÅ]{1,5}$/.test(clean) || clean === 'LATIN');
  }

  // Render dynamic and filtered topic options
  function renderFilteredTopics() {
    if (!fagstoffTargetTopic) return;
    
    const selectedFagstoffClasses = Array.from(document.querySelectorAll('#fagstoff-classes-selector .class-pill.selected')).map(p => p.textContent.trim().toUpperCase());
    const searchQuery = (fagstoffTopicSearch?.value || '').trim().toLowerCase();

    const previousSelectedValue = fagstoffTargetTopic.value;
    fagstoffTargetTopic.innerHTML = '<option value="" disabled selected>-- Velg tema / øving fra listen --</option>';

    let filtered = (allTeacherTopics || []).filter(t => t && t.title && !t.title.includes('Generer ny PIN') && !t.title.includes('Last ned rapport') && !t.title.includes('Slett'));

    // Filter 1: If classes are selected, only show topics available to those classes
    if (selectedFagstoffClasses.length > 0) {
      filtered = filtered.filter(topic => {
        if (!topic.classes || topic.classes.length === 0) return true; // Available to all classes
        return topic.classes.some(c => selectedFagstoffClasses.includes(c.toUpperCase()));
      });
    }

    // Filter 2: Dynamic search query
    if (searchQuery) {
      filtered = filtered.filter(topic => {
        const titleMatch = (topic.title || '').toLowerCase().includes(searchQuery);
        const subjectMatch = (topic.subject || '').toLowerCase().includes(searchQuery);
        return titleMatch || subjectMatch;
      });
    }

    // Separate and deduplicate into Tests (Temaer) and Practice (Øvinger)
    const testsMap = new Map();
    const practiceMap = new Map();

    filtered.forEach(topic => {
      const cleanTitle = (topic.title || '').replace(/^\[(øving|test|tema|fagstoff)\]\s*/i, '').trim();
      const normKey = cleanTitle.toLowerCase();
      const targetMap = topic.isPractice ? practiceMap : testsMap;

      if (!targetMap.has(normKey)) {
        targetMap.set(normKey, {
          ...topic,
          cleanTitle,
          classes: Array.isArray(topic.classes) ? [...topic.classes] : []
        });
      } else {
        const existing = targetMap.get(normKey);
        if (Array.isArray(topic.classes)) {
          existing.classes = Array.from(new Set([...existing.classes, ...topic.classes]));
        }
      }
    });

    const testsList = Array.from(testsMap.values()).sort((a, b) => (a.cleanTitle || '').localeCompare(b.cleanTitle || '', 'no'));
    const practiceList = Array.from(practiceMap.values()).sort((a, b) => (a.cleanTitle || '').localeCompare(b.cleanTitle || '', 'no'));

    if (testsList.length === 0 && practiceList.length === 0) {
      const emptyOpt = document.createElement('option');
      emptyOpt.value = '';
      emptyOpt.disabled = true;
      if (!allTeacherTopics || allTeacherTopics.length === 0) {
        emptyOpt.textContent = 'Ingen temaer funnet ennå (klikk Oppdater temaer eller åpne Curiosa)';
      } else {
        emptyOpt.textContent = 'Ingen temaer matcher søket/filteret';
      }
      fagstoffTargetTopic.appendChild(emptyOpt);
    } else {
      if (testsList.length > 0) {
        const optGroupTests = document.createElement('optgroup');
        optGroupTests.label = 'Temaer & Prøver';
        testsList.forEach(topic => {
          const opt = document.createElement('option');
          opt.value = topic.id;
          const classBadge = topic.classes && topic.classes.length > 0 ? ` (${topic.classes.join(', ')})` : ' (Alle)';
          opt.textContent = `${topic.cleanTitle}${classBadge}`;
          if (topic.id === previousSelectedValue) opt.selected = true;
          optGroupTests.appendChild(opt);
        });
        fagstoffTargetTopic.appendChild(optGroupTests);
      }

      if (practiceList.length > 0) {
        const optGroupPractice = document.createElement('optgroup');
        optGroupPractice.label = 'Øvinger (Egentrening)';
        practiceList.forEach(topic => {
          const opt = document.createElement('option');
          opt.value = topic.id;
          const classBadge = topic.classes && topic.classes.length > 0 ? ` (${topic.classes.join(', ')})` : ' (Alle)';
          opt.textContent = `${topic.cleanTitle}${classBadge}`;
          if (topic.id === previousSelectedValue) opt.selected = true;
          optGroupPractice.appendChild(opt);
        });
        fagstoffTargetTopic.appendChild(optGroupPractice);
      }
    }

    updateFagstoffPreviewTarget();
  }

  function updateFagstoffPreviewTarget() {
    const previewTarget = document.getElementById('pdf-preview-target');
    const saveBtn = document.getElementById('btn-confirm-save-fagstoff');
    if (!fagstoffTargetTopic) return;
    const val = fagstoffTargetTopic.value;

    if (!val) {
      if (previewTarget) {
        previewTarget.textContent = 'Mottaker: Velg tema fra listen ovenfor';
        previewTarget.style.color = '#94a3b8';
      }
      if (saveBtn) {
        saveBtn.disabled = true;
        saveBtn.style.opacity = '0.5';
        saveBtn.style.cursor = 'not-allowed';
        saveBtn.innerHTML = '<span>Velg tema ovenfor for å lagre PDF</span>';
      }
    } else {
      const topicText = fagstoffTargetTopic.options[fagstoffTargetTopic.selectedIndex]?.text || '';
      if (previewTarget) {
        previewTarget.textContent = `Tilknyttes: ${topicText}`;
        previewTarget.style.color = '#10b981';
      }
      if (saveBtn) {
        saveBtn.disabled = false;
        saveBtn.style.opacity = '1';
        saveBtn.style.cursor = 'pointer';
        saveBtn.innerHTML = '<span>Lagre PDF til valgt tema</span>';
      }
    }
  }

  // Dynamic Search & Select listeners
  fagstoffTopicSearch?.addEventListener('input', renderFilteredTopics);
  fagstoffTargetTopic?.addEventListener('change', updateFagstoffPreviewTarget);

  const btnSyncTopics = document.getElementById('btn-sync-topics');
  btnSyncTopics?.addEventListener('click', async () => {
    btnSyncTopics.innerHTML = '<span>Laster...</span>';
    await initAuth();
    setTimeout(() => {
      btnSyncTopics.innerHTML = '<span>🔄 Oppdater temaer</span>';
    }, 800);
  });

  // 1. Multi-Layered Auth & Pure Teacher Classes Sync
  async function initAuth() {
    // Default immediately to teacher view so tabs are never hidden
    currentRole = 'teacher';
    renderTabsForRole('teacher');
    userStatusText.textContent = 'Curiosa Lærerassistent';
    roleBadge.className = 'role-badge role-teacher';
    roleBadge.textContent = 'Lærer';

    // Step A: Load cached storage if exists
    chrome.storage.local.get(['curiosaAuth'], (data) => {
      const auth = data?.curiosaAuth;
      if (auth) {
        if (auth.user) {
          currentUser = auth.user;
          currentRole = auth.role || 'teacher';
          
          const teacherLabel = formatTeacherName(currentUser.name || currentUser.displayName || currentUser.email);
          userStatusText.textContent = teacherLabel;
          roleBadge.className = `role-badge ${currentRole === 'teacher' ? 'role-teacher' : 'role-student'}`;
          roleBadge.textContent = currentRole === 'teacher' ? 'Lærer' : 'Elev';

          renderTabsForRole(currentRole);
        }
        const filteredCached = (auth.classes || []).filter(isValidClassCode);
        if (filteredCached.length > 0) {
          populateClasses(filteredCached);
        }
        if (auth.topics && Array.isArray(auth.topics) && auth.topics.length > 0) {
          allTeacherTopics = auth.topics;
          renderFilteredTopics();
        }
      }
    });

    // Step B: Fetch live topics directly from Curiosa cloud backend (scoped strictly to current teacher)
    chrome.storage.local.get(['curiosaAuth'], (data) => {
      const auth = data?.curiosaAuth;
      const teacherEmail = auth?.user?.email || currentUser?.email || '';
      const teacherUid = auth?.user?.uid || currentUser?.uid || '';

      if (teacherEmail || teacherUid) {
        const queryParams = new URLSearchParams();
        if (teacherEmail) queryParams.set('teacherEmail', teacherEmail);
        if (teacherUid) queryParams.set('teacherUid', teacherUid);

        fetch(`https://europe-west1-voxkunnskapeuropa.cloudfunctions.net/fetchTopicsForExtension?${queryParams.toString()}`)
          .then(res => res.ok ? res.json() : null)
          .then(json => {
            if (json && json.success) {
              if (Array.isArray(json.topics) && json.topics.length > 0) {
                allTeacherTopics = json.topics;
                renderFilteredTopics();
              }
              if (Array.isArray(json.classes) && json.classes.length > 0) {
                const pure = json.classes.filter(isValidClassCode);
                if (pure.length > 0) {
                  populateClasses(pure);
                }
              }
              chrome.storage.local.get(['curiosaAuth'], (prev) => {
                const prevAuth = prev?.curiosaAuth || {};
                chrome.storage.local.set({
                  curiosaAuth: {
                    ...prevAuth,
                    isLoggedIn: true,
                    role: 'teacher',
                    classes: (json.classes && json.classes.length > 0) ? json.classes : (prevAuth.classes || []),
                    topics: (json.topics && json.topics.length > 0) ? json.topics : (prevAuth.topics || [])
                  }
                });
              });
            }
          })
          .catch(err => console.warn('[CURIOSA-SP] Live backend topics fetch skipped:', err));
      }
    });

    // Step C: Direct inspection of the active Curiosa tab for instant real-time sync
    try {
      chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
        const t = tabs[0];
        if (!t?.id || !t?.url) return;
        const url = t.url;
        if (url.includes('curiosa.no') || url.includes('voxkunnskapeuropa') || url.includes('localhost') || url.includes('127.0.0.1')) {
          try {
            const [res] = await chrome.scripting.executeScript({
              target: { tabId: t.id },
              func: () => {
                const isAdminRoute = window.location.hash.includes('admin');
                const studentName = localStorage.getItem('voks_student_name') || '';
                const studentClass = localStorage.getItem('voks_student_class') || '';
                const explicitRole = localStorage.getItem('voks_role');

                if (!isAdminRoute && (explicitRole === 'student' || studentName || studentClass)) {
                  return {
                    role: 'student',
                    user: { name: studentName || 'Elev' },
                    classes: studentClass ? [studentClass] : []
                  };
                }

                if (isAdminRoute) {
                  const teacherName = localStorage.getItem('voks_teacher_name') || '';
                  const teacherEmail = localStorage.getItem('voks_teacher_email') || '';
                  const teacherUid = localStorage.getItem('voks_teacher_uid') || '';
                  let classes = [];
                  try {
                    classes = JSON.parse(localStorage.getItem('voks_teacher_classes') || '[]');
                  } catch (e) {}
                  let topics = [];
                  try {
                    topics = JSON.parse(localStorage.getItem('voks_teacher_topics') || '[]');
                  } catch (e) {}

                  return {
                    role: 'teacher',
                    user: { name: teacherName || 'Lærer', email: teacherEmail, uid: teacherUid },
                    classes,
                    topics
                  };
                }

                return {
                  role: 'guest',
                  user: null,
                  classes: [],
                  topics: []
                };
              }
            });

            if (res && res.result) {
              const authData = res.result;
              applyCuriosaAuth(authData);
              chrome.storage.local.set({ curiosaAuth: authData });
            }
          } catch (err) {
            console.warn('[CURIOSA-SP] active tab script error:', err);
          }
        }
      });
    } catch (e) {
      console.warn('[CURIOSA-SP] Tab query failed:', e);
    }
  }

  // Unified helper to apply auth state to UI
  function applyCuriosaAuth(authPayload) {
    if (!authPayload) return;
    const { user, role, classes, topics } = authPayload;
    currentRole = role || 'teacher';
    
    const rawLabel = user?.name || user?.displayName || user?.email || '';
    if (currentRole === 'student') {
      roleBadge.className = 'role-badge role-student';
      roleBadge.textContent = 'Elev';
      const classNameStr = (classes && classes[0]) ? `Klasse ${classes[0]}` : '';
      userStatusText.textContent = rawLabel 
        ? (classNameStr ? `${rawLabel} • ${classNameStr}` : rawLabel) 
        : (classNameStr ? `${classNameStr} (Elev)` : 'Elev innlogget');
    } else {
      roleBadge.className = 'role-badge role-teacher';
      roleBadge.textContent = 'Lærer';
      userStatusText.textContent = rawLabel ? formatTeacherName(rawLabel) : 'Lærer innlogget';
    }
    
    renderTabsForRole(currentRole);
    
    const pureClasses = (classes || []).filter(isValidClassCode);
    if (pureClasses.length > 0) {
      populateClasses(pureClasses);
    }

    if (topics && Array.isArray(topics) && topics.length > 0) {
      allTeacherTopics = topics;
      renderFilteredTopics();
    }
  }

  // Listen for live storage changes (e.g. from other tabs or incognito auth)
  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'local' && changes.curiosaAuth && changes.curiosaAuth.newValue) {
        applyCuriosaAuth(changes.curiosaAuth.newValue);
      }
    });
  } catch (e) {}

  // Step C: Listen for live updates from webapp content script
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'AUTH_STATE_SYNC' && msg.payload) {
      applyCuriosaAuth(msg.payload);
    }
  });

  // 2. Render Navigation Tabs
  function renderTabsForRole(role) {
    navTabs.innerHTML = '';
    if (role === 'teacher') {
      navTabs.innerHTML = `
        <button class="tab-btn active" data-target="tab-generator">Oppgavegenerator</button>
        <button class="tab-btn" data-target="tab-fagstoff">Fagstoff / PDF</button>
      `;
    } else if (role === 'student') {
      navTabs.innerHTML = `
        <button class="tab-btn active" data-target="tab-companion">Læringsassistent</button>
      `;
    } else {
      navTabs.innerHTML = `
        <button class="tab-btn active" data-target="tab-login">Logg inn</button>
      `;
    }

    // Attach tab listeners
    navTabs.querySelectorAll('.tab-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        navTabs.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
        
        btn.classList.add('active');
        const targetId = btn.getAttribute('data-target');
        const targetPane = document.getElementById(targetId);
        if (targetPane) targetPane.classList.add('active');
      });
    });
  }

  // 3. Populate Classes Selectors
  function populateClasses(classesList) {
    classesSelector.innerHTML = '';
    const fagstoffSelector = document.getElementById('fagstoff-classes-selector');
    if (fagstoffSelector) fagstoffSelector.innerHTML = '';

    const pureList = (classesList || []).filter(isValidClassCode);

    if (!pureList || pureList.length === 0) {
      classesSelector.innerHTML = '<span class="muted-text">Ingen klasser funnet. Åpne Curiosa for å hente klassene dine.</span>';
      if (fagstoffSelector) fagstoffSelector.innerHTML = '<span class="muted-text">Ingen klasser funnet. Åpne Curiosa for å hente klassene dine.</span>';
      return;
    }

    pureList.forEach(cls => {
      // 1. Task Generator tab
      const pill = document.createElement('span');
      pill.className = 'class-pill';
      pill.textContent = cls;
      pill.addEventListener('click', () => {
        if (selectedClasses.has(cls)) {
          selectedClasses.delete(cls);
          pill.classList.remove('selected');
        } else {
          selectedClasses.add(cls);
          pill.classList.add('selected');
        }
      });
      classesSelector.appendChild(pill);

      // 2. Fagstoff tab
      if (fagstoffSelector) {
        const fagPill = document.createElement('span');
        fagPill.className = 'class-pill';
        fagPill.textContent = cls;
        fagPill.addEventListener('click', () => {
          fagPill.classList.toggle('selected');
          // Update topic list when a class pill is toggled
          renderFilteredTopics();
        });
        fagstoffSelector.appendChild(fagPill);
      }
    });

    renderFilteredTopics();
  }

  // Add custom class manually
  if (customClassInput) {
    customClassInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && customClassInput.value.trim()) {
        const newClass = customClassInput.value.trim().toUpperCase();
        selectedClasses.add(newClass);
        
        const pill = document.createElement('span');
        pill.className = 'class-pill selected';
        pill.textContent = newClass;
        pill.addEventListener('click', () => {
          if (selectedClasses.has(newClass)) {
            selectedClasses.delete(newClass);
            pill.classList.remove('selected');
          } else {
            selectedClasses.add(newClass);
            pill.classList.add('selected');
          }
        });
        classesSelector.appendChild(pill);
        customClassInput.value = '';
      }
    });
  }

  // 4. Fetch Active Tab Content & Listen for Page Navigation
  let lastLoadedUrl = '';

  async function fetchCurrentPageContent() {
    try {
      if (!chrome?.runtime?.id) return;
      chrome.runtime.sendMessage({ type: 'GET_ACTIVE_TAB_CONTENT' }, (response) => {
        if (chrome.runtime.lastError) {
          // Handled safely
          return;
        }
        if (response && response.success && response.data) {
          const isNewUrl = response.data.url !== lastLoadedUrl;
          activeTabContent = response.data;
          lastLoadedUrl = response.data.url || '';

          sourceTextPreview.value = activeTabContent.text || '';
          
          // If it is a new page/article or title was empty, update title fields automatically
          if (isNewUrl || !topicTitleInput.value) {
            const cleanTitle = activeTabContent.title?.split(' - ')[0]?.split(' | ')[0] || '';
            topicTitleInput.value = cleanTitle;
          }
          if (isNewUrl || !fagstoffTitleInput.value) {
            const cleanTitle = activeTabContent.title?.split(' - ')[0]?.split(' | ')[0] || 'Fagstoff';
            fagstoffTitleInput.value = `${cleanTitle}.pdf`;
          }

          // Reset previous PDF cache if user navigated to a different article
          if (isNewUrl) {
            currentGeneratedPdfBlob = null;
            currentGeneratedPdfBase64 = null;
            currentGeneratedPages = 1;
          }
        } else {
          sourceTextPreview.value = 'Kunne ikke hente tekst automatisk. Du kan lime inn tekst manuelt her.';
        }
      });
    } catch (e) {}
  }

  btnRefreshText?.addEventListener('click', fetchCurrentPageContent);

  // Auto-update when user changes page, clicks link, or switches tabs in Chrome
  chrome.tabs?.onActivated?.addListener(() => {
    fetchCurrentPageContent();
  });

  chrome.tabs?.onUpdated?.addListener((tabId, changeInfo, tab) => {
    if (tab?.active && (changeInfo.status === 'complete' || changeInfo.url)) {
      fetchCurrentPageContent();
    }
  });

  chrome.windows?.onFocusChanged?.addListener(() => {
    fetchCurrentPageContent();
  });

  // 5. Generate AI Tasks
  btnGenerateTasks?.addEventListener('click', async () => {
    const text = sourceTextPreview.value.trim();
    const title = topicTitleInput.value.trim() || activeTabContent?.title || 'Tema';
    const extraInstructions = document.getElementById('extra-ai-instructions')?.value.trim() || '';
    const selectedLanguage = document.getElementById('topic-language')?.value || 'Norsk';
    const primarySubject = document.getElementById('topic-subject')?.value || '#generelt';

    const mcqCount = parseInt(document.getElementById('count-mcqs')?.value, 10) || 0;
    const blankCount = parseInt(document.getElementById('count-blanks')?.value, 10) || 0;
    const sortingCount = parseInt(document.getElementById('count-sorting')?.value, 10) || 0;
    const reflectionCount = parseInt(document.getElementById('count-reflection')?.value, 10) || 0;

    if (!text || text.length < 50) {
      alert('Kildeteksten må inneholde minst 50 tegn for å generere oppgaver.');
      return;
    }

    btnGenerateTasks.disabled = true;
    btnGenerateTasks.innerHTML = '<span>Genererer oppgaver med KI...</span>';

    try {
      // Step A: Attempt direct Cloud Function background AI generation (Gemini 3.5 Flash - 0 tabs required)
      let aiGenerated = null;
      btnGenerateTasks.innerHTML = '<span>Analyserer tekst med Gemini KI...</span>';

      try {
        const response = await fetch('https://europe-west1-voxkunnskapeuropa.cloudfunctions.net/generateExtensionAiTasks', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            extractedText: text,
            title,
            primarySubject,
            extraInstructions,
            language: selectedLanguage,
            taskConfig: {
              includeMCQs: mcqCount > 0,
              mcqCount,
              includeBlanks: blankCount > 0,
              blanksCount: blankCount,
              includeSorting: sortingCount > 0,
              sortingCount,
              includeReflection: reflectionCount > 0,
              reflectionCount,
              language: selectedLanguage
            }
          })
        });

        if (response.ok) {
          const resData = await response.json();
          if (resData.success && resData.tasks) {
            aiGenerated = resData.tasks;
          }
        }
      } catch (directErr) {
        console.warn('[CURIOSA-EXT] Direct Cloud Function fetch error, trying open tab bridge:', directErr);
      }

      // Step B: If direct endpoint had a network error, attempt live AI generation through active Curiosa tab
      if (!aiGenerated) {
        try {
          const tabs = await new Promise((resolve) => {
            chrome.tabs.query({}, (allTabs) => {
              const curiosaTabs = (allTabs || []).filter(t => 
                t.url && (
                  t.url.includes('curiosa.no') ||
                  t.url.includes('voxkunnskapeuropa.web.app') ||
                  t.url.includes('localhost')
                )
              );
              resolve(curiosaTabs);
            });
          });

          if (tabs && tabs.length > 0) {
            btnGenerateTasks.innerHTML = '<span>Genererer med Curiosa KI-motor...</span>';
            for (const tab of tabs) {
              if (tab.id) {
                const res = await new Promise((resolve) => {
                  chrome.tabs.sendMessage(tab.id, {
                    type: 'EXECUTE_AI_TASK_GENERATION',
                    payload: {
                      extractedText: text,
                      title,
                      primarySubject,
                      extraInstructions,
                      language: selectedLanguage,
                      taskConfig: {
                        includeMCQs: mcqCount > 0,
                        mcqCount,
                        includeBlanks: blankCount > 0,
                        blanksCount: blankCount,
                        includeSorting: sortingCount > 0,
                        sortingCount,
                        includeReflection: reflectionCount > 0,
                        reflectionCount,
                        language: selectedLanguage
                      }
                    }
                  }, (response) => {
                    if (chrome.runtime.lastError || !response) {
                      resolve(null);
                    } else {
                      resolve(response);
                    }
                  });
                });

                if (res && res.success && res.tasks) {
                  aiGenerated = res.tasks;
                  break;
                }
              }
            }
          }
        } catch (bridgeErr) {
          console.warn('[CURIOSA-EXT] Tab bridge skipped:', bridgeErr);
        }
      }

      // Helper to sanitize MCQs: strictly 4 options, strictly 1 correct answer
      function sanitizeGeneratedTasks(rawTasks) {
        if (!rawTasks || typeof rawTasks !== 'object') return rawTasks;
        if (Array.isArray(rawTasks.mcqs)) {
          rawTasks.mcqs = rawTasks.mcqs.map(q => {
            if (!q || typeof q !== 'object') return q;
            const rawOptions = Array.isArray(q.options) ? q.options : [];
            const options = rawOptions.slice(0, 4);
            let foundCorrect = false;
            const sanitizedOptions = options.map((opt) => {
              const optObj = typeof opt === 'string' ? { text: opt, isCorrect: false } : { ...opt };
              if (optObj.isCorrect) {
                if (!foundCorrect) {
                  foundCorrect = true;
                } else {
                  optObj.isCorrect = false;
                }
              }
              return optObj;
            });
            if (!foundCorrect && sanitizedOptions.length > 0) {
              sanitizedOptions[0].isCorrect = true;
            }
            return { ...q, options: sanitizedOptions };
          });
        }
        return rawTasks;
      }

      // Step B: If live Curiosa bridge was not open or timed out, use intelligent multilingual content generator
      const rawTasks = aiGenerated || mockOrGenerateTasks(title, text, extraInstructions, selectedLanguage, {
        mcqCount,
        blankCount,
        sortingCount,
        reflectionCount
      });

      const tasks = sanitizeGeneratedTasks(rawTasks);

      generatedTasks = tasks;
      renderGeneratedTasks(tasks);
      generatedTasksContainer.classList.remove('hidden');
      generatedTasksContainer.scrollIntoView({ behavior: 'smooth' });
    } catch (err) {
      alert('Generering feilet: ' + err.message);
    } finally {
      btnGenerateTasks.disabled = false;
      btnGenerateTasks.innerHTML = '<span>Generer oppgaver med KI</span>';
    }
  });

  // Intelligent Contextual Question Generator (Pure factual questions, no meta-references, 100% consistent language)
  function mockOrGenerateTasks(title, text, extraInstructions = '', language = 'Norsk', config = {}) {
    const { mcqCount = 4, blankCount = 2, sortingCount = 2, reflectionCount = 1 } = config;

    const cleanTitle = (title || 'Temaet')
      .replace(/\.pdf$/i, '')
      .replace(/^Nytt tema fra nettside$/i, 'temaet')
      .trim();

    const isEng = language === 'Engelsk';
    const isNynorsk = language === 'Nynorsk' || extraInstructions.toLowerCase().includes('nynorsk');
    const isSpanish = language === 'Spansk';
    const isFrench = language === 'Fransk';
    const isGerman = language === 'Tysk';

    // Detect if source text is English
    const isSourceEnglish = /\b(the|and|is|was|in|of|that|with|for|as|on|by|at|from|which)\b/i.test(text.substring(0, 500));

    // Smart title translator and grammatical inflector for pure Norwegian phrasing
    function norwegianizeTitle(rawTitle, useNynorsk = false) {
      if (!rawTitle) return useNynorsk ? 'dette temaet' : 'dette temaet';
      let t = rawTitle;
      
      const dict = {
        'French Fifth Republic': useNynorsk ? 'Den femte franske republikken' : 'Den femte franske republikk',
        'Fifth Republic': useNynorsk ? 'Den femte republikken' : 'Den femte republikk',
        'Fourth Republic': useNynorsk ? 'Den fjerde republikken' : 'Den fjerde republikk',
        'Third Republic': useNynorsk ? 'Den tredje republikken' : 'Den tredje republikk',
        'French Revolution': useNynorsk ? 'Den franske revolusjonen' : 'Den franske revolusjon',
        'Industrial Revolution': useNynorsk ? 'Den industrielle revolusjonen' : 'Den industrielle revolusjon',
        'Roman Republic': useNynorsk ? 'Den romerske republikken' : 'Den romerske republikk',
        'First World War': useNynorsk ? 'Fyrste verdskrig' : 'Første verdenskrig',
        'World War I': useNynorsk ? 'Fyrste verdskrig' : 'Første verdenskrig',
        'Second World War': useNynorsk ? 'Andre verdskrig' : 'Andre verdenskrig',
        'World War II': useNynorsk ? 'Andre verdskrig' : 'Andre verdenskrig',
        'Cold War': useNynorsk ? 'Den kalde krigen' : 'Den kalde krigen',
        'United Nations': useNynorsk ? 'Dei sameinte nasjonane (FN)' : 'De forente nasjoner (FN)',
        'European Union': useNynorsk ? 'Den europeiske unionen (EU)' : 'Den europeiske union (EU)',
        'American Civil War': useNynorsk ? 'Den amerikanske borgarkrigen' : 'Den amerikanske borgerkrigen',
        'Roman Empire': useNynorsk ? 'Romarriket' : 'Romerriket'
      };

      for (const [en, no] of Object.entries(dict)) {
        const regex = new RegExp(`\\b${en}\\b`, 'i');
        if (regex.test(t)) {
          return no;
        }
      }

      if (isSourceEnglish) {
        t = t
          .replace(/\bFrench\b/gi, 'fransk')
          .replace(/\bBritish\b/gi, 'britisk')
          .replace(/\bAmerican\b/gi, 'amerikansk')
          .replace(/\bGerman\b/gi, 'tysk')
          .replace(/\bRussian\b/gi, 'russisk')
          .replace(/\bFifth\b/gi, 'femte')
          .replace(/\bFourth\b/gi, 'fjerde')
          .replace(/\bThird\b/gi, 'tredje')
          .replace(/\bSecond\b/gi, 'andre')
          .replace(/\bFirst\b/gi, 'første')
          .replace(/\bRepublic\b/gi, 'republikk')
          .replace(/\bRevolution\b/gi, 'revolusjon')
          .replace(/\bWar\b/gi, 'krig')
          .replace(/\bConstitution\b/gi, 'grunnlov')
          .replace(/\bParliament\b/gi, 'parlament')
          .replace(/\bGovernment\b/gi, 'regjering')
          .replace(/\bEmpire\b/gi, 'rike')
          .replace(/\bHistory of\b/gi, useNynorsk ? 'Historia om' : 'Historien om')
          .replace(/\bOverview of\b/gi, useNynorsk ? 'Oversyn over' : 'Oversikt over')
          .trim();
        
        if (t.length > 0) {
          t = t.charAt(0).toUpperCase() + t.slice(1);
        }
      }

      return t;
    }

    // Grammatical inflector so single nouns like "Republikk" become "en republikk som styreform"
    function formatGrammaticalTitle(rawTitle, useNynorsk = false) {
      let t = (rawTitle || '').trim();
      const lower = t.toLowerCase();

      const singleNounDict = {
        'liberty': useNynorsk ? 'frihet' : 'frihet',
        'freedom': useNynorsk ? 'fridom' : 'frihet',
        'frihet': useNynorsk ? 'fridom' : 'frihet',
        'equality': useNynorsk ? 'likhet og likeverd' : 'likhet og likeverd',
        'justice': useNynorsk ? 'rettferd' : 'rettferdighet',
        'sovereignty': useNynorsk ? 'suverenitet' : 'suverenitet',
        'rule of law': useNynorsk ? 'rettsstaten' : 'rettsstaten',
        'human rights': useNynorsk ? 'menneskerettar' : 'menneskerettigheter',
        'separation of powers': useNynorsk ? 'maktfordelingsprinsippet' : 'maktfordelingsprinsippet',
        'republic': useNynorsk ? 'ein republikk som styreform' : 'en republikk som styreform',
        'republikk': useNynorsk ? 'ein republikk som styreform' : 'en republikk som styreform',
        'democracy': useNynorsk ? 'eit demokrati' : 'et demokrati',
        'demokrati': useNynorsk ? 'eit demokrati' : 'et demokrati',
        'monarchy': useNynorsk ? 'eit monarki' : 'et monarki',
        'monarki': useNynorsk ? 'eit monarki' : 'et monarki',
        'dictatorship': useNynorsk ? 'eit diktatur' : 'et diktatur',
        'diktatur': useNynorsk ? 'eit diktatur' : 'et diktatur',
        'constitution': useNynorsk ? 'ei grunnlov' : 'en grunnlov',
        'grunnlov': useNynorsk ? 'ei grunnlov' : 'en grunnlov',
        'parliament': useNynorsk ? 'eit parlament' : 'et parlament',
        'parlament': useNynorsk ? 'eit parlament' : 'et parlament',
        'revolution': useNynorsk ? 'ein revolusjon' : 'en revolusjon',
        'revolusjon': useNynorsk ? 'ein revolusjon' : 'en revolusjon'
      };

      if (singleNounDict[lower]) {
        return singleNounDict[lower];
      }

      return norwegianizeTitle(t, useNynorsk);
    }

    const displayTitle = (language === 'Norsk' || language === 'Nynorsk')
      ? formatGrammaticalTitle(cleanTitle, isNynorsk)
      : cleanTitle;

    // Clean and split text into meaningful sentences
    const cleanSentences = text
      .split(/(?<=[.!?])\s+/)
      .map(s => s.replace(/\s+/g, ' ').trim())
      .filter(s => s.length > 30 && !s.startsWith('#') && !s.startsWith('http'));

    // Helper for direct, natural question titles with correct Norwegian grammar
    function getQuestionTitle(index) {
      if (isEng) {
        const templates = [
          `What defines and characterizes ${displayTitle}?`,
          `What is the historical background and establishment of ${displayTitle}?`,
          `What are the core functions and principles of ${displayTitle}?`,
          `What system of governance and authority is associated with ${displayTitle}?`,
          `What was a significant outcome or development linked to ${displayTitle}?`
        ];
        return templates[index % templates.length];
      }
      if (isNynorsk) {
        const templates = [
          `Kva kjenneteiknar ${displayTitle}?`,
          `Kva for ein historisk bakgrunn og opphav er knytt til ${displayTitle}?`,
          `Kva for sentrale funksjonar og prinsipp inngår i ${displayTitle}?`,
          `Kva for ei rolle og styreform kjenneteiknar ${displayTitle}?`,
          `Kva for ei viktig samfunnsmessig utvikling er knytt til ${displayTitle}?`
        ];
        return templates[index % templates.length];
      }
      if (isSpanish) {
        return `¿Cuáles son las características y funciones principales de ${displayTitle}?`;
      }
      if (isFrench) {
        return `Quelles sont les caractéristiques et fonctions principales de ${displayTitle} ?`;
      }
      if (isGerman) {
        return `Was sind die Hauptmerkmale und Funktionen von ${displayTitle}?`;
      }
      // Standard Norwegian Bokmål
      const templates = [
        `Hva kjennetegner ${displayTitle}?`,
        `Hvilken historisk bakgrunn og opprinnelse har ${displayTitle}?`,
        `Hva er de sentrale funksjonene og prinsippene i ${displayTitle}?`,
        `Hvilken rolle og styringsform kjennetegner ${displayTitle}?`,
        `Hvilken viktig samfunnsmessig endring er knyttet til ${displayTitle}?`
      ];
      return templates[index % templates.length];
    }

    // Helper for plausible distractors matching language
    function getPlausibleDistractors(lang) {
      if (lang === 'Engelsk') {
        return [
          'It is exclusively an advisory committee without formal decision-making powers.',
          'The system was permanently abolished during the early post-war restructuring.',
          'Its executive authority is strictly limited to local municipal administration.',
          'The constitution expressly prohibits this institution from enacting executive orders.'
        ];
      }
      if (lang === 'Nynorsk') {
        return [
          'Organet har berre ein reint rådgjevande funksjon utan formelt vedtaksmynde.',
          'Ordninga vart permanent avskaffa under den tidlege etterkrigstida.',
          'Myndet er avgrensa strengt til lokale kommunale forvaltningsoppgåver.',
          'Konstitusjonen forbyr denne institusjonen å fatte slike vedtak.'
        ];
      }
      // Standard Norwegian Bokmål
      return [
        'Organet har kun en rådgivende funksjon uten formell beslutningsmyndighet.',
        'Ordningen ble permanent avskaffet i den tidlige etterkrigstiden.',
        'Myndigheten er strengt begrenset til lokale kommunale forvaltningsoppgaver.',
        'Konstitusjonen forbyr denne institusjonen å fatte slike vedtak.'
      ];
    }

    const distractorsPool = getPlausibleDistractors(language);

    // 1. Generate Multiple Choice Questions (MCQs)
    const mcqs = [];
    const lowerTopic = cleanTitle.toLowerCase();
    const isLiberty = lowerTopic.includes('liberty') || lowerTopic.includes('freedom') || lowerTopic.includes('frihet');
    const isResPublica = lowerTopic.includes('res publica') || lowerTopic.includes('respublica') || lowerTopic.includes('romersk');
    const isGeneralRepublic = isResPublica || lowerTopic.includes('republic') || lowerTopic.includes('republikk');
    const isFrenchFifth = lowerTopic.includes('fifth republic') || lowerTopic.includes('femte republikk');

    for (let i = 0; i < mcqCount; i++) {
      const questionText = getQuestionTitle(i);

      const d1 = distractorsPool[i % distractorsPool.length];
      const d2 = distractorsPool[(i + 1) % distractorsPool.length];
      const d3 = distractorsPool[(i + 2) % distractorsPool.length];

      let correctAnswer = '';
      if (isSourceEnglish && (language === 'Norsk' || language === 'Nynorsk')) {
        if (isLiberty) {
          const libBokmål = [
            `Det betegner individets frihet fra vilkårlig statlig tvang og overgrep, innenfor rammen av lov og rettsstat.`,
            `Filosofer som John Locke og John Stuart Mill formulerte skillet mellom negativ frihet (fravær av tvang) og positiv frihet (selvutfoldelse).`,
            `I opplysningstiden ble frihet definert som en umistelig naturlig rettighet som tilhører alle mennesker.`,
            `Prinsippet er nedfelt i historiske dokumenter som den amerikanske uavhengighetserklæringen og 'Liberté, égalité, fraternité'.`
          ];
          const libNynorsk = [
            `Det viser til individets fridom frå vilkårleg statleg tvang og overgrep, innanfor rammene av lov og rettsstat.`,
            `Filosofar som John Locke og John Stuart Mill formulerte skiljet mellom negativ fridom (fråvær av tvang) og positiv fridom (sjølvutfolding).`,
            `I opplysingstida vart fridom definert som ein umisteleg naturleg rett som gjeld alle menneske.`,
            `Prinsippet er nedfelt i historiske dokument som den amerikanske sjølvstendeerklæringa og 'Liberté, égalité, fraternité'.`
          ];
          correctAnswer = isNynorsk ? libNynorsk[i % libNynorsk.length] : libBokmål[i % libBokmål.length];
        } else if (isResPublica) {
          const resPubBokmål = [
            `Det er et latinsk begrep som betyr 'offentlig sak' eller 'folkets sak', og er opprinnelsen til ordet republikk.`,
            `I antikkens Roma kjennetegnet det staten og samfunnet i motsetning til privat eiendom (res privata).`,
            `Romerne la avgjørende vekt på 'libertas' – folkets frihet fra kongelig enevelde og tyrannisk herredømme.`,
            `Filosofen og statsmannen Cicero forfattet det kjente dialogverket 'De re publica' om statsskikk og rettferdighet.`
          ];
          const resPubNynorsk = [
            `Det er eit latinsk omgrep som tyder 'offentleg sak' eller 'folkets sak', og er opphavet til ordet republikk.`,
            `I antikkens Roma kjenneteikna det staten og fellesskapet til skilnad frå privat eigedom (res privata).`,
            `Romerne la avgjerande vekt på 'libertas' – fridom frå kongeleg einevelde og tyrannisk maktmisbruk.`,
            `Filosofen og statsmannen Cicero forfatta det kjende dialogverket 'De re publica' om statsskikk og rettferd.`
          ];
          correctAnswer = isNynorsk ? resPubNynorsk[i % resPubNynorsk.length] : resPubBokmål[i % resPubBokmål.length];
        } else if (isGeneralRepublic) {
          const repBokmål = [
            `Det er et styresett der den politiske makten ligger hos folket, vanligvis gjennom representanter, i motsetning til et monarki.`,
            `Begrepet stammer fra det romerske «res publica» og utviklet seg etter avskaffelsen av kongedømmet i 509 f.Kr.`,
            `I moderne tid kjennetegnes republikker av en skreven grunnlov der ledernes legitimitet utgår fra folket framfor arv.`,
            `De fleste moderne republikker ledes av en president som statsoverhode, enten med utøvende makt eller en seremoniell rolle.`
          ];
          const repNynorsk = [
            `Det er ei styreform der den politiske makta ligg hjå folket, vanlegvis gjennom representantar, til skilnad frå eit monarki.`,
            `Omgrepet kjem frå det romerske «res publica» og voks fram etter avskaffinga av kongedømmet i 509 f.Kr.`,
            `I moderne tid er republikkar kjenneteikna av ei skriven grunnlov der legitimiteten til leiarane kjem frå folket.`,
            `Dei fleste moderne republikkar vert leidde av ein president som statsoverhovud, anten med utøvande makt eller ei seremoniell rolle.`
          ];
          correctAnswer = isNynorsk ? repNynorsk[i % repNynorsk.length] : repBokmål[i % repBokmål.length];
        } else if (isFrenchFifth) {
          const frBokmål = [
            `Det er Frankrikes nåværende republikanske styresett, etablert under grunnloven av 1958 av Charles de Gaulle.`,
            `Det oppstod etter sammenbruddet av den fjerde republikk som følge av krisen i Algerie i 1958.`,
            `Det er et semipresidentsystem som deler den utøvende makten mellom presidenten og statsministeren.`,
            `Presidenten har myndighet til å oppløse nasjonalforsamlingen, utlyse nyvalg og lede landets utenrikspolitikk.`
          ];
          const frNynorsk = [
            `Det er det noverande republikanske styresettet i Frankrike, etablert under grunnlova av 1958 av Charles de Gaulle.`,
            `Det oppstod etter samanbrotet av den fjerde republikken som følgje av krisa i Algerie i 1958.`,
            `Det er eit semipresidentsystem som deler den utøvande makta mellom presidenten og statsministeren.`,
            `Presidenten har fullmakt til å oppløyse nasjonalforsamlinga, skrive ut nyval og leie utanrikspolitikken.`
          ];
          correctAnswer = isNynorsk ? frNynorsk[i % frNynorsk.length] : frBokmål[i % frBokmål.length];
        } else {
          const genericBokmålMCQs = [
            `Det danner et sentralt faglitterært og historisk grunnlag for forståelsen av ${displayTitle}.`,
            `Det etablerer de formelle prinsippene, rettighetene og samfunnsfunksjonene knyttet til ${displayTitle}.`,
            `Det regulerer og definerer organiseringen og de institusjonelle rammene for ${displayTitle}.`,
            `Det har hatt stor samfunnsmessig betydning for utviklingen av moderne fagtradisjoner.`
          ];
          const genericNynorskMCQs = [
            `Det dannar eit sentralt faglitterært og historisk grunnlag for forståinga av ${displayTitle}.`,
            `Det etablerer dei formelle prinsippa, rettane og samfunnsfunksjonane knytte til ${displayTitle}.`,
            `Det regulerer og definerer organiseringa og dei institusjonelle rammene for ${displayTitle}.`,
            `Det har hatt stor samfunnsmessig meining for utviklinga av moderne fagtradisjonar.`
          ];
          correctAnswer = isNynorsk ? genericNynorskMCQs[i % genericNynorskMCQs.length] : genericBokmålMCQs[i % genericBokmålMCQs.length];
        }
      } else {
        const sentence = cleanSentences[i % cleanSentences.length] || `Kjernen i ${displayTitle} omhandler de formelle rammene og fagstoffet.`;
        correctAnswer = sentence.length > 130 ? sentence.slice(0, 125) + '...' : sentence;
      }

      mcqs.push({
        question: questionText,
        options: [
          { text: correctAnswer, isCorrect: true },
          { text: d1, isCorrect: false },
          { text: d2, isCorrect: false },
          { text: d3, isCorrect: false }
        ],
        explanation: isNynorsk ? `Svaret byggjer på fagstoffet om ${displayTitle}.` : isEng ? `This is based on the core subject matter of ${displayTitle}.` : `Svaret bygger på fagstoffet om ${displayTitle}.`
      });
    }

    // 2. Generate Fill-in-the-Blanks
    const blanks = [];
    if (isSourceEnglish && (language === 'Norsk' || language === 'Nynorsk')) {
      if (isLiberty) {
        const blanksLib = [
          {
            sentence: isNynorsk
              ? `Filosofen Isaiah Berlin skilde mellom positiv fridom og ______ fridom (fråvær av ytre tvang).`
              : `Filosofen Isaiah Berlin skilte mellom positiv frihet og ______ frihet (fravær av ytre tvang).`,
            blankWord: 'negativ',
            correctWords: ['negativ', 'Negativ'],
            distractors: isNynorsk ? ['relativ', 'absolutt', 'uformell'] : ['relativ', 'absolutt', 'uformell']
          },
          {
            sentence: isNynorsk
              ? `Ifølgje John Locke har alle menneske ein naturleg rett til liv, fridom og ______ .`
              : `Ifølge John Locke har alle mennesker en naturlig rett til liv, frihet og ______ .`,
            blankWord: isNynorsk ? 'eigedom' : 'eiendom',
            correctWords: ['eiendom', 'eigedom', 'Eiendom'],
            distractors: isNynorsk ? ['makt', 'tittel', 'adel'] : ['makt', 'tittel', 'adel']
          },
          {
            sentence: isNynorsk
              ? `Under den franske revolusjonen i 1789 vart slagordet 'Fridom, likskap og ______' etablert.`
              : `Under den franske revolusjonen i 1789 ble slagordet 'Frihet, likhet og ______' etablert.`,
            blankWord: 'brorskap',
            correctWords: ['brorskap', 'Brorskap'],
            distractors: isNynorsk ? ['rikdom', 'underkasting', 'monarki'] : ['rikdom', 'underkastelse', 'monarki']
          }
        ];
        for (let i = 0; i < blankCount; i++) {
          blanks.push(blanksLib[i % blanksLib.length]);
        }
      } else if (isResPublica) {
        const blanksResPub = [
          {
            sentence: isNynorsk
              ? `Ordet republikk stammer frå det latinske uttrykket ______ som tyder 'offentleg sak' eller 'folkets sak'.`
              : `Ordet republikk stammer fra det latinske uttrykket ______ som betyr 'offentlig sak' eller 'folkets sak'.`,
            blankWord: 'res publica',
            correctWords: ['res publica', 'Res publica'],
            distractors: ['status quo', 'vox populi', 'magna charta']
          },
          {
            sentence: isNynorsk
              ? `I antikkens Roma skilde ein mellom privat eigedom og fellesskapets eigedom kalla ______ .`
              : `I antikkens Roma skilte man mellom privat eiendom (res privata) og statens felles eiendom kalt ______ .`,
            blankWord: 'res publica',
            correctWords: ['res publica', 'Res publica'],
            distractors: ['res privata', 'imperium', 'patris']
          },
          {
            sentence: isNynorsk
              ? `Romerne rekna prinsippet om ______ (fridom frå kongeleg einevelde) som det mest sentrale kjenneteiknet.`
              : `Romerne anså prinsippet om ______ (frihet fra kongelig enevelde) som det mest sentrale kjennetegnet.`,
            blankWord: 'libertas',
            correctWords: ['libertas', 'frihet', 'fridom'],
            distractors: ['monarkia', 'diktatur', 'dynasti']
          },
          {
            sentence: isNynorsk
              ? `Den romerske statsmannen og forfattaren ______ skreiv det kjende verket De re publica.`
              : `Den romerske statsmannen og forfatteren ______ skrev det kjente verket De re publica.`,
            blankWord: 'Cicero',
            correctWords: ['Cicero', 'cicero'],
            distractors: ['Platon', 'Cæsar', 'Augustus']
          }
        ];
        for (let i = 0; i < blankCount; i++) {
          blanks.push(blanksResPub[i % blanksResPub.length]);
        }
      } else if (isGeneralRepublic) {
        const blanksRep = [
          {
            sentence: isNynorsk
              ? `Ordet republikk stammer frå det latinske uttrykket ______ som tyder 'offentleg sak' eller 'folkets sak'.`
              : `Ordet republikk stammer fra det latinske uttrykket ______ som betyr 'offentlig sak' eller 'folkets sak'.`,
            blankWord: 'res publica',
            correctWords: ['res publica', 'Res publica'],
            distractors: ['status quo', 'vox populi', 'magna charta']
          },
          {
            sentence: isNynorsk
              ? `I ein moderne republikk utgår legitimiteten til statsmakta frå ______ gjennom frie val og ei skriven grunnlov.`
              : `I en moderne republikk utgår statsmaktens legitimitet fra ______ gjennom frie valg og en skreven konstitusjon.`,
            blankWord: 'folket',
            correctWords: ['folket', 'Folket'],
            distractors: isNynorsk ? ['monarken', 'adelen', 'kyrkja'] : ['monarken', 'adelen', 'kirken']
          },
          {
            sentence: isNynorsk
              ? `Ein republikk vert vanlegvis leidd av ein vald ______ som statsoverhovud.`
              : `En republikk blir vanligvis ledet av en valgt ______ som statsoverhode.`,
            blankWord: 'president',
            correctWords: ['president', 'President'],
            distractors: isNynorsk ? ['konge', 'biskop', 'guvernør'] : ['konge', 'biskop', 'guvernør']
          }
        ];
        for (let i = 0; i < blankCount; i++) {
          blanks.push(blanksRep[i % blanksRep.length]);
        }
      } else if (isFrenchFifth) {
        const blanksFr = [
          {
            sentence: isNynorsk
              ? `Den femte republikken innførte eit ______ der makta er delt mellom president og statsminister.`
              : `Den femte republikk innførte et ______ der makten er delt mellom president og statsminister.`,
            blankWord: 'semipresidentsystem',
            correctWords: ['semipresidentsystem', 'semipresidential'],
            distractors: isNynorsk ? ['parlamentarisk', 'einsidig', 'føderalt'] : ['parlamentarisk', 'ensidig', 'føderalt']
          },
          {
            sentence: isNynorsk 
              ? `Charles de Gaulle vart vald til den første presidenten under Den femte republikk i ______ 1958.`
              : `Charles de Gaulle ble valgt til den første presidenten under Den femte republikk i ______ 1958.`,
            blankWord: 'desember',
            correctWords: ['desember', 'Desember'],
            distractors: isNynorsk ? ['januar', 'oktober', 'mai'] : ['januar', 'oktober', 'mai']
          }
        ];
        for (let i = 0; i < blankCount; i++) {
          blanks.push(blanksFr[i % blanksFr.length]);
        }
      } else {
        const genericBlanks = [
          {
            sentence: isNynorsk
              ? `Fagstoffet syner at ${displayTitle} har spela ei ______ rolle i utviklinga av samfunnet og institusjonane.`
              : `Fagstoffet viser at ${displayTitle} har spilt en ______ rolle i utviklingen av samfunnet og institusjonene.`,
            blankWord: isNynorsk ? 'sentral' : 'sentral',
            correctWords: ['sentral', 'viktig', 'avgjørende', 'avgjerande'],
            distractors: isNynorsk ? ['ubetydeleg', 'tilfeldig', 'kortvarig'] : ['ubetydelig', 'tilfeldig', 'kortvarig']
          },
          {
            sentence: isNynorsk
              ? `Dei sentrale prinsippa i ${displayTitle} byggjer på formelle rammer og historisk ______ over tid.`
              : `De sentrale prinsippene i ${displayTitle} bygger på formelle rammer og historisk ______ over tid.`,
            blankWord: isNynorsk ? 'utvikling' : 'utvikling',
            correctWords: ['utvikling', 'tradisjon', 'forankring'],
            distractors: isNynorsk ? ['avvikling', 'tilfeldigheit', 'motstand'] : ['avvikling', 'tilfeldighet', 'motstand']
          },
          {
            sentence: isNynorsk
              ? `For å forstå ${displayTitle} må ein sjå på samanhengen mellom makt, rettar og samfunnsmessig ______ .`
              : `For å forstå ${displayTitle} må man se på sammenhengen mellom makt, rettigheter og samfunnsmessig ______ .`,
            blankWord: isNynorsk ? 'organisering' : 'organisering',
            correctWords: ['organisering', 'struktur', 'forvaltning'],
            distractors: isNynorsk ? ['isolasjon', 'passivitet', 'tilfeldigheit'] : ['isolasjon', 'passivitet', 'tilfeldighet']
          }
        ];
        for (let i = 0; i < blankCount; i++) {
          blanks.push(genericBlanks[i % genericBlanks.length]);
        }
      }
    } else {
      for (let i = 0; i < blankCount; i++) {
        const sentence = cleanSentences[(i + 2) % cleanSentences.length] || `Kunnskap om ${displayTitle} gir viktig forståelse for fagområdet.`;
        const words = sentence.replace(/[,;:.()]/g, '').split(' ').filter(w => w.length > 4 && !w.startsWith('http'));
        const targetWord = words[Math.min(3, words.length - 1)] || 'viktig';
        
        blanks.push({
          sentence: sentence.replace(targetWord, '______'),
          blankWord: targetWord,
          correctWords: [targetWord],
          distractors: isEng ? ['incorrect', 'limited', 'random'] : ['feilaktig', 'begrenset', 'tilfeldig']
        });
      }
    }

    // 3. Generate Sorting
    const sorting = [];
    for (let i = 0; i < sortingCount; i++) {
      sorting.push({
        category: isNynorsk ? `Sentrale trekk ved ${displayTitle} (${i + 1})` : isEng ? `Core aspects of ${displayTitle} (${i + 1})` : `Sentrale trekk ved ${displayTitle} (${i + 1})`,
        items: isNynorsk
          ? ['Struktur og organisering', 'Historisk bakgrunn', 'Viktige prinsipp', 'Praktisk meining']
          : isEng
          ? ['Structure and organization', 'Historical background', 'Key principles', 'Practical significance']
          : ['Struktur og organisering', 'Historisk bakgrunn', 'Viktige prinsipper', 'Praktisk betydning']
      });
    }

    // 4. Generate Reflection Tasks
    const reflection = [];
    for (let i = 0; i < reflectionCount; i++) {
      let refText = '';
      if (extraInstructions && extraInstructions.length > 5) {
        refText = isNynorsk
          ? `Med fokus på "${extraInstructions}": Drøft korleis tematikken kring ${displayTitle} gjer seg gjeldande og kva for faglege konsekvensar dette har.`
          : isEng
          ? `With focus on "${extraInstructions}": Discuss the key perspectives surrounding ${displayTitle} and its broader implications.`
          : `Med fokus på "${extraInstructions}": Drøft hvordan tematikken rundt ${displayTitle} gjør seg gjeldende og hvilke faglige konsekvenser dette har.`;
      } else if (isEng) {
        refText = `Discuss the central societal, political, and institutional impacts of ${displayTitle}.`;
      } else if (isNynorsk) {
        refText = i === 0
          ? `Drøft dei sentrale samfunnsmessige og politiske konsekvensane av ${displayTitle}.`
          : `Gjer greie for kva for sentrale utfordringar og moglegheiter som er knytte til ${displayTitle}.`;
      } else {
        refText = i === 0
          ? `Drøft de sentrale samfunnsmessige og politiske konsekvensene av ${displayTitle}.`
          : `Gjør rede for hvilke sentrale utfordringer og muligheter som er knyttet til ${displayTitle}.`;
      }

      reflection.push({
        question: refText,
        maxPoints: 6,
        modelAnswer: isNynorsk
          ? `Eit godt svar gjer greie for hovudlinjene i ${displayTitle}, drøftar årsaker og konsekvensar, og syner god fagleg forståing.`
          : isEng
          ? `A strong response outlines the core principles of ${displayTitle}, analyzes causes and effects, and demonstrates solid subject understanding.`
          : `Et godt svar gjør rede for hovedlinjene i ${displayTitle}, drøfter årsaker og konsekvenser, og viser god faglig forståelse.`
      });
    }

    return {
      title: cleanTitle,
      language,
      extraAiInstructions: extraInstructions,
      mcqs,
      blanks,
      sorting,
      reflection
    };
  }

  const editingTasks = new Set();

  function renderGeneratedTasks(tasks) {
    generatedTasksList.innerHTML = '';
    let totalCount = 0;

    // 1. MCQs
    if (tasks.mcqs && Array.isArray(tasks.mcqs)) {
      tasks.mcqs.forEach((q, i) => {
        totalCount++;
        const key = `mcq-${i}`;
        const isEditing = editingTasks.has(key);
        const div = document.createElement('div');
        div.className = `task-item ${isEditing ? 'is-editing' : ''}`;

        let optionsHtml = '';
        if (isEditing) {
          optionsHtml = '<div class="task-edit-box">';
          optionsHtml += `<label style="margin-top: 4px;">Spørsmålstekst:</label>`;
          optionsHtml += `<textarea class="input-field-sm edit-mcq-question" data-idx="${i}" rows="2">${escapeHtml(q.question)}</textarea>`;
          optionsHtml += `<label style="margin-top: 6px;">Svaralternativer (velg radioknapp for riktig svar):</label>`;
          
          if (Array.isArray(q.options)) {
            q.options.forEach((opt, oIdx) => {
              const isCorrect = (typeof opt === 'object') ? opt.isCorrect : (oIdx === q.correctIndex);
              const optText = (typeof opt === 'object') ? opt.text : opt;
              optionsHtml += `
                <div class="option-edit-row">
                  <input type="radio" name="correct-mcq-${i}" value="${oIdx}" ${isCorrect ? 'checked' : ''} data-action="set-correct" data-mcq-idx="${i}" data-opt-idx="${oIdx}" title="Merk som riktig svar">
                  <input type="text" class="input-field-sm edit-mcq-opt" value="${escapeHtml(optText)}" data-mcq-idx="${i}" data-opt-idx="${oIdx}" placeholder="Alternativ ${oIdx + 1}">
                </div>
              `;
            });
          }
          optionsHtml += '</div>';
        } else {
          if (Array.isArray(q.options)) {
            optionsHtml = '<ul style="margin: 6px 0; padding-left: 18px; font-size: 11px; line-height: 1.5;">';
            q.options.forEach((opt, oIdx) => {
              const isCorrect = (typeof opt === 'object') ? opt.isCorrect : (oIdx === q.correctIndex);
              const optText = (typeof opt === 'object') ? opt.text : opt;
              optionsHtml += `<li style="${isCorrect ? 'color: #10b981; font-weight: 700;' : 'color: #94a3b8;'}">${isCorrect ? '✓ ' : '• '}${escapeHtml(optText)}</li>`;
            });
            optionsHtml += '</ul>';
          }
        }

        div.innerHTML = `
          <div class="task-header">
            <strong style="color: #38bdf8; font-size: 11px;">Flervalg #${i + 1}</strong>
            <div class="task-actions">
              ${isEditing 
                ? `<button type="button" class="btn-task-action btn-done" data-action="done-task" data-key="${key}">✓ Ferdig</button>` 
                : `<button type="button" class="btn-task-action" data-action="edit-task" data-key="${key}">✏️ Rediger</button>`
              }
              <button type="button" class="btn-task-action btn-delete" data-action="delete-task" data-type="mcqs" data-idx="${i}" title="Slett oppgave">🗑️</button>
            </div>
          </div>
          ${!isEditing ? `<p style="font-weight: 600; font-size: 12px; margin: 4px 0 6px 0; color: #f1f5f9;">${escapeHtml(q.question)}</p>` : ''}
          ${optionsHtml}
        `;
        generatedTasksList.appendChild(div);
      });
    }

    // 2. Blanks
    if (tasks.blanks && Array.isArray(tasks.blanks)) {
      tasks.blanks.forEach((b, i) => {
        totalCount++;
        const key = `blank-${i}`;
        const isEditing = editingTasks.has(key);
        const div = document.createElement('div');
        div.className = `task-item ${isEditing ? 'is-editing' : ''}`;

        const sentenceText = b.sentence || b.summary || '';
        const correctWord = b.blankWord || (Array.isArray(b.correctWords) ? b.correctWords.join(', ') : b.correctWords) || '';
        div.innerHTML = `
          <div class="task-header">
            <strong style="color: #a78bfa; font-size: 11px;">Fyll inn hull #${i + 1}</strong>
            <div class="task-actions">
              ${isEditing 
                ? `<button type="button" class="btn-task-action btn-done" data-action="done-task" data-key="${key}">✓ Ferdig</button>` 
                : `<button type="button" class="btn-task-action" data-action="edit-task" data-key="${key}">✏️ Rediger</button>`
              }
              <button type="button" class="btn-task-action btn-delete" data-action="delete-task" data-type="blanks" data-idx="${i}" title="Slett oppgave">🗑️</button>
            </div>
          </div>
          ${isEditing 
            ? `<div class="task-edit-box">
                <label>Setning (bruk ______ for hull):</label>
                <textarea class="input-field-sm edit-blank-sentence" data-idx="${i}" rows="2">${escapeHtml(sentenceText)}</textarea>
                <label style="margin-top: 4px;">Riktig ord som skal fylles inn:</label>
                <input type="text" class="input-field-sm edit-blank-word" data-idx="${i}" value="${escapeHtml(correctWord)}" placeholder="Fasit-ord">
               </div>`
            : `<p style="font-size: 12px; margin: 4px 0; color: #f1f5f9; line-height: 1.45;">${escapeHtml(sentenceText)}</p>
               ${correctWord ? `
               <div style="margin-top: 6px; padding: 4px 8px; background: rgba(167, 139, 250, 0.12); border: 1px solid rgba(167, 139, 250, 0.25); border-radius: 6px; font-size: 11px; color: #c4b5fd;">
                 <strong>Fasit / Riktig ord:</strong> <span style="font-weight: 700; color: #a78bfa;">${escapeHtml(correctWord)}</span>
               </div>` : ''}
              `
          }
        `;
        generatedTasksList.appendChild(div);
      });
    }

    // 3. Sorting
    if (tasks.sorting && Array.isArray(tasks.sorting)) {
      tasks.sorting.forEach((s, i) => {
        totalCount++;
        const key = `sorting-${i}`;
        const isEditing = editingTasks.has(key);
        const div = document.createElement('div');
        div.className = `task-item ${isEditing ? 'is-editing' : ''}`;

        const itemsStr = Array.isArray(s.items) ? s.items.join(', ') : (s.items || '');
        div.innerHTML = `
          <div class="task-header">
            <strong style="color: #fbbf24; font-size: 11px;">Sortering #${i + 1}</strong>
            <div class="task-actions">
              ${isEditing 
                ? `<button type="button" class="btn-task-action btn-done" data-action="done-task" data-key="${key}">✓ Ferdig</button>` 
                : `<button type="button" class="btn-task-action" data-action="edit-task" data-key="${key}">✏️ Rediger</button>`
              }
              <button type="button" class="btn-task-action btn-delete" data-action="delete-task" data-type="sorting" data-idx="${i}" title="Slett oppgave">🗑️</button>
            </div>
          </div>
          ${isEditing 
            ? `<div class="task-edit-box">
                <label>Kategori:</label>
                <input type="text" class="input-field-sm edit-sorting-cat" data-idx="${i}" value="${escapeHtml(s.category || '')}">
                <label style="margin-top: 4px;">Elementer (komma-separert):</label>
                <input type="text" class="input-field-sm edit-sorting-items" data-idx="${i}" value="${escapeHtml(itemsStr)}">
               </div>`
            : `<p style="font-size: 12px; margin: 4px 0; color: #f1f5f9;">Kategori: <strong>${escapeHtml(s.category || '')}</strong></p>
               <p style="font-size: 11px; color: #94a3b8; margin: 2px 0;">Elementer: ${escapeHtml(itemsStr)}</p>`
          }
        `;
        generatedTasksList.appendChild(div);
      });
    }

    // 4. Reflection
    if (tasks.reflection && Array.isArray(tasks.reflection)) {
      tasks.reflection.forEach((r, i) => {
        totalCount++;
        const key = `reflection-${i}`;
        const isEditing = editingTasks.has(key);
        const div = document.createElement('div');
        div.className = `task-item ${isEditing ? 'is-editing' : ''}`;

        div.innerHTML = `
          <div class="task-header">
            <strong style="color: #f43f5e; font-size: 11px;">Refleksjon #${i + 1} (${r.maxPoints || 6} poeng)</strong>
            <div class="task-actions">
              ${isEditing 
                ? `<button type="button" class="btn-task-action btn-done" data-action="done-task" data-key="${key}">✓ Ferdig</button>` 
                : `<button type="button" class="btn-task-action" data-action="edit-task" data-key="${key}">✏️ Rediger</button>`
              }
              <button type="button" class="btn-task-action btn-delete" data-action="delete-task" data-type="reflection" data-idx="${i}" title="Slett oppgave">🗑️</button>
            </div>
          </div>
          ${isEditing 
            ? `<div class="task-edit-box">
                <label>Refleksjonsspørsmål:</label>
                <textarea class="input-field-sm edit-reflection-q" data-idx="${i}" rows="2">${escapeHtml(r.question)}</textarea>
                <div style="display: flex; align-items: center; gap: 8px; margin-top: 4px;">
                  <label style="margin: 0;">Maks poeng:</label>
                  <input type="number" class="input-field-sm edit-reflection-pts" data-idx="${i}" value="${r.maxPoints || 6}" min="1" max="20" style="width: 60px;">
                </div>
               </div>`
            : `<p style="font-size: 12px; margin: 4px 0; color: #f1f5f9;">${escapeHtml(r.question)}</p>`
          }
        `;
        generatedTasksList.appendChild(div);
      });
    }

    if (totalCount === 0) {
      generatedTasksList.innerHTML = '<p class="muted-text" style="padding: 10px; text-align: center;">Ingen oppgaver i listen. Generer på nytt eller legg til.</p>';
    }

    taskSummaryBadge.textContent = `${totalCount} oppgaver`;
  }

  // Delegated Event Handlers for Edit, Done, Delete and Live Inputs
  generatedTasksList?.addEventListener('click', (e) => {
    const btn = e.target.closest('button[data-action]');
    if (!btn) return;

    const action = btn.dataset.action;
    if (action === 'delete-task') {
      const type = btn.dataset.type;
      const idx = parseInt(btn.dataset.idx, 10);
      if (generatedTasks && generatedTasks[type] && Array.isArray(generatedTasks[type])) {
        generatedTasks[type].splice(idx, 1);
        editingTasks.delete(`${type.replace(/s$/, '')}-${idx}`);
        renderGeneratedTasks(generatedTasks);
      }
    } else if (action === 'edit-task') {
      const key = btn.dataset.key;
      if (key) {
        editingTasks.add(key);
        renderGeneratedTasks(generatedTasks);
      }
    } else if (action === 'done-task') {
      const key = btn.dataset.key;
      if (key) {
        editingTasks.delete(key);
        renderGeneratedTasks(generatedTasks);
      }
    }
  });

  // Live input changes for edited fields
  generatedTasksList?.addEventListener('input', (e) => {
    const target = e.target;
    if (!generatedTasks) return;

    // MCQ Question
    if (target.classList.contains('edit-mcq-question')) {
      const idx = parseInt(target.dataset.idx, 10);
      if (generatedTasks.mcqs?.[idx]) {
        generatedTasks.mcqs[idx].question = target.value;
      }
    }
    // MCQ Option Text
    else if (target.classList.contains('edit-mcq-opt')) {
      const mcqIdx = parseInt(target.dataset.mcqIdx, 10);
      const optIdx = parseInt(target.dataset.optIdx, 10);
      if (generatedTasks.mcqs?.[mcqIdx]?.options?.[optIdx]) {
        if (typeof generatedTasks.mcqs[mcqIdx].options[optIdx] === 'object') {
          generatedTasks.mcqs[mcqIdx].options[optIdx].text = target.value;
        } else {
          generatedTasks.mcqs[mcqIdx].options[optIdx] = target.value;
        }
      }
    }
    // Blank Sentence
    else if (target.classList.contains('edit-blank-sentence')) {
      const idx = parseInt(target.dataset.idx, 10);
      if (generatedTasks.blanks?.[idx]) {
        generatedTasks.blanks[idx].sentence = target.value;
      }
    }
    // Sorting Category
    else if (target.classList.contains('edit-sorting-cat')) {
      const idx = parseInt(target.dataset.idx, 10);
      if (generatedTasks.sorting?.[idx]) {
        generatedTasks.sorting[idx].category = target.value;
      }
    }
    // Sorting Items
    else if (target.classList.contains('edit-sorting-items')) {
      const idx = parseInt(target.dataset.idx, 10);
      if (generatedTasks.sorting?.[idx]) {
        generatedTasks.sorting[idx].items = target.value.split(',').map(s => s.trim()).filter(Boolean);
      }
    }
    // Reflection Question
    else if (target.classList.contains('edit-reflection-q')) {
      const idx = parseInt(target.dataset.idx, 10);
      if (generatedTasks.reflection?.[idx]) {
        generatedTasks.reflection[idx].question = target.value;
      }
    }
    // Reflection Points
    else if (target.classList.contains('edit-reflection-pts')) {
      const idx = parseInt(target.dataset.idx, 10);
      if (generatedTasks.reflection?.[idx]) {
        generatedTasks.reflection[idx].maxPoints = parseInt(target.value, 10) || 6;
      }
    }
  });

  // Radio button change for correct MCQ answer
  generatedTasksList?.addEventListener('change', (e) => {
    const target = e.target;
    if (target.name?.startsWith('correct-mcq-') && target.dataset.action === 'set-correct') {
      const mcqIdx = parseInt(target.dataset.mcqIdx, 10);
      const correctOptIdx = parseInt(target.dataset.optIdx, 10);
      if (generatedTasks?.mcqs?.[mcqIdx]?.options) {
        generatedTasks.mcqs[mcqIdx].correctIndex = correctOptIdx;
        generatedTasks.mcqs[mcqIdx].options.forEach((opt, oIdx) => {
          if (typeof opt === 'object') {
            opt.isCorrect = (oIdx === correctOptIdx);
          }
        });
      }
    }
  });

  // 6. Publish to Curiosa Webapp & Open in Topic Editor
  btnPublishTopic?.addEventListener('click', async () => {
    btnPublishTopic.disabled = true;
    btnPublishTopic.textContent = 'Bygger pensum-PDF og lagrer...';

    const extraInstructions = document.getElementById('extra-ai-instructions')?.value.trim() || '';
    const selectedLanguage = document.getElementById('topic-language')?.value || 'Norsk';
    const rawTitle = topicTitleInput.value.trim() || 'Nytt tema fra nettside';
    const textContent = sourceTextPreview.value.trim();

    // Automatically generate a real, clean, beautifully structured PDF without web banners
    let generatedPdfData = null;
    try {
      const pdfRes = await generateStructuredPdf(rawTitle, textContent, activeTabContent?.url || '', {
        includeImages: true,
        includeSourceLink: true,
        aiClean: true,
        language: selectedLanguage
      });
      if (pdfRes && pdfRes.base64) {
        generatedPdfData = {
          name: `${rawTitle}.pdf`,
          data: pdfRes.base64,
          size: pdfRes.blob?.size || 0,
          totalPages: pdfRes.totalPages || 1,
          sourceUrl: activeTabContent?.url || ''
        };
      }
    } catch (pdfErr) {
      console.warn('[CURIOSA-EXT] Could not auto-generate PDF for topic:', pdfErr);
    }

    const payload = {
      title: rawTitle,
      primarySubject: document.getElementById('topic-subject').value,
      isPractice: document.getElementById('topic-mode').value === 'practice',
      language: selectedLanguage,
      allowedClasses: Array.from(selectedClasses),
      extraAiInstructions: extraInstructions,
      tasks: generatedTasks,
      content: textContent,
      sourceUrl: activeTabContent?.url || '',
      fagstoffPdfs: generatedPdfData ? [generatedPdfData] : []
    };

    chrome.storage.local.set({ pendingImportTopic: payload }, () => {
      setTimeout(() => {
        btnPublishTopic.textContent = 'Åpner redigering i Curiosa...';
        btnPublishTopic.style.background = '#10b981';
        
        chrome.tabs.create({
          url: 'https://curiosa.no/#/admin?tab=topics'
        });
      }, 600);
    });
  });

  // 7. Preview and Save Structured Fagstoff PDF
  const fagstoffPreviewContainer = document.getElementById('fagstoff-preview-container');
  const btnConfirmSaveFagstoff = document.getElementById('btn-confirm-save-fagstoff');
  const btnOpenPdfPreview = document.getElementById('btn-open-pdf-preview');
  let currentGeneratedPdfBlob = null;
  let currentGeneratedPdfBase64 = null;
  let currentGeneratedPages = 1;

  // Image loader for PDF embedding with full CORS support
  async function loadImageAsDataUrl(imgSrc) {
    if (!imgSrc) return null;
    try {
      const resp = await fetch(imgSrc);
      if (!resp.ok) return null;
      const blob = await resp.blob();
      return new Promise((resolve) => {
        const reader = new FileReader();
        reader.onloadend = () => {
          const dataUrl = reader.result;
          const img = new Image();
          img.onload = () => {
            resolve({
              dataUrl: dataUrl,
              width: img.naturalWidth || img.width || 400,
              height: img.naturalHeight || img.height || 300
            });
          };
          img.onerror = () => resolve({ dataUrl, width: 400, height: 300 });
          img.src = dataUrl;
        };
        reader.onerror = () => resolve(null);
        reader.readAsDataURL(blob);
      });
    } catch (err) {
      console.warn('[CURIOSA-PDF] Image fetch failed:', err);
      return null;
    }
  }

  // Sanitizes text for jsPDF WinAnsi / Latin-1 encoding while preserving Norwegian æ, ø, å, Æ, Ø, Å and standard accents
  function sanitizeForPdf(str) {
    if (!str) return '';
    return str
      .replace(/[\u00A0\u1680\u2000-\u200B\u202F\u205F\u3000\uFEFF]/g, ' ') // Non-breaking & unicode spaces
      .replace(/[\u2018\u2019]/g, "'") // Smart single quotes
      .replace(/[\u201C\u201D]/g, '"') // Smart double quotes
      .replace(/[\u2013\u2014]/g, '-') // En/em dashes
      .replace(/[\u00AB\u00BB]/g, '"') // « » guillemets to double quotes
      .replace(/\u00AD/g, '') // Soft hyphens
      // Map non-Latin Sanskrit / transliteration unicode diacritics to ascii
      .replace(/[āáǎà]/g, 'a').replace(/[ĀÁǍÀ]/g, 'A')
      .replace(/[ēéěè]/g, 'e').replace(/[ĒÉĚÈ]/g, 'E')
      .replace(/[īíǐì]/g, 'i').replace(/[ĪÍǏÌ]/g, 'I')
      .replace(/[ōóǒò]/g, 'o').replace(/[ŌÓǑÒ]/g, 'O')
      .replace(/[ūúǔù]/g, 'u').replace(/[ŪÚǓÙ]/g, 'U')
      .replace(/[ñṇṅ]/g, 'n').replace(/[ÑṆṄ]/g, 'N')
      .replace(/[śṣ]/g, 's').replace(/[ŚṢ]/g, 'S')
      .replace(/[ṭ]/g, 't').replace(/[Ṭ]/g, 'T')
      .replace(/[ḍ]/g, 'd').replace(/[Ḍ]/g, 'D')
      .replace(/[ṛ]/g, 'r').replace(/[Ṛ]/g, 'R')
      .replace(/[ḷ]/g, 'l').replace(/[Ḷ]/g, 'L')
      .replace(/[^\x20-\x7E\xA0-\xFF\n\r\t]/g, ' ') // Safe printable Latin-1 (includes æ, ø, å, etc.)
      .replace(/[ ]{2,}/g, ' ') // Collapse extra spaces
      .trim();
  }

  // AI Text Cleaner & Markdown Structurer for PDF
  function cleanAndStructureText(rawText) {
    if (!rawText) return [];

    const rawLines = rawText.split(/\r?\n/);
    const cleanedBlocks = [];
    let currentParagraph = [];

    function flushParagraph() {
      if (currentParagraph.length > 0) {
        const paraText = currentParagraph.join(' ')
          .replace(/\*\*(.*?)\*\*/g, '$1') // Strip bold **
          .replace(/\*(.*?)\*/g, '$1') // Strip italic *
          .replace(/__(.*?)__/g, '$1')
          .replace(/_(.*?)_/g, '$1')
          .trim();
        if (paraText.length > 5) {
          cleanedBlocks.push({ type: 'p', text: paraText });
        }
        currentParagraph = [];
      }
    }

    for (let i = 0; i < rawLines.length; i++) {
      const line = rawLines[i].trim();
      if (!line) {
        flushParagraph();
        continue;
      }

      // 1. Heading (H1, H2, H3, H4)
      if (/^#{1,6}\s+/.test(line)) {
        flushParagraph();
        const level = (line.match(/^#+/) || ['##'])[0].length;
        const headingText = line.replace(/^#{1,6}\s+/, '')
          .replace(/\*\*/g, '')
          .replace(/\*/g, '')
          .trim();
        if (headingText) {
          cleanedBlocks.push({ 
            type: level <= 2 ? 'h2' : 'h3', 
            text: headingText 
          });
        }
        continue;
      }

      // 2. Bullet lists (-, *, •)
      if (/^[\*\-•]\s+/.test(line)) {
        flushParagraph();
        const listItemText = line.replace(/^[\*\-•]\s+/, '')
          .replace(/\*\*(.*?)\*\*/g, '$1')
          .replace(/\*(.*?)\*/g, '$1')
          .trim();
        if (listItemText) {
          cleanedBlocks.push({ type: 'li', text: listItemText });
        }
        continue;
      }

      // 3. Inline bullet list detection (e.g. "* Item 1 * Item 2")
      if (line.includes(' * ') || line.includes(' • ')) {
        flushParagraph();
        const parts = line.split(/(?=\s+[\*•]\s+)/).map(p => p.replace(/^[\*•\s]+/, '').trim()).filter(Boolean);
        parts.forEach(part => {
          cleanedBlocks.push({ 
            type: 'li', 
            text: part.replace(/\*\*(.*?)\*\*/g, '$1').replace(/\*(.*?)\*/g, '$1').trim() 
          });
        });
        continue;
      }

      // Standard text line for paragraph
      currentParagraph.push(line);
    }

    flushParagraph();
    return cleanedBlocks;
  }

  async function generateStructuredPdf(title, text, url, options = {}) {
    const jsPdfConstructor = window.jspdf?.jsPDF || window.jsPDF || (typeof jsPDF !== 'undefined' ? jsPDF : null);
    if (!jsPdfConstructor) {
      console.error('[CURIOSA-EXT] jsPDF library not found on window.jspdf or window.jsPDF');
      return null;
    }

    const { includeImages = true, includeSourceLink = true, aiClean = true, language = 'Norsk' } = options;

    let textToUse = text;
    let titleToUse = title;
    const isEng = language === 'Engelsk';
    const isSourceEnglish = /\b(the|and|is|was|in|of|that|with|for|as|on|by|at|from|which)\b/i.test(text.substring(0, 500));
    const needsTranslation = (isSourceEnglish && (language === 'Norsk' || language === 'Nynorsk' || language === 'Spansk' || language === 'Fransk' || language === 'Tysk')) ||
                             (!isSourceEnglish && isEng);

    if (needsTranslation) {
      try {
        const response = await fetch('https://europe-west1-voxkunnskapeuropa.cloudfunctions.net/generateExtensionTextTranslation', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            text,
            title,
            targetLanguage: language
          })
        });

        if (response.ok) {
          const resData = await response.json();
          if (resData.success && resData.translatedText) {
            textToUse = resData.translatedText;
            titleToUse = formatGrammaticalTitle(title, language === 'Nynorsk');
          }
        }
      } catch (directTransErr) {
        console.warn('[CURIOSA-EXT] Direct translation fetch error, trying open tab bridge:', directTransErr);
      }

      if (textToUse === text) {
        try {
          const tabs = await new Promise((resolve) => {
            chrome.tabs.query({}, (allTabs) => {
              const curiosaTabs = (allTabs || []).filter(t => 
                t.url && (
                  t.url.includes('curiosa.no') ||
                  t.url.includes('voxkunnskapeuropa.web.app') ||
                  t.url.includes('localhost')
                )
              );
              resolve(curiosaTabs);
            });
          });

          if (tabs && tabs.length > 0) {
            for (const tab of tabs) {
              if (tab.id) {
                const res = await new Promise((resolve) => {
                  chrome.tabs.sendMessage(tab.id, {
                    type: 'EXECUTE_AI_TEXT_TRANSLATION',
                    payload: {
                      text,
                      title,
                      targetLanguage: language
                    }
                  }, (response) => {
                    if (chrome.runtime.lastError || !response) resolve(null);
                    else resolve(response);
                  });
                });

                if (res && res.success && res.translatedText) {
                  textToUse = res.translatedText;
                  titleToUse = formatGrammaticalTitle(title, language === 'Nynorsk');
                  break;
                }
              }
            }
          }
        } catch (transErr) {
          console.warn('[CURIOSA-EXT] Live text translation skipped:', transErr);
        }
      }
    }

    const doc = new jsPdfConstructor({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4'
    });

    const pageWidth = 210;
    const pageHeight = 297;
    const margin = 20;
    const maxLineWidth = pageWidth - (margin * 2);
    let y = margin;

    const safeTitle = sanitizeForPdf(titleToUse);

    // Header / Brand Top Bar (Compact & Sleek)
    doc.setFillColor(16, 185, 129); // Curiosa Emerald
    doc.rect(margin, y, 3.5, 10, 'F');
    
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(14);
    doc.setTextColor(15, 23, 42); // Dark slate
    doc.text('CURIOSA PENSUM', margin + 6, y + 4.5);
    
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(100, 116, 139);
    doc.text(`Kildemateriale • Generert ${new Date().toLocaleDateString('no-NO')}`, margin + 6, y + 8.5);
    
    y += 14;
    doc.setDrawColor(226, 232, 240);
    doc.line(margin, y, pageWidth - margin, y);
    y += 6;

    // Embed article image if available and requested (compact & balanced layout)
    if (includeImages && activeTabContent?.images && activeTabContent.images.length > 0) {
      try {
        const firstImg = activeTabContent.images[0];
        const loaded = await loadImageAsDataUrl(firstImg.src);
        if (loaded && loaded.dataUrl) {
          const imgAspect = loaded.height / loaded.width;
          let displayWidth = Math.min(maxLineWidth, 95);
          let displayHeight = displayWidth * imgAspect;
          
          // Cap maximum image height to 55mm so text flows naturally on page 1
          if (displayHeight > 55) {
            displayHeight = 55;
            displayWidth = displayHeight / imgAspect;
          }

          if (y + displayHeight > pageHeight - 30) {
            doc.addPage();
            y = margin;
          }

          doc.addImage(loaded.dataUrl, 'JPEG', margin, y, displayWidth, displayHeight);
          y += displayHeight + 3;

          if (firstImg.alt && firstImg.alt !== 'Artikkelbilde') {
            doc.setFont('helvetica', 'italic');
            doc.setFontSize(8);
            doc.setTextColor(148, 163, 184);
            const safeAlt = sanitizeForPdf(firstImg.alt);
            doc.text(safeAlt.slice(0, 80), margin, y);
            y += 5;
          }
          y += 3;
        }
      } catch (imgErr) {
        console.warn('Could not embed image:', imgErr);
      }
    }

    // Process structured paragraphs and headings
    const blocks = aiClean ? cleanAndStructureText(textToUse) : textToUse.split('\n').map(t => ({ type: 'p', text: sanitizeForPdf(t) }));

    for (const block of blocks) {
      const trimmed = sanitizeForPdf(block.text);
      if (!trimmed) continue;

      if (block.type === 'h2' || block.type === 'h') {
        // Prevent orphan headings: require at least 50mm space remaining on page
        if (y > pageHeight - 50) {
          doc.addPage();
          y = margin;
        }
        y += 4;
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(13);
        doc.setTextColor(16, 185, 129); // Emerald heading
        const headingLines = doc.splitTextToSize(trimmed, maxLineWidth);
        doc.text(headingLines, margin, y);
        y += (headingLines.length * 6.5) + 3;
      } else if (block.type === 'h3') {
        // Subheadings
        if (y > pageHeight - 40) {
          doc.addPage();
          y = margin;
        }
        y += 3;
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(11);
        doc.setTextColor(30, 41, 59); // Slate 800
        const headingLines = doc.splitTextToSize(trimmed, maxLineWidth);
        doc.text(headingLines, margin, y);
        y += (headingLines.length * 5.5) + 2;
      } else if (block.type === 'li') {
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(10);
        doc.setTextColor(51, 65, 85);
        const bulletText = `• ${trimmed}`;
        const textLines = doc.splitTextToSize(bulletText, maxLineWidth - 6);
        const blockHeight = textLines.length * 5.2;

        if (y + blockHeight > pageHeight - margin) {
          doc.addPage();
          y = margin;
        }

        doc.text(textLines, margin + 4, y);
        y += blockHeight + 2;
      } else {
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(10);
        doc.setTextColor(51, 65, 85);
        const textLines = doc.splitTextToSize(trimmed, maxLineWidth);
        const blockHeight = textLines.length * 5.2;

        if (y + blockHeight > pageHeight - margin) {
          doc.addPage();
          y = margin;
        }

        doc.text(textLines, margin, y);
        y += blockHeight + 4; // Distinct paragraph spacing
      }
    }

    // Clickable Source Link placed cleanly at the VERY END of the PDF
    if (includeSourceLink && url) {
      if (y > pageHeight - 25) {
        doc.addPage();
        y = margin;
      }
      y += 4;
      doc.setDrawColor(226, 232, 240);
      doc.line(margin, y, pageWidth - margin, y);
      y += 5;
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8.5);
      doc.setTextColor(37, 99, 235); // Blue
      const displayUrl = url.length > 80 ? url.slice(0, 77) + '...' : url;
      doc.textWithLink(`Kilde: ${displayUrl}`, margin, y, { url: url });
      y += 6;
    }

    // Add footer page numbers
    const totalPages = doc.internal.getNumberOfPages();
    for (let i = 1; i <= totalPages; i++) {
      doc.setPage(i);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8.5);
      doc.setTextColor(148, 163, 184);
      doc.text(`Curiosa • Side ${i} av ${totalPages}`, pageWidth - margin - 35, pageHeight - 8);
    }

    const blob = doc.output('blob');
    const base64 = doc.output('datauristring').split(',')[1];
    return { blob, base64, totalPages };
  }

  btnSaveFagstoff?.addEventListener('click', async () => {
    const selectedLanguage = document.getElementById('topic-language')?.value || 'Norsk';
    const rawFagstoffTitle = fagstoffTitleInput?.value.trim() || activeTabContent?.title || 'Fagstoff-dokument';
    const textContent = sourceTextPreview.value.trim();
    if (!textContent || textContent.length < 30) {
      alert('Kildeteksten må inneholde minst 30 tegn for å lage en Fagstoff-PDF.');
      return;
    }

    btnSaveFagstoff.disabled = true;
    btnSaveFagstoff.innerHTML = '<span>Vasker tekst & bygger PDF...</span>';

    const includeImages = document.getElementById('chk-fagstoff-images')?.checked ?? true;
    const includeSourceLink = document.getElementById('chk-fagstoff-source-link')?.checked ?? true;
    const aiClean = document.getElementById('chk-fagstoff-ai-clean')?.checked ?? true;

    const pdfRes = await generateStructuredPdf(rawFagstoffTitle, textContent, activeTabContent?.url || '', {
      includeImages,
      includeSourceLink,
      aiClean,
      language: selectedLanguage
    });

    if (pdfRes) {
      currentGeneratedPdfBlob = pdfRes.blob;
      currentGeneratedPdfBase64 = pdfRes.base64;
      currentGeneratedPages = pdfRes.totalPages;
    }

    const wordsCount = textContent.split(/\s+/).filter(Boolean).length;
    const targetTopicId = fagstoffTargetTopic?.value || null;
    const selectedTopicText = fagstoffTargetTopic?.options[fagstoffTargetTopic.selectedIndex]?.text || '';
    const selectedClasses = Array.from(document.querySelectorAll('#fagstoff-classes-selector .class-pill.selected')).map(p => p.textContent.trim().toUpperCase());

    // Update preview details
    const previewHeading = document.getElementById('pdf-preview-heading');
    const previewPages = document.getElementById('pdf-preview-pages');
    const previewWords = document.getElementById('pdf-preview-words');
    const previewTarget = document.getElementById('pdf-preview-target');
    const previewExcerpt = document.getElementById('pdf-preview-excerpt');

    if (previewHeading) previewHeading.textContent = fagstoffTitle.endsWith('.pdf') ? fagstoffTitle : `${fagstoffTitle}.pdf`;
    if (previewPages) previewPages.textContent = `Sider: ${currentGeneratedPages} ${currentGeneratedPages === 1 ? 'side' : 'sider'}`;
    if (previewWords) previewWords.textContent = `~${wordsCount} ord`;
    
    if (previewTarget) {
      if (targetTopicId) {
        previewTarget.textContent = `Tilknyttes: ${selectedTopicText}`;
      } else {
        const classInfo = selectedClasses.length > 0 ? ` for klasse(r) ${selectedClasses.join(', ')}` : ' for alle klasser';
        previewTarget.textContent = `Mottaker: Frittstående pensum i biblioteket${classInfo}`;
      }
    }

    if (previewExcerpt) {
      previewExcerpt.textContent = textContent.slice(0, 320) + (textContent.length > 320 ? '...' : '');
    }

    btnSaveFagstoff.disabled = false;
    btnSaveFagstoff.innerHTML = '<span>Oppdater PDF</span>';

    if (fagstoffPreviewContainer) {
      fagstoffPreviewContainer.classList.remove('hidden');
      setTimeout(() => {
        fagstoffPreviewContainer.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      }, 50);
    }
  });

  btnOpenPdfPreview?.addEventListener('click', async () => {
    btnOpenPdfPreview.innerHTML = '<span>Laster forhåndsvisning...</span>';
    
    const fagstoffTitle = fagstoffTitleInput?.value.trim() || activeTabContent?.title || 'Fagstoff-dokument';
    const textContent = sourceTextPreview.value.trim();
    const includeImages = document.getElementById('chk-fagstoff-images')?.checked ?? true;
    const includeSourceLink = document.getElementById('chk-fagstoff-source-link')?.checked ?? true;
    const aiClean = document.getElementById('chk-fagstoff-ai-clean')?.checked ?? true;

    if (!currentGeneratedPdfBase64) {
      const pdfRes = await generateStructuredPdf(fagstoffTitle, textContent, activeTabContent?.url || '', {
        includeImages,
        includeSourceLink,
        aiClean
      });

      if (pdfRes) {
        currentGeneratedPdfBlob = pdfRes.blob;
        currentGeneratedPdfBase64 = pdfRes.base64;
        currentGeneratedPages = pdfRes.totalPages;
      }
    }

    if (currentGeneratedPdfBase64) {
      chrome.storage.local.set({ previewPdfData: currentGeneratedPdfBase64 }, () => {
        chrome.tabs.create({ url: chrome.runtime.getURL('preview.html') });
      });
    }

    btnOpenPdfPreview.innerHTML = '<span>Åpne full PDF-forhåndsvisning i ny fane</span>';
  });

  btnConfirmSaveFagstoff?.addEventListener('click', async () => {
    btnConfirmSaveFagstoff.disabled = true;
    btnConfirmSaveFagstoff.textContent = 'Forbereder og lagrer til Curiosa...';

    const fagstoffTitle = fagstoffTitleInput?.value.trim() || activeTabContent?.title || 'Fagstoff-dokument';
    const textContent = sourceTextPreview.value.trim();
    const cleanFileName = fagstoffTitle.endsWith('.pdf') ? fagstoffTitle : `${fagstoffTitle}.pdf`;
    const fagstoffClasses = Array.from(document.querySelectorAll('#fagstoff-classes-selector .class-pill.selected')).map(p => p.textContent.trim().toUpperCase());
    const includeImages = document.getElementById('chk-fagstoff-images')?.checked ?? true;
    const includeSourceLink = document.getElementById('chk-fagstoff-source-link')?.checked ?? true;
    const aiClean = document.getElementById('chk-fagstoff-ai-clean')?.checked ?? true;

    if (!currentGeneratedPdfBase64) {
      const pdfRes = await generateStructuredPdf(fagstoffTitle, textContent, activeTabContent?.url || '', {
        includeImages,
        includeSourceLink,
        aiClean
      });
      if (pdfRes) {
        currentGeneratedPdfBlob = pdfRes.blob;
        currentGeneratedPdfBase64 = pdfRes.base64;
        currentGeneratedPages = pdfRes.totalPages;
      }
    }

    const targetTopicId = fagstoffTargetTopic?.value || null;

    if (!targetTopicId) {
      btnConfirmSaveFagstoff.disabled = false;
      btnConfirmSaveFagstoff.textContent = 'Lagre PDF til valgt tema';
      const feedback = document.getElementById('save-feedback-status');
      if (feedback) {
        feedback.style.display = 'block';
        feedback.style.color = '#f87171';
        feedback.textContent = '⚠️ Vennligst velg hvilket tema PDF-en skal legges til ovenfor.';
      }
      fagstoffTargetTopic?.focus();
      return;
    }

    const payload = {
      title: fagstoffTitle.replace(/\.pdf$/i, ''),
      targetTopicId: targetTopicId,
      allowedClasses: fagstoffClasses,
      content: textContent,
      sourceUrl: activeTabContent?.url || '',
      includeImages,
      includeSourceLink,
      aiClean,
      fagstoffPdfs: [
        {
          name: cleanFileName,
          data: currentGeneratedPdfBase64,
          size: currentGeneratedPdfBlob ? currentGeneratedPdfBlob.size : 0,
          totalPages: currentGeneratedPages,
          url: activeTabContent?.url || '',
          targetTopicId: targetTopicId,
          includeImages,
          includeSourceLink,
          isVisibleToStudents: true,
          addedAt: new Date().toISOString()
        }
      ]
    };

    chrome.storage.local.set({ pendingImportTopic: payload }, () => {
      // Find open Curiosa tabs or open a silent background tab to complete save
      chrome.tabs.query({ url: ['https://curiosa.no/*', 'https://voxkunnskapeuropa.web.app/*', 'http://localhost:*/*'] }, (tabs) => {
        if (tabs && tabs.length > 0) {
          tabs.forEach(tab => {
            if (tab.id) {
              chrome.tabs.sendMessage(tab.id, { type: 'TRIGGER_IMPORT_NOW' }, () => {
                if (chrome.runtime.lastError) {
                  // Safe ignore
                }
              });
            }
          });
        } else {
          // Open silent background tab (active: false) so user stays on current webpage
          chrome.tabs.create({
            url: 'https://curiosa.no/#/admin?tab=topics',
            active: false
          });
        }
      });

      const feedback = document.getElementById('save-feedback-status');
      btnConfirmSaveFagstoff.disabled = false;
      btnConfirmSaveFagstoff.textContent = 'PDF lagret til temaet!';
      btnConfirmSaveFagstoff.style.background = '#10b981';

      if (feedback) {
        feedback.style.display = 'block';
        feedback.style.color = '#10b981';
        feedback.textContent = 'Lagt til under Fagstoff i det valgte temaet i Curiosa!';
      }

      setTimeout(() => {
        btnConfirmSaveFagstoff.textContent = 'Lagre PDF til valgt tema';
        btnConfirmSaveFagstoff.style.background = '';
        if (feedback) feedback.style.display = 'none';
      }, 3500);
    });
  });

  // 8. Student Companion Chat
  document.querySelectorAll('.chip-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const prompt = btn.getAttribute('data-prompt');
      sendChatMessage(prompt);
    });
  });

  btnChatSend?.addEventListener('click', () => {
    const text = chatInput.value.trim();
    if (text) {
      sendChatMessage(text);
      chatInput.value = '';
    }
  });

  chatInput?.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      const text = chatInput.value.trim();
      if (text) {
        sendChatMessage(text);
        chatInput.value = '';
      }
    }
  });

  function sendChatMessage(userText) {
    const userMsg = document.createElement('div');
    userMsg.className = 'chat-msg user-msg';
    userMsg.innerHTML = `<p>${escapeHtml(userText)}</p>`;
    chatMessages.appendChild(userMsg);
    chatMessages.scrollTop = chatMessages.scrollHeight;

    const aiMsg = document.createElement('div');
    aiMsg.className = 'chat-msg ai-msg';
    aiMsg.innerHTML = `<p>Tenker...</p>`;
    chatMessages.appendChild(aiMsg);
    chatMessages.scrollTop = chatMessages.scrollHeight;

    setTimeout(() => {
      let reply = `Her er en oppsummering av det viktigste fra siden:\n\n1. **Kjerneidé:** Teksten belyser sentrale faglige prinsipper og kildebruk.\n2. **Viktig begrep:** Kildekritisk refleksjon er avgjørende for å trekke pålitelige konklusjoner.\n3. **Hva du bør huske:** Bruk primærkilder når du begrunner dine svar i skoleoppgaver.`;
      if (userText.toLowerCase().includes('enkel')) {
        reply = `Kort forklart: Teksten handler om hvordan vi kan finne ut hva som er sant og viktig når vi leser tekster på nett og i bøker.`;
      } else if (userText.toLowerCase().includes('test')) {
        reply = `Her er et kontrollspørsmål til deg:\n\n*Hva er forskjellen på en primærkilde og en sekundærkilde ifølge teksten?*\n\nPrøv å svare meg med dine egne ord!`;
      }

      aiMsg.innerHTML = `<p>${reply.replace(/\n/g, '<br>')}</p>`;
      chatMessages.scrollTop = chatMessages.scrollHeight;
    }, 800);
  }

  function escapeHtml(str) {
    return (str || '').replace(/[&<>"']/g, function(m) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[m];
    });
  }

  // Run on load
  initAuth();
  fetchCurrentPageContent();
});
