// Curiosa Skoleassistent - Universell Lese- og Skrivestøtte Content Script
// Kjører på alle nettsider for elever med aktivert lesestøtte

(function() {
  let activePopup = null;
  let isSpeaking = false;

  // Check if feature is enabled in local storage
  async function isHelperEnabled() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['curiosaAuth'], (data) => {
        // Active if logged in as student or explicitly enabled
        const auth = data?.curiosaAuth;
        if (!auth) {
          resolve(true); // Default enabled for demo/testing
          return;
        }
        resolve(true);
      });
    });
  }

  // Handle double click on text
  document.addEventListener('dblclick', async (e) => {
    const target = e.target;
    if (!target || target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable) {
      return;
    }

    if (target.closest('.curiosa-synonym-popup')) {
      return;
    }

    const enabled = await isHelperEnabled();
    if (!enabled) return;

    const selection = window.getSelection();
    let word = selection?.toString()?.trim();
    if (!word) return;

    // Filter valid word
    word = word.replace(/^[.,/#!$%^&*;:{}=\-_`~()]+|[.,/#!$%^&*;:{}=\-_`~()]+$/g, '');
    if (word.length < 2 || word.length > 30 || word.includes(' ') || /\d/.test(word)) return;

    // Position popup near selection
    const range = selection.getRangeAt(0);
    const rect = range.getBoundingClientRect();
    const x = Math.min(window.innerWidth - 320, Math.max(10, rect.left + window.scrollX - 20));
    const y = rect.bottom + window.scrollY + 8;

    showSynonymPopup(word, x, y);
  });

  // Remove popup on click outside or escape
  document.addEventListener('mousedown', (e) => {
    if (activePopup && !activePopup.contains(e.target)) {
      closePopup();
    }
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && activePopup) {
      closePopup();
    }
  });

  function closePopup() {
    if (window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }
    isSpeaking = false;
    if (activePopup) {
      activePopup.remove();
      activePopup = null;
    }
  }

  async function showSynonymPopup(word, x, y) {
    closePopup();

    const container = document.createElement('div');
    container.className = 'curiosa-synonym-popup';
    container.style.left = `${x}px`;
    container.style.top = `${y}px`;

    container.innerHTML = `
      <div class="curiosa-card">
        <div class="curiosa-header">
          <div class="curiosa-title-box">
            <span class="curiosa-icon" style="font-size: 11px; font-weight: 800; color: #10b981;">[ORDBOK]</span>
            <strong class="curiosa-word">${escapeHtml(word)}</strong>
          </div>
          <div class="curiosa-actions">
            <button class="curiosa-tts-btn" title="Les opp" style="font-size: 10px; font-weight: 800;">LYD</button>
            <button class="curiosa-close-btn" title="Lukk">X</button>
          </div>
        </div>
        <div class="curiosa-body">
          <div class="curiosa-loader">Henter synonymer og forklaring...</div>
        </div>
        <div class="curiosa-footer">
          <span>Curiosa Lese- og skrivestotte</span>
        </div>
      </div>
    `;

    document.body.appendChild(container);
    activePopup = container;

    container.querySelector('.curiosa-close-btn').addEventListener('click', closePopup);
    const ttsBtn = container.querySelector('.curiosa-tts-btn');

    // Fetch explanation & synonyms via dictionary / AI fallback
    try {
      const data = await fetchSynonymData(word);
      renderPopupContent(container, word, data);
      
      ttsBtn.addEventListener('click', () => {
        speakWord(word, data, ttsBtn);
      });
    } catch (err) {
      container.querySelector('.curiosa-body').innerHTML = `
        <div class="curiosa-error">Kunne ikke hente ordforklaring akkurat nå.</div>
      `;
    }
  }

  function renderPopupContent(container, word, data) {
    const body = container.querySelector('.curiosa-body');
    const synonymsHtml = (data.synonyms || []).slice(0, 5).map(s => 
      `<span class="curiosa-pill">${escapeHtml(s)}</span>`
    ).join(' ');

    body.innerHTML = `
      ${data.explanation ? `<p class="curiosa-explanation">${escapeHtml(data.explanation)}</p>` : ''}
      ${synonymsHtml ? `
        <div class="curiosa-synonyms-section">
          <span class="curiosa-sublabel">Synonymer:</span>
          <div class="curiosa-pills">${synonymsHtml}</div>
        </div>
      ` : '<p class="curiosa-muted">Ingen synonymer funnet.</p>'}
    `;
  }

  function speakWord(word, data, button) {
    if (!window.speechSynthesis) return;

    if (isSpeaking) {
      window.speechSynthesis.cancel();
      isSpeaking = false;
      button.textContent = '🔊';
      return;
    }

    const textToSpeak = `${word}. ${data.synonyms?.length ? 'Synonymer: ' + data.synonyms.slice(0, 4).join(', ') + '.' : ''} ${data.explanation || ''}`;
    const utterance = new SpeechSynthesisUtterance(textToSpeak);
    utterance.lang = 'nb-NO';
    utterance.rate = 0.9;

    const voices = window.speechSynthesis.getVoices();
    const norwegianVoice = voices.find(v => v.lang.startsWith('nb') || v.lang.startsWith('no')) || voices[0];
    if (norwegianVoice) utterance.voice = norwegianVoice;

    utterance.onstart = () => {
      isSpeaking = true;
      button.textContent = '⏹️';
    };
    utterance.onend = () => {
      isSpeaking = false;
      button.textContent = '🔊';
    };
    utterance.onerror = () => {
      isSpeaking = false;
      button.textContent = '🔊';
    };

    window.speechSynthesis.speak(utterance);
  }

  // Fast AI-powered synonym and definition lookup via Curiosa Cloud Function
  async function fetchSynonymData(word) {
    const cleanWord = (word || '').trim();
    if (!cleanWord) return { explanation: '', synonyms: [] };

    try {
      const response = await fetch(`https://europe-west1-voxkunnskapeuropa.cloudfunctions.net/generateExtensionSynonyms?word=${encodeURIComponent(cleanWord)}`);
      if (response.ok) {
        const json = await response.json();
        if (json && json.success && json.data) {
          return {
            explanation: json.data.explanation || `Ordforklaring for «${word}».`,
            synonyms: Array.isArray(json.data.synonyms) ? json.data.synonyms : []
          };
        }
      }
    } catch (e) {
      console.warn('[CURIOSA-EXT] Synonym API fetch error:', e);
    }

    // Fallback if network fails
    return {
      explanation: `Ordforklaring for «${word}».`,
      synonyms: []
    };
  }

  function escapeHtml(str) {
    return (str || '').replace(/[&<>"']/g, function(m) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[m];
    });
  }
})();
