chrome.storage.local.get(['previewPdfData'], (res) => {
  const loading = document.getElementById('loading');
  const viewer = document.getElementById('pdf-viewer');
  if (res && res.previewPdfData) {
    try {
      const byteCharacters = atob(res.previewPdfData);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: 'application/pdf' });
      const blobUrl = URL.createObjectURL(blob);
      
      if (loading) loading.style.display = 'none';
      if (viewer) {
        viewer.style.display = 'block';
        viewer.src = blobUrl;
      }
    } catch (e) {
      if (loading) loading.textContent = 'Feil ved innlasting av PDF: ' + e.message;
    }
  } else {
    if (loading) loading.textContent = 'Ingen PDF-data funnet. Generer PDF i sidepanelet først.';
  }
});
