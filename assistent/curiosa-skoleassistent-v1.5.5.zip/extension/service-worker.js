// Curiosa Skoleassistent - Service Worker (Manifest V3)

// 1. Enable Side Panel opening on action icon click
chrome.sidePanel
  .setPanelBehavior({ openPanelOnActionClick: true })
  .catch((error) => console.error('[CURIOSA-SW] setPanelBehavior error:', error));

// 2. Setup Context Menus on install/startup
chrome.runtime.onInstalled.addListener(() => {
  setupContextMenus();
});

function setupContextMenus() {
  chrome.contextMenus.removeAll(() => {
    // Teacher Menu 1: Generate Tasks from page or selection
    chrome.contextMenus.create({
      id: 'curiosa_generate_tasks',
      title: 'Lag Curiosa-oppgaver fra denne siden',
      contexts: ['page', 'selection', 'link']
    });

    // Teacher Menu 2: Send PDF/Article to Fagstoff
    chrome.contextMenus.create({
      id: 'curiosa_send_fagstoff',
      title: 'Legg til som Fagstoff i Curiosa',
      contexts: ['page', 'selection', 'link']
    });

    // Student / General: Open Companion
    chrome.contextMenus.create({
      id: 'curiosa_open_companion',
      title: 'Åpne Curiosa Læringsassistent',
      contexts: ['all']
    });
  });
}

// 3. Handle Context Menu Clicks
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  // Open side panel in current window safely
  try {
    let targetWindowId = tab?.windowId;
    if (!targetWindowId || targetWindowId === -1) {
      const currentWin = await chrome.windows.getCurrent();
      targetWindowId = currentWin?.id;
    }
    if (targetWindowId && targetWindowId !== -1) {
      await chrome.sidePanel.open({ windowId: targetWindowId });
    }
  } catch (err) {
    console.error('[CURIOSA-SW] Could not open side panel:', err);
  }

  // Pass context data to Side Panel
  setTimeout(() => {
    try {
      chrome.runtime.sendMessage({
        type: 'CONTEXT_MENU_CLICKED',
        menuItemId: info.menuItemId,
        selectionText: info.selectionText || '',
        pageUrl: info.pageUrl || tab.url || '',
        tabTitle: tab.title || '',
        tabId: tab.id
      }, () => {
        if (chrome.runtime.lastError) {
          // Handled safely: Side panel might not be open yet
        }
      });
    } catch (e) {}
  }, 400);
});

// 4. Default Whitelisted Domains during Kiosk / Exam Mode
const DEFAULT_EXAM_WHITELIST = [
  'curiosa.no',
  'voxkunnskapeuropa.web.app',
  'localhost',
  'feide.no',
  'dataporten.no',
  'ordbokene.no',
  'lingit.no',
  'lingdys.no',
  'texthelp.com',
  'googleapis.com',
  'firebaseapp.com'
];

function cleanDomain(d) {
  return (d || '').replace(/^https?:\/\//i, '').replace(/^www\./i, '').replace(/^\*\./, '').split('/')[0].trim().toLowerCase();
}

// 5. Manage Kiosk / Test Focus Rules via DeclarativeNetRequest & Tab Guards
async function enableExamFocusMode(customWhitelist = []) {
  const allowedDomains = Array.from(new Set([
    ...DEFAULT_EXAM_WHITELIST,
    ...(customWhitelist || []).map(cleanDomain)
  ])).filter(Boolean);
  
  console.log('[CURIOSA-SW] Enabling Exam Focus Mode with whitelist:', allowedDomains);

  // Declarative Net Request: Block all external navigation except whitelisted domains
  const blockRule = {
    id: 1001,
    priority: 1,
    action: {
      type: 'block'
    },
    condition: {
      regexFilter: '^https?://',
      resourceTypes: ['main_frame', 'sub_frame', 'websocket'],
      excludedInitiatorDomains: allowedDomains,
      excludedRequestDomains: allowedDomains
    }
  };

  try {
    await chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: [1001],
      addRules: [blockRule]
    });

    // Save state
    await chrome.storage.local.set({ isExamFocusActive: true, examWhitelist: allowedDomains });

    // Store original URLs of open unauthorized tabs and freeze them to blocked page
    chrome.tabs.query({}, (tabs) => {
      const suspendedTabs = {};
      tabs.forEach(t => {
        if (!t.url || t.url.startsWith('chrome://') || t.url.startsWith('chrome-extension://')) return;
        try {
          const host = new URL(t.url).hostname.toLowerCase();
          const isAllowed = allowedDomains.some(d => host === d || host.endsWith('.' + d));
          if (!isAllowed) {
            suspendedTabs[t.id] = t.url;
            const blockedUrl = chrome.runtime.getURL(`pages/blocked.html?domain=${encodeURIComponent(host)}&orig=${encodeURIComponent(t.url)}`);
            chrome.tabs.update(t.id, { url: blockedUrl });
          }
        } catch (e) {}
      });
      if (Object.keys(suspendedTabs).length > 0) {
        chrome.storage.local.set({ suspendedTabs });
      }
    });
  } catch (err) {
    console.error('[CURIOSA-SW] Failed to enable exam mode:', err);
  }
}

async function disableExamFocusMode() {
  console.log('[CURIOSA-SW] Disabling Exam Focus Mode');
  try {
    await chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: [1001]
    });
    await chrome.storage.local.set({ isExamFocusActive: false });

    // 1. Direct scan across all tabs for any sitting on blocked.html
    chrome.tabs.query({}, (tabs) => {
      tabs.forEach(t => {
        if (!t.url) return;
        if (t.url.includes('pages/blocked.html')) {
          try {
            const urlObj = new URL(t.url);
            const orig = urlObj.searchParams.get('orig');
            if (orig && (orig.startsWith('http://') || orig.startsWith('https://'))) {
              console.log('[CURIOSA-SW] Restoring blocked tab', t.id, '->', orig);
              chrome.tabs.update(t.id, { url: orig });
            }
          } catch (e) {}
        }
      });
    });

    // 2. Fallback restoration from suspendedTabs storage
    chrome.storage.local.get(['suspendedTabs'], (data) => {
      const suspended = data?.suspendedTabs || {};
      for (const [tabIdStr, origUrl] of Object.entries(suspended)) {
        const tabId = parseInt(tabIdStr, 10);
        chrome.tabs.get(tabId, (tab) => {
          if (chrome.runtime.lastError || !tab) return;
          if (tab.url && (tab.url.includes('pages/blocked.html') || tab.url.includes('curiosa.no/#/dashboard?view=topic'))) {
            chrome.tabs.update(tabId, { url: origUrl });
          }
        });
      }
      chrome.storage.local.remove(['suspendedTabs']);
    });
  } catch (err) {
    console.error('[CURIOSA-SW] Failed to disable exam mode:', err);
  }
}

// Proactive tab navigation guard during active exam
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (!changeInfo.url) return;
  chrome.storage.local.get(['isExamFocusActive', 'examWhitelist', 'suspendedTabs'], (data) => {
    if (data && data.isExamFocusActive) {
      const whitelist = data.examWhitelist || DEFAULT_EXAM_WHITELIST;
      try {
        const urlObj = new URL(changeInfo.url);
        const host = urlObj.hostname.toLowerCase();
        const isAllowed = whitelist.some(d => host === d || host.endsWith('.' + d));
        if (!isAllowed && !urlObj.protocol.startsWith('chrome')) {
          console.warn('[CURIOSA-SW] Blocked navigation to unauthorized domain during exam:', host);
          const currentSuspended = data.suspendedTabs || {};
          currentSuspended[tabId] = changeInfo.url;
          chrome.storage.local.set({ suspendedTabs: currentSuspended });
          
          const blockedUrl = chrome.runtime.getURL(`pages/blocked.html?domain=${encodeURIComponent(host)}&orig=${encodeURIComponent(changeInfo.url)}`);
          chrome.tabs.update(tabId, { url: blockedUrl });
        }
      } catch (e) {}
    }
  });
});

// Active tab lock: if student clicks another tab during active exam, bring focus back to Curiosa exam
chrome.tabs.onActivated.addListener(async (activeInfo) => {
  chrome.storage.local.get(['isExamFocusActive', 'examWhitelist', 'examTabId'], async (data) => {
    if (!data?.isExamFocusActive || !data?.examTabId) return;
    if (activeInfo.tabId === data.examTabId) return;

    try {
      const tab = await chrome.tabs.get(activeInfo.tabId);
      if (!tab?.url) return;
      const host = new URL(tab.url).hostname.toLowerCase();
      const whitelist = data.examWhitelist || DEFAULT_EXAM_WHITELIST;
      const isAllowed = whitelist.some(d => host === d || host.endsWith('.' + d));
      
      // If student clicked on an unallowed tab, instantly pull focus back to the exam tab
      if (!isAllowed && !tab.url.includes('pages/blocked.html')) {
        console.warn('[CURIOSA-SW] Student tried to switch to unapproved tab. Refocusing exam tab.');
        chrome.tabs.update(data.examTabId, { active: true });
      }
    } catch (e) {}
  });
});

// Auto-re-fullscreen guard: If window drops out of fullscreen during active exam, force it back into fullscreen
chrome.windows.onBoundsChanged.addListener(async (win) => {
  chrome.storage.local.get(['isExamFocusActive', 'examWindowId'], async (data) => {
    if (data?.isExamFocusActive && data?.examWindowId && win.id === data.examWindowId) {
      if (win.state !== 'fullscreen' && win.state !== 'locked-fullscreen') {
        console.warn('[CURIOSA-SW] Window left fullscreen during active exam. Restoring fullscreen.');
        try {
          await chrome.windows.update(win.id, { state: 'fullscreen' });
        } catch (e) {}
      }
    }
  });
});

// 6. Message Listener (from content scripts & webapp)
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || !message.type) {
    return false;
  }

  if (message.type === 'AUTH_STATE_SYNC') {
    const { user, role, school, classes, topics, hasReadWriteSupport } = message.payload || {};
    
    if (role === 'student') {
      // Clear out all teacher topics/state when syncing student
      chrome.storage.local.set({
        curiosaAuth: {
          isLoggedIn: !!user,
          user: user || null,
          role: 'student',
          school: school || null,
          classes: classes || [],
          topics: [],
          hasReadWriteSupport: !!hasReadWriteSupport,
          lastSyncedAt: Date.now()
        }
      });
    } else if (role === 'guest' || !user) {
      // Logged out / guest state
      chrome.storage.local.set({
        curiosaAuth: {
          isLoggedIn: false,
          user: null,
          role: 'guest',
          school: null,
          classes: [],
          topics: [],
          hasReadWriteSupport: false,
          lastSyncedAt: Date.now()
        }
      });
    } else {
      // Teacher role
      chrome.storage.local.set({
        curiosaAuth: {
          isLoggedIn: true,
          user: user,
          role: 'teacher',
          school: school || null,
          classes: classes || [],
          topics: topics || [],
          hasReadWriteSupport: !!hasReadWriteSupport,
          lastSyncedAt: Date.now()
        }
      });
    }
    sendResponse({ status: 'ok' });
    return false;
  }

  if (message.type === 'START_EXAM_FOCUS') {
    const tabId = sender?.tab?.id;
    const windowId = sender?.tab?.windowId;
    if (tabId) {
      chrome.storage.local.set({ examTabId: tabId, examWindowId: windowId });
      if (windowId) {
        chrome.windows.update(windowId, { state: 'fullscreen' }).catch(() => {});
      }
    }

    enableExamFocusMode(message.whitelist || []).then(() => {
      sendResponse({ status: 'ok', active: true });
    }).catch((e) => {
      sendResponse({ status: 'error', message: e.message });
    });
    return true;
  }

  if (message.type === 'STOP_EXAM_FOCUS') {
    chrome.storage.local.remove(['examTabId', 'examWindowId']);
    disableExamFocusMode().then(() => {
      sendResponse({ status: 'ok', active: false });
    }).catch((e) => {
      sendResponse({ status: 'error', message: e.message });
    });
    return true;
  }

  if (message.type === 'GET_ACTIVE_TAB_CONTENT') {
    (async () => {
      try {
        const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!activeTab || !activeTab.id) {
          sendResponse({ success: false, error: 'No active tab' });
          return;
        }
        if (activeTab.url?.startsWith('chrome://') || activeTab.url?.startsWith('chrome-extension://') || activeTab.url?.startsWith('edge://') || activeTab.url?.startsWith('about:')) {
          sendResponse({ success: false, error: 'Cannot extract from browser internal page' });
          return;
        }
        const results = await chrome.scripting.executeScript({
          target: { tabId: activeTab.id },
          func: () => {
            try {
              const selection = window.getSelection()?.toString()?.trim();
              const rawTitle = (document.querySelector('h1')?.innerText || document.title || '')
                .replace(/\s*-\s*Wikipedia.*$/i, '')
                .replace(/\s*-\s*NRK.*$/i, '')
                .replace(/\s*\|\s*.*$/i, '')
                .trim();
              const metaDesc = document.querySelector('meta[name="description"]')?.content || '';

              // Find primary content container
              const containerCandidates = [
                '.mw-parser-output',
                'article',
                'main',
                '[role="main"]',
                '#main-content',
                '.article-body',
                '.article-content',
                '#article-body',
                '.story-body',
                '.post-content',
                '.entry-content'
              ];
              let mainEl = null;
              for (const sel of containerCandidates) {
                const el = document.querySelector(sel);
                if (el && el.innerText && el.innerText.length > 200) {
                  mainEl = el;
                  break;
                }
              }
              if (!mainEl) mainEl = document.body;

              // Extract high-quality images from main content
              const images = [];
              const imgElements = mainEl.querySelectorAll('figure img, .thumbimage, img');
              imgElements.forEach(img => {
                const src = img.currentSrc || img.src;
                if (src && !src.startsWith('data:') && !src.includes('/static/images/') && !src.includes('badge') && !src.includes('icon')) {
                  const w = img.naturalWidth || img.width || 0;
                  const h = img.naturalHeight || img.height || 0;
                  if ((w >= 160 && h >= 120) || (!w && !src.endsWith('.svg'))) {
                    if (!images.some(existing => existing.src === src) && images.length < 5) {
                      const caption = img.closest('figure')?.querySelector('figcaption')?.innerText?.trim() 
                        || img.closest('.thumb')?.querySelector('.thumbcaption')?.innerText?.trim()
                        || img.alt 
                        || '';
                      images.push({
                        src: src,
                        alt: caption.replace(/\[\d+\]/g, '').trim()
                      });
                    }
                  }
                }
              });

              // Clone and clean DOM
              const clone = mainEl.cloneNode(true);
              const noiseSelectors = [
                'script', 'style', 'noscript', 'nav', 'footer', 'header', 'svg', 'iframe', 'form', 'button',
                '.sidebar', '.vertical-navbox', '.navbox', '.seriesbox', '.series', '.portal',
                '.infobox', '.infobox-v2', '.ambox', '.metadata', '.vector-toc', '.mw-editsection',
                '.mw-jump-link', '.noprint', '.reflist', '.reference', '.citation', 'aside', '.advertisement',
                '.ad', '.social-share', '.cookie-banner', '.site-header', '.site-footer', '.mw-empty-elt',
                '#toc', '.toc', '.vector-page-toolbar', '.mw-indicators', '.IPA', '.IPA-label', '.phonetic',
                '.pronunciation', '.audiolink', '.catlinks', '[role="navigation"]',
                '#article-comments', '.l-article__comments', '.comment', '.comments', '#comments',
                '.comment-thread', '.create-comment', '.l-article__credits', '.article-meta', '.feedback', '#feedback',
                'table.navbox', 'table.vertical-navbox', 'table.sidebar', 'table[role="presentation"]', 'table.infobox'
              ];
              clone.querySelectorAll(noiseSelectors.join(', ')).forEach(el => el.remove());

              // Helper to sanitize phonetic / broken Unicode characters for clean reading
              const cleanString = (str) => {
                if (!str) return '';
                return str
                  .replace(/\(\s*\/[^/)]+\/\s*[,;]?\s*(\/[^/)]+\/)?\s*;/g, '(')
                  .replace(/\(\s*\/[^)]+\/\s*\)/g, '')
                  .replace(/\/[\u0250-\u02AF\u1D00-\u1D7F\u02B0-\u02FFˈˌːˑ˘. ]+\//g, '')
                  .replace(/\[\s*(edit|\d+|[a-z])\s*\]/gi, '')
                  .replace(/[\u0370-\u03FF\u1F00-\u1FFF]/g, '') // remove raw Greek symbols that corrupt standard PDF fonts
                  .replace(/[\u0000-\u001F\u007F-\u009F]/g, '')
                  .replace(/[“”]/g, '"')
                  .replace(/[‘’`]/g, "'")
                  .replace(/[–—]/g, '-')
                  .replace(/\(\s*[,;:]+\s*/g, '(')
                  .replace(/\s*[,;:]+\s*\)/g, ')')
                  .replace(/\(\s*\)/g, '')
                  .replace(/[^\S\r\n]+/g, ' ') // Preserve newlines!
                  .trim();
              };

              // Extract sequential paragraphs, tables and headings
              const structuredSections = [];
              const blocks = clone.querySelectorAll('h2, h3, h4, p, blockquote, ul, ol, table');
              let reachedEndSection = false;
              
              if (blocks && blocks.length > 0) {
                for (const block of blocks) {
                  if (reachedEndSection) break;

                  if (block.closest('.sidebar, .navbox, [role="navigation"], #article-comments, .l-article__comments, .comment')) {
                    continue;
                  }

                  const tag = block.tagName.toLowerCase();
                  let text = cleanString(block.innerText || '');
                  if (!text) continue;

                  // Detect bibliography, notes, references, comments or external links sections to STOP extraction
                  if (tag.startsWith('h')) {
                    if (/^(notes|references|further reading|bibliography|external links|see also|sources|footnotes|citations|noter|referanser|litteratur|kilder|se også|bakgrunnsstoff|relatert|kommentarer|comments|diskusjon|bidragsytere|om artikkelen)/i.test(text)) {
                      reachedEndSection = true;
                      break;
                    }
                    structuredSections.push(`## ${text}`);
                    continue;
                  }
                  
                  // Skip citation lines, notes, and category items
                  if (/^(jump to|coordinates:|see also|references|external links|further reading|kilder|se også|noter|notes|litteratur|kommentarer)/i.test(text)) {
                    continue;
                  }
                  if (/^(cite|cs1 maint|doi:|isbn|issn|jstor|pmid|s2cid|bibcode|oclc)/i.test(text)) {
                    continue;
                  }
                  if (/^(articles with|short description|hidden categories|categories:|kategori:)/i.test(text)) {
                    continue;
                  }

                  if (tag === 'p') {
                    if (text.length > 25) {
                      structuredSections.push(text);
                    }
                  } else if (tag === 'table') {
                    const rows = Array.from(block.querySelectorAll('tr'));
                    const tableRows = [];
                    rows.forEach(tr => {
                      const cells = Array.from(tr.querySelectorAll('th, td'))
                        .map(c => cleanString(c.innerText || ''))
                        .filter(Boolean);
                      if (cells.length > 0) {
                        tableRows.push(cells.join(' | '));
                      }
                    });
                    if (tableRows.length > 0 && tableRows.length <= 150) {
                      structuredSections.push(tableRows.join('\n'));
                    }
                  } else if (tag === 'ul' || tag === 'ol') {
                    const items = Array.from(block.querySelectorAll('li'))
                      .map(li => cleanString(li.innerText || ''))
                      .filter(t => t.length > 15 && !/^(cite|cs1|doi:|isbn|jstor|articles with|short description)/i.test(t))
                      .map(t => `• ${t}`);
                    if (items.length > 0 && items.length <= 30) {
                      structuredSections.push(items.join('\n'));
                    }
                  }
                }
              }

              const cleanText = structuredSections.length > 0 
                ? structuredSections.join('\n\n')
                : cleanString(clone.innerText || '');

              return {
                title: cleanString(rawTitle),
                url: window.location.href,
                selection: cleanString(selection),
                metaDesc: cleanString(metaDesc),
                images,
                text: selection ? cleanString(selection) : cleanText.slice(0, 30000)
              };
            } catch (e) {
              return {
                title: document.title || '',
                url: window.location.href,
                selection: '',
                metaDesc: '',
                images: [],
                text: document.body.innerText?.slice(0, 30000) || ''
              };
            }
          }
        });

        if (results && results[0]?.result) {
          sendResponse({ success: true, data: results[0].result });
        } else {
          sendResponse({ success: false, error: 'Could not extract text' });
        }
      } catch (err) {
        sendResponse({ success: false, error: err.message });
      }
    })();
    return true;
  }

  return false;
});
