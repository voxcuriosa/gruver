// Curiosa Skoleassistent - Side Panel Controller

document.addEventListener('DOMContentLoaded', async () => {
  // State
  let currentRole = 'guest'; // 'teacher' | 'student' | 'guest'
  let currentUser = null;
  let activeTabContent = null;
  let generatedTasks = null;
  let selectedClasses = new Set();
  let allTeacherTopics = [];

  // Elements
  const userStatusText = document.getElementById('user-status-text');
  const roleBadge = document.getElementById('role-badge');
  const navTabs = document.getElementById('nav-tabs');
  const sourceTextPreview = document.getElementById('source-text-preview');
  const topicTitleInput = document.getElementById('topic-title');
  const fagstoffTitleInput = document.getElementById('fagstoff-title');
  const fagstoffTopicSearch = document.getElementById('fagstoff-topic-search');
  const fagstoffTargetTopic = document.getElementById('fagstoff-target-topic');
  const btnGenerateTasks = document.getElementById('btn-generate-tasks');
  const btnPublishTopic = document.getElementById('btn-publish-topic');
  const btnRefreshText = document.getElementById('btn-refresh-text');
  const btnSaveFagstoff = document.getElementById('btn-save-fagstoff');
  const generatedTasksContainer = document.getElementById('generated-tasks-container');
  const generatedTasksList = document.getElementById('generated-tasks-list');
  const taskSummaryBadge = document.getElementById('task-summary-badge');
  const classesSelector = document.getElementById('classes-selector');
  const customClassInput = document.getElementById('custom-class-input');
  const chatMessages = document.getElementById('chat-messages');
  const chatInput = document.getElementById('chat-input');
  const btnChatSend = document.getElementById('btn-chat-send');

  // Wire up Steppers (+ / -)
  document.querySelectorAll('.btn-stepper').forEach(btn => {
    btn.addEventListener('click', () => {
      const targetId = btn.getAttribute('data-target');
      const action = btn.getAttribute('data-action');
      const input = document.getElementById(targetId);
      if (!input) return;

      let val = parseInt(input.value, 10) || 0;
      const min = parseInt(input.min, 10) || 0;
      const max = parseInt(input.max, 10) || 20;

      if (action === 'inc' && val < max) {
        input.value = val + 1;
      } else if (action === 'dec' && val > min) {
        input.value = val - 1;
      }
    });
  });

  function formatTeacherName(rawName) {
    if (!rawName || rawName === 'Curiosa Laererassistent' || rawName === 'Innlogget laerer') {
      return 'Curiosa Laererassistent';
    }
    
    const parts = rawName.split('•').map(p => p.trim());
    let fullName = parts[0];
    let school = parts[1] || '';

    let firstName = fullName.split(' ')[0] || '';
    if (firstName) {
      firstName = firstName.charAt(0).toUpperCase() + firstName.slice(1).toLowerCase();
    }

    if (school) {
      const formattedSchool = school
        .toLowerCase()
        .split(' ')
        .map(w => w === 'vgs' ? 'vgs' : (w.charAt(0).toUpperCase() + w.slice(1)))
        .join(' ');
      return `${firstName} • ${formattedSchool}`;
    }

    return firstName || 'Laerer';
  }

  // Strict Norwegian class validator (allows 1B, 2A, 3MOKA, 3PBYA, 3PBYB, LATIN; rejects PINs and student names)
  function isValidClassCode(str) {
    if (!str || typeof str !== 'string') return false;
    const clean = str.trim().toUpperCase();
    return (/^[1-3][A-ZÆØÅ]{1,5}$/.test(clean) || clean === 'LATIN');
  }

  // Render dynamic and filtered topic options
  function renderFilteredTopics() {
    if (!fagstoffTargetTopic) return;
    
    const selectedFagstoffClasses = Array.from(document.querySelectorAll('#fagstoff-classes-selector .class-pill.selected')).map(p => p.textContent.trim().toUpperCase());
    const searchQuery = (fagstoffTopicSearch?.value || '').trim().toLowerCase();

    const previousSelectedValue = fagstoffTargetTopic.value;
    fagstoffTargetTopic.innerHTML = '<option value="">-- Frittstående pensum i biblioteket --</option>';

    let filtered = (allTeacherTopics || []).filter(t => t && t.title && !t.title.includes('Generer ny PIN') && !t.title.includes('Last ned rapport') && !t.title.includes('Slett'));

    // Filter 1: If classes are selected, only show topics available to those classes
    if (selectedFagstoffClasses.length > 0) {
      filtered = filtered.filter(topic => {
        if (!topic.classes || topic.classes.length === 0) return true; // Available to all classes
        return topic.classes.some(c => selectedFagstoffClasses.includes(c.toUpperCase()));
      });
    }

    // Filter 2: Dynamic search query
    if (searchQuery) {
      filtered = filtered.filter(topic => {
        const titleMatch = (topic.title || '').toLowerCase().includes(searchQuery);
        const subjectMatch = (topic.subject || '').toLowerCase().includes(searchQuery);
        return titleMatch || subjectMatch;
      });
    }

    if (filtered.length === 0) {
      const opt = document.createElement('option');
      opt.value = "";
      opt.disabled = true;
      opt.textContent = selectedFagstoffClasses.length > 0
        ? `Ingen temaer funnet for valgt(e) klasse(r)`
        : `Ingen temaer matcher søket`;
      fagstoffTargetTopic.appendChild(opt);
      return;
    }

    filtered.forEach(topic => {
      const opt = document.createElement('option');
      opt.value = topic.id;
      // Strip any existing [ØVING], [TEST] or [FAGSTOFF] tag in the title so it is not duplicated
      const cleanTitle = (topic.title || '').replace(/^\[(øving|test|fagstoff)\]\s*/i, '').trim();
      const typeBadge = topic.isPractice ? '[Øving]' : '[Test]';
      const classBadge = topic.classes && topic.classes.length > 0 ? ` (${topic.classes.join(', ')})` : ' (Alle)';
      opt.textContent = `${typeBadge} ${cleanTitle}${classBadge}`;
      if (topic.id === previousSelectedValue) {
        opt.selected = true;
      }
      fagstoffTargetTopic.appendChild(opt);
    });

    updateClassesLabel();
  }

  function updateClassesLabel() {
    const classesLabel = document.getElementById('fagstoff-classes-label');
    const classesHint = document.getElementById('fagstoff-classes-hint');
    if (!classesLabel || !classesHint) return;

    const isStandalone = !fagstoffTargetTopic?.value;
    if (isStandalone) {
      classesLabel.textContent = 'Tildel pensum til klasser';
      classesHint.textContent = 'Klikk på klassene som skal få dokumentet i sitt Fagstoff-arkiv (eller la stå tomt for alle).';
    } else {
      const selectedTopicName = fagstoffTargetTopic.options[fagstoffTargetTopic.selectedIndex]?.text || '';
      classesLabel.textContent = 'Filtrer temaer etter klasse';
      classesHint.textContent = `Dokumentet knyttes til "${selectedTopicName}" og arver klassene til temaet.`;
    }
  }

  // Dynamic Search & Select listeners
  fagstoffTopicSearch?.addEventListener('input', renderFilteredTopics);
  fagstoffTargetTopic?.addEventListener('change', updateClassesLabel);

  // 1. Multi-Layered Auth & Pure Teacher Classes Sync
  async function initAuth() {
    // Step A: Load cached storage if exists
    chrome.storage.local.get(['curiosaAuth'], (data) => {
      const auth = data?.curiosaAuth;
      if (auth && auth.user) {
        currentUser = auth.user;
        currentRole = auth.role || 'teacher';
        
        const teacherLabel = formatTeacherName(currentUser.name || currentUser.displayName || currentUser.email);
        userStatusText.textContent = teacherLabel;
        roleBadge.className = `role-badge ${currentRole === 'teacher' ? 'role-teacher' : 'role-student'}`;
        roleBadge.textContent = currentRole === 'teacher' ? 'Laerer' : 'Elev';

        renderTabsForRole(currentRole);
        const filteredCached = (auth.classes || []).filter(isValidClassCode);
        if (filteredCached.length > 0) {
          populateClasses(filteredCached);
        }
        if (auth.topics && Array.isArray(auth.topics)) {
          allTeacherTopics = auth.topics;
          renderFilteredTopics();
        }
      }
    });

    // Step B: Direct inspection of all open tabs to find Curiosa
    try {
      chrome.tabs.query({}, async (tabs) => {
        for (const t of tabs) {
          if (!t.id) continue;
          const url = t.url || '';
          if (url.includes('curiosa.no') || url.includes('voxkunnskapeuropa') || url.includes('localhost') || url.includes('127.0.0.1')) {
            try {
              const [res] = await chrome.scripting.executeScript({
                target: { tabId: t.id },
                func: () => {
                  let rawTeacherName = '';
                  const spans = Array.from(document.querySelectorAll('span, div, header, p'));
                  for (const el of spans) {
                    const txt = el.textContent?.trim() || '';
                    if (txt.includes('•') && (txt.includes('VGS') || txt.includes('vgs') || txt.includes('Skole') || txt.includes('SKOLE') || txt.length < 60)) {
                      if (!txt.includes('Curiosa') && !txt.includes('–')) {
                        rawTeacherName = txt;
                        break;
                      }
                    }
                  }

                  const foundClasses = new Set();

                  function checkClass(str) {
                    if (!str || typeof str !== 'string') return false;
                    const clean = str.trim().toUpperCase();
                    return (/^[1-3][A-ZÆØÅ]{1,5}$/.test(clean) || clean === 'LATIN');
                  }

                  // 1. Check localStorage for classes
                  try {
                    const stored = JSON.parse(localStorage.getItem('voks_teacher_classes') || '[]');
                    if (Array.isArray(stored)) {
                      stored.forEach(c => {
                        if (checkClass(c)) foundClasses.add(c.toUpperCase());
                      });
                    }
                  } catch(e) {}

                  // 2. Specific class elements in table (p.text-brand-400)
                  document.querySelectorAll('p.text-brand-400, .text-brand-400').forEach(el => {
                    const txt = el.textContent?.trim().toUpperCase();
                    if (checkClass(txt)) {
                      foundClasses.add(txt);
                    }
                  });

                  // 3. Topics strictly from localStorage
                  let topics = [];
                  try {
                    const rawTopics = localStorage.getItem('voks_teacher_topics');
                    if (rawTopics) {
                      const parsed = JSON.parse(rawTopics);
                      if (Array.isArray(parsed)) {
                        topics = parsed.filter(t => t && t.title && !t.title.includes('Generer ny PIN') && !t.title.includes('Last ned rapport') && !t.title.includes('Slett'));
                      }
                    }
                  } catch(e) {}

                  return {
                    teacherName: rawTeacherName || localStorage.getItem('voks_teacher_name') || '',
                    classes: Array.from(foundClasses).sort(),
                    topics: topics
                  };
                }
              });

              if (res && res.result) {
                const data = res.result;
                if (data.teacherName) {
                  userStatusText.textContent = formatTeacherName(data.teacherName);
                }
                currentRole = 'teacher';
                roleBadge.className = 'role-badge role-teacher';
                roleBadge.textContent = 'Laerer';
                renderTabsForRole('teacher');

                const pureClasses = (data.classes || []).filter(isValidClassCode);
                if (pureClasses.length > 0) {
                  populateClasses(pureClasses);
                }

                if (data.topics && Array.isArray(data.topics)) {
                  allTeacherTopics = data.topics;
                  renderFilteredTopics();
                }

                chrome.storage.local.set({
                  curiosaAuth: {
                    isLoggedIn: true,
                    role: 'teacher',
                    user: { name: data.teacherName },
                    classes: pureClasses,
                    topics: data.topics || []
                  }
                });
              }
            } catch(err) {
              console.warn('[CURIOSA-SP] tab script error:', err);
            }
          }
        }
      });
    } catch (e) {
      console.warn('[CURIOSA-SP] Tab query failed:', e);
    }
  }

  // Step C: Listen for live updates from webapp content script
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'AUTH_STATE_SYNC' && msg.payload) {
      const { user, role, classes, topics } = msg.payload;
      const rawLabel = user?.name || user?.displayName || user?.email || '';
      if (rawLabel) {
        userStatusText.textContent = formatTeacherName(rawLabel);
      }
      currentRole = role || 'teacher';
      roleBadge.className = `role-badge ${currentRole === 'teacher' ? 'role-teacher' : 'role-student'}`;
      roleBadge.textContent = currentRole === 'teacher' ? 'Laerer' : 'Elev';
      renderTabsForRole(currentRole);
      
      const pureClasses = (classes || []).filter(isValidClassCode);
      if (pureClasses.length > 0) {
        populateClasses(pureClasses);
      }

      if (topics && Array.isArray(topics)) {
        allTeacherTopics = topics;
        renderFilteredTopics();
      }
    }
  });

  // 2. Render Navigation Tabs
  function renderTabsForRole(role) {
    navTabs.innerHTML = '';
    if (role === 'teacher') {
      navTabs.innerHTML = `
        <button class="tab-btn active" data-target="tab-generator">Oppgavegenerator</button>
        <button class="tab-btn" data-target="tab-fagstoff">Fagstoff / PDF</button>
      `;
    } else if (role === 'student') {
      navTabs.innerHTML = `
        <button class="tab-btn active" data-target="tab-companion">Laeringsassistent</button>
      `;
    } else {
      navTabs.innerHTML = `
        <button class="tab-btn active" data-target="tab-login">Logg inn</button>
      `;
    }

    // Attach tab listeners
    navTabs.querySelectorAll('.tab-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        navTabs.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
        
        btn.classList.add('active');
        const targetId = btn.getAttribute('data-target');
        const targetPane = document.getElementById(targetId);
        if (targetPane) targetPane.classList.add('active');
      });
    });
  }

  // 3. Populate Classes Selectors
  function populateClasses(classesList) {
    classesSelector.innerHTML = '';
    const fagstoffSelector = document.getElementById('fagstoff-classes-selector');
    if (fagstoffSelector) fagstoffSelector.innerHTML = '';

    const pureList = (classesList || []).filter(isValidClassCode);

    if (!pureList || pureList.length === 0) {
      classesSelector.innerHTML = '<span class="muted-text">Ingen klasser funnet. Apne Curiosa for a hente klassene dine.</span>';
      if (fagstoffSelector) fagstoffSelector.innerHTML = '<span class="muted-text">Ingen klasser funnet. Apne Curiosa for a hente klassene dine.</span>';
      return;
    }

    pureList.forEach(cls => {
      // 1. Task Generator tab
      const pill = document.createElement('span');
      pill.className = 'class-pill';
      pill.textContent = cls;
      pill.addEventListener('click', () => {
        if (selectedClasses.has(cls)) {
          selectedClasses.delete(cls);
          pill.classList.remove('selected');
        } else {
          selectedClasses.add(cls);
          pill.classList.add('selected');
        }
      });
      classesSelector.appendChild(pill);

      // 2. Fagstoff tab
      if (fagstoffSelector) {
        const fagPill = document.createElement('span');
        fagPill.className = 'class-pill';
        fagPill.textContent = cls;
        fagPill.addEventListener('click', () => {
          fagPill.classList.toggle('selected');
          // Update topic list when a class pill is toggled
          renderFilteredTopics();
        });
        fagstoffSelector.appendChild(fagPill);
      }
    });

    renderFilteredTopics();
  }

  // Add custom class manually
  if (customClassInput) {
    customClassInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && customClassInput.value.trim()) {
        const newClass = customClassInput.value.trim().toUpperCase();
        selectedClasses.add(newClass);
        
        const pill = document.createElement('span');
        pill.className = 'class-pill selected';
        pill.textContent = newClass;
        pill.addEventListener('click', () => {
          if (selectedClasses.has(newClass)) {
            selectedClasses.delete(newClass);
            pill.classList.remove('selected');
          } else {
            selectedClasses.add(newClass);
            pill.classList.add('selected');
          }
        });
        classesSelector.appendChild(pill);
        customClassInput.value = '';
      }
    });
  }

  // 4. Fetch Active Tab Content
  async function fetchCurrentPageContent() {
    sourceTextPreview.value = 'Henter tekst fra nettsiden...';
    chrome.runtime.sendMessage({ type: 'GET_ACTIVE_TAB_CONTENT' }, (response) => {
      if (response && response.success && response.data) {
        activeTabContent = response.data;
        sourceTextPreview.value = activeTabContent.text || '';
        
        if (topicTitleInput && !topicTitleInput.value) {
          const cleanTitle = activeTabContent.title?.split(' - ')[0]?.split(' | ')[0] || '';
          topicTitleInput.value = cleanTitle;
        }
        if (fagstoffTitleInput && !fagstoffTitleInput.value) {
          fagstoffTitleInput.value = activeTabContent.title ? `${activeTabContent.title}.pdf` : 'Fagstoff.pdf';
        }
      } else {
        sourceTextPreview.value = 'Kunne ikke hente tekst automatisk. Du kan lime inn tekst manuelt her.';
      }
    });
  }

  btnRefreshText?.addEventListener('click', fetchCurrentPageContent);

  // 5. Generate AI Tasks
  btnGenerateTasks?.addEventListener('click', async () => {
    const text = sourceTextPreview.value.trim();
    const title = topicTitleInput.value.trim() || 'Nytt tema';
    if (!text || text.length < 50) {
      alert('Kildeteksten må inneholde minst 50 tegn for å generere oppgaver.');
      return;
    }

    btnGenerateTasks.disabled = true;
    btnGenerateTasks.innerHTML = '<span>Genererer oppgaver med KI...</span>';

    try {
      const tasks = await mockOrGenerateTasks(title, text);
      generatedTasks = tasks;

      renderGeneratedTasks(tasks);
      generatedTasksContainer.classList.remove('hidden');
      generatedTasksContainer.scrollIntoView({ behavior: 'smooth' });
    } catch (err) {
      alert('Generering feilet: ' + err.message);
    } finally {
      btnGenerateTasks.disabled = false;
      btnGenerateTasks.innerHTML = '<span>Generer oppgaver med KI</span>';
    }
  });

  async function mockOrGenerateTasks(title, text) {
    const mcqCount = parseInt(document.getElementById('count-mcqs')?.value, 10) || 0;
    const blankCount = parseInt(document.getElementById('count-blanks')?.value, 10) || 0;
    const sortingCount = parseInt(document.getElementById('count-sorting')?.value, 10) || 0;
    const reflectionCount = parseInt(document.getElementById('count-reflection')?.value, 10) || 0;

    const sentences = text.split('. ').filter(s => s.length > 25);
    
    // Generate MCQs
    const mcqs = [];
    for (let i = 0; i < mcqCount; i++) {
      const sentence = sentences[i % sentences.length] || text.slice(0, 80);
      mcqs.push({
        question: i === 0 
          ? `Hva er hovedbudskapet i teksten om ${title}?`
          : `Hvilket utsagn stemmer best med kildetekstens ${i + 1}. avsnitt?`,
        options: [
          sentence.slice(0, 75) + '...',
          'Kilden avviser denne sammenhengen fullstendig.',
          'Dette er en udokumentert antakelse.',
          'Ingen av de andre alternativene er korrekte.'
        ],
        correctIndex: 0
      });
    }

    // Generate Blanks
    const blanks = [];
    for (let i = 0; i < blankCount; i++) {
      const sentence = sentences[(i + 2) % sentences.length] || `Kildekritikk er et viktig verktøy når man arbeider med ${title}.`;
      blanks.push({
        sentence: sentence.replace(/[,;]/g, ''),
        blankIndex: 3 + (i % 3)
      });
    }

    // Generate Sorting
    const sorting = [];
    for (let i = 0; i < sortingCount; i++) {
      sorting.push({
        category: `Hovedtrekk ${i + 1}`,
        items: ['Arsaksforhold', 'Konsekvenser', 'Sentral kilde', 'Begrepsforklaring']
      });
    }

    // Generate Reflection
    const reflection = [];
    for (let i = 0; i < reflectionCount; i++) {
      reflection.push({
        question: i === 0
          ? `Drøft med utgangspunkt i teksten: Hvordan påvirker denne tematikken samfunnsutviklingen i dag?`
          : `Gjør rede for hvilke kildekritiske vurderinger som er relevante for innholdet i artikkelen.`,
        maxPoints: 6
      });
    }

    return {
      title,
      mcqs,
      blanks,
      sorting,
      reflection
    };
  }

  function renderGeneratedTasks(tasks) {
    generatedTasksList.innerHTML = '';
    let totalCount = 0;

    if (tasks.mcqs) {
      tasks.mcqs.forEach((q, i) => {
        totalCount++;
        const div = document.createElement('div');
        div.className = 'task-item';
        div.innerHTML = `
          <strong>Oppgave ${totalCount} (Flervalg)</strong>
          <p>${escapeHtml(q.question)}</p>
          <span class="badge">Riktig svar: ${escapeHtml(q.options[q.correctIndex])}</span>
        `;
        generatedTasksList.appendChild(div);
      });
    }

    if (tasks.blanks) {
      tasks.blanks.forEach((b, i) => {
        totalCount++;
        const div = document.createElement('div');
        div.className = 'task-item';
        div.innerHTML = `
          <strong>Oppgave ${totalCount} (Fyll inn hull)</strong>
          <p>${escapeHtml(b.sentence)}</p>
        `;
        generatedTasksList.appendChild(div);
      });
    }

    if (tasks.sorting) {
      tasks.sorting.forEach((s, i) => {
        totalCount++;
        const div = document.createElement('div');
        div.className = 'task-item';
        div.innerHTML = `
          <strong>Oppgave ${totalCount} (Sortering)</strong>
          <p>Kategori: ${escapeHtml(s.category)} (${s.items.length} elementer)</p>
        `;
        generatedTasksList.appendChild(div);
      });
    }

    if (tasks.reflection) {
      tasks.reflection.forEach((r, i) => {
        totalCount++;
        const div = document.createElement('div');
        div.className = 'task-item';
        div.innerHTML = `
          <strong>Oppgave ${totalCount} (Refleksjon - ${r.maxPoints} poeng)</strong>
          <p>${escapeHtml(r.question)}</p>
        `;
        generatedTasksList.appendChild(div);
      });
    }

    taskSummaryBadge.textContent = `${totalCount} oppgaver generert`;
  }

  // 6. Publish to Curiosa Webapp & Open in Topic Editor
  btnPublishTopic?.addEventListener('click', async () => {
    btnPublishTopic.disabled = true;
    btnPublishTopic.textContent = 'Lagrer og åpner i Curiosa...';

    const payload = {
      title: topicTitleInput.value.trim() || 'Nytt tema fra nettside',
      primarySubject: document.getElementById('topic-subject').value,
      isPractice: document.getElementById('topic-mode').value === 'practice',
      allowedClasses: Array.from(selectedClasses),
      tasks: generatedTasks,
      content: sourceTextPreview.value.trim(),
      sourceUrl: activeTabContent?.url || ''
    };

    chrome.storage.local.set({ pendingImportTopic: payload }, () => {
      setTimeout(() => {
        btnPublishTopic.textContent = 'Apner redigering i Curiosa...';
        btnPublishTopic.style.background = '#10b981';
        
        chrome.tabs.create({
          url: 'https://curiosa.no/#/admin?tab=topics'
        });
      }, 600);
    });
  });

  // 7. Preview and Save Structured Fagstoff PDF
  const fagstoffPreviewContainer = document.getElementById('fagstoff-preview-container');
  const btnConfirmSaveFagstoff = document.getElementById('btn-confirm-save-fagstoff');

  btnSaveFagstoff?.addEventListener('click', () => {
    const fagstoffTitle = fagstoffTitleInput?.value.trim() || activeTabContent?.title || 'Fagstoff-dokument';
    const textContent = sourceTextPreview.value.trim();
    if (!textContent || textContent.length < 30) {
      alert('Kildeteksten må inneholde minst 30 tegn for å lage en Fagstoff-PDF.');
      return;
    }

    const wordsCount = textContent.split(/\s+/).filter(Boolean).length;
    const includeImages = document.getElementById('chk-fagstoff-images')?.checked ?? true;
    const targetTopicId = fagstoffTargetTopic?.value || null;
    const selectedTopicText = fagstoffTargetTopic?.options[fagstoffTargetTopic.selectedIndex]?.text || '';
    const selectedClasses = Array.from(document.querySelectorAll('#fagstoff-classes-selector .class-pill.selected')).map(p => p.textContent.trim().toUpperCase());

    // Update preview details
    const previewHeading = document.getElementById('pdf-preview-heading');
    const previewWords = document.getElementById('pdf-preview-words');
    const previewImages = document.getElementById('pdf-preview-images');
    const previewTarget = document.getElementById('pdf-preview-target');
    const previewExcerpt = document.getElementById('pdf-preview-excerpt');

    if (previewHeading) previewHeading.textContent = fagstoffTitle.endsWith('.pdf') ? fagstoffTitle : `${fagstoffTitle}.pdf`;
    if (previewWords) previewWords.textContent = `Tekstomfang: ~${wordsCount} ord`;
    if (previewImages) previewImages.textContent = `Bilder & figurer: ${includeImages ? 'Inkludert' : 'Kun ren tekst'}`;
    
    if (previewTarget) {
      if (targetTopicId) {
        previewTarget.textContent = `Tilknyttes: ${selectedTopicText}`;
      } else {
        const classInfo = selectedClasses.length > 0 ? ` for klasse(r) ${selectedClasses.join(', ')}` : ' for alle klasser';
        previewTarget.textContent = `Mottaker: Frittstående pensum i biblioteket${classInfo}`;
      }
    }

    if (previewExcerpt) {
      previewExcerpt.textContent = textContent.slice(0, 320) + (textContent.length > 320 ? '...' : '');
    }

    if (fagstoffPreviewContainer) {
      fagstoffPreviewContainer.classList.remove('hidden');
      fagstoffPreviewContainer.scrollIntoView({ behavior: 'smooth' });
    }
  });

  btnConfirmSaveFagstoff?.addEventListener('click', () => {
    btnConfirmSaveFagstoff.disabled = true;
    btnConfirmSaveFagstoff.textContent = 'Lagrer og åpner i Curiosa...';

    const fagstoffTitle = fagstoffTitleInput?.value.trim() || activeTabContent?.title || 'Fagstoff-dokument';
    const fagstoffClasses = Array.from(document.querySelectorAll('#fagstoff-classes-selector .class-pill.selected')).map(p => p.textContent.trim().toUpperCase());
    const targetTopicId = fagstoffTargetTopic?.value || null;
    const includeImages = document.getElementById('chk-fagstoff-images')?.checked ?? true;
    const autoStructure = document.getElementById('chk-fagstoff-structure')?.checked ?? true;

    const payload = {
      title: `[FAGSTOFF] ${fagstoffTitle}`,
      isPractice: true,
      targetTopicId: targetTopicId,
      allowedClasses: fagstoffClasses,
      content: sourceTextPreview.value.trim(),
      sourceUrl: activeTabContent?.url || '',
      includeImages,
      autoStructure,
      fagstoffPdfs: [
        {
          name: fagstoffTitle.endsWith('.pdf') ? fagstoffTitle : `${fagstoffTitle}.pdf`,
          url: activeTabContent?.url || '',
          targetTopicId: targetTopicId,
          includeImages,
          autoStructure,
          addedAt: new Date().toISOString()
        }
      ]
    };

    chrome.storage.local.set({ pendingImportTopic: payload }, () => {
      setTimeout(() => {
        btnConfirmSaveFagstoff.textContent = 'Fagstoff lagret! Åpner i Curiosa...';
        btnConfirmSaveFagstoff.style.background = '#10b981';
        
        setTimeout(() => {
          btnConfirmSaveFagstoff.disabled = false;
          btnConfirmSaveFagstoff.innerHTML = '<span>Lagre & Publiser til Curiosa</span>';
          btnConfirmSaveFagstoff.style.background = '';
          
          chrome.tabs.create({
            url: 'https://curiosa.no/#/admin?tab=topics'
          });
        }, 1000);
      }, 500);
    });
  });

  // 8. Student Companion Chat
  document.querySelectorAll('.chip-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const prompt = btn.getAttribute('data-prompt');
      sendChatMessage(prompt);
    });
  });

  btnChatSend?.addEventListener('click', () => {
    const text = chatInput.value.trim();
    if (text) {
      sendChatMessage(text);
      chatInput.value = '';
    }
  });

  chatInput?.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      const text = chatInput.value.trim();
      if (text) {
        sendChatMessage(text);
        chatInput.value = '';
      }
    }
  });

  function sendChatMessage(userText) {
    const userMsg = document.createElement('div');
    userMsg.className = 'chat-msg user-msg';
    userMsg.innerHTML = `<p>${escapeHtml(userText)}</p>`;
    chatMessages.appendChild(userMsg);
    chatMessages.scrollTop = chatMessages.scrollHeight;

    const aiMsg = document.createElement('div');
    aiMsg.className = 'chat-msg ai-msg';
    aiMsg.innerHTML = `<p>Tenker...</p>`;
    chatMessages.appendChild(aiMsg);
    chatMessages.scrollTop = chatMessages.scrollHeight;

    setTimeout(() => {
      let reply = `Her er en oppsummering av det viktigste fra siden:\n\n1. **Kjerneidé:** Teksten belyser sentrale faglige prinsipper og kildebruk.\n2. **Viktig begrep:** Kildekritisk refleksjon er avgjørende for å trekke pålitelige konklusjoner.\n3. **Hva du bør huske:** Bruk primærkilder når du begrunner dine svar i skoleoppgaver.`;
      if (userText.toLowerCase().includes('enkel')) {
        reply = `Kort forklart: Teksten handler om hvordan vi kan finne ut hva som er sant og viktig når vi leser tekster på nett og i bøker.`;
      } else if (userText.toLowerCase().includes('test')) {
        reply = `Her er et kontrollspørsmål til deg:\n\n*Hva er forskjellen på en primærkilde og en sekundærkilde ifølge teksten?*\n\nPrøv å svare meg med dine egne ord!`;
      }

      aiMsg.innerHTML = `<p>${reply.replace(/\n/g, '<br>')}</p>`;
      chatMessages.scrollTop = chatMessages.scrollHeight;
    }, 800);
  }

  function escapeHtml(str) {
    return (str || '').replace(/[&<>"']/g, function(m) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[m];
    });
  }

  // Run on load
  initAuth();
  fetchCurrentPageContent();
});
