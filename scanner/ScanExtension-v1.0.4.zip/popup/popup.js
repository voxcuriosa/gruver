document.addEventListener('DOMContentLoaded', async () => {
  // DOM Elements
  const configForm = document.getElementById('config-form');
  const progressPanel = document.getElementById('progress-panel');
  const badgeStatus = document.getElementById('badge-status');

  const modeRadios = document.getElementsByName('scanMode');
  const groupTargetPages = document.getElementById('group-target-pages');
  const groupTargetHeading = document.getElementById('group-target-heading');
  const targetHeadingInput = document.getElementById('target-heading');

  const boxContinuous = document.getElementById('box-continuous');
  const boxSubchapter = document.getElementById('box-subchapter');
  const boxAutoChapter = document.getElementById('box-auto-chapter');

  const targetPagesInput = document.getElementById('target-pages');
  const pagesCalcHint = document.getElementById('pages-calc-hint');
  const btnPagesDec = document.getElementById('btn-pages-dec');
  const btnPagesInc = document.getElementById('btn-pages-inc');

  const navModeSelect = document.getElementById('nav-mode');
  const delaySlider = document.getElementById('delay-sec');
  const delayValue = document.getElementById('delay-value');
  const pdfNameInput = document.getElementById('pdf-name');

  const btnStart = document.getElementById('btn-start');
  const btnPause = document.getElementById('btn-pause');
  const btnFinishPdf = document.getElementById('btn-finish-pdf');
  const btnCancel = document.getElementById('btn-cancel');

  const progressText = document.getElementById('progress-text');
  const progressPercent = document.getElementById('progress-percent');
  const progressBar = document.getElementById('progress-bar');

  // Mode Toggle Behavior
  function updateModeUI() {
    const selectedMode = document.querySelector('input[name="scanMode"]:checked')?.value || 'continuous';
    
    groupTargetPages.classList.add('hidden');
    groupTargetHeading.classList.add('hidden');
    boxContinuous.classList.add('hidden');
    boxSubchapter.classList.add('hidden');
    boxAutoChapter.classList.add('hidden');

    if (selectedMode === 'chapter') {
      groupTargetPages.classList.remove('hidden');
    } else if (selectedMode === 'subchapter') {
      groupTargetHeading.classList.remove('hidden');
      boxSubchapter.classList.remove('hidden');
    } else if (selectedMode === 'auto_chapter') {
      boxAutoChapter.classList.remove('hidden');
    } else {
      boxContinuous.classList.remove('hidden');
    }
  }

  modeRadios.forEach((radio) => {
    radio.addEventListener('change', updateModeUI);
  });

  // Target pages calculation hint
  function updateCalcHint() {
    const val = parseInt(targetPagesInput.value, 10) || 1;
    pagesCalcHint.textContent = `${val} opptak i samlet PDF`;
  }

  targetPagesInput.addEventListener('input', updateCalcHint);

  // Delay Slider Live Display
  delaySlider.addEventListener('input', () => {
    delayValue.textContent = `${parseFloat(delaySlider.value).toFixed(1)}s`;
  });

  // Page Stepper Buttons
  btnPagesDec.addEventListener('click', () => {
    const val = parseInt(targetPagesInput.value, 10) || 1;
    targetPagesInput.value = Math.max(1, val - 1);
    updateCalcHint();
  });

  btnPagesInc.addEventListener('click', () => {
    const val = parseInt(targetPagesInput.value, 10) || 1;
    targetPagesInput.value = Math.min(500, val + 1);
    updateCalcHint();
  });

  // Auto-detect reader type based on URL
  const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (activeTab && activeTab.url) {
    if (activeTab.url.includes('unibok.no')) {
      navModeSelect.value = 'scroll';
    } else if (activeTab.url.includes('smartbok.no')) {
      navModeSelect.value = 'flip';
    }
  }

  if (activeTab && activeTab.title) {
    const cleanTitle = activeTab.title.replace(/[^a-zA-Z0-9æøåÆØÅ_-]/g, '_').substring(0, 30);
    if (cleanTitle && (!pdfNameInput.value || pdfNameInput.value === 'Bok_Skann')) {
      pdfNameInput.value = cleanTitle;
    }
  }

  // Render State
  function renderState(state) {
    if (!state || state.status === 'idle') {
      configForm.classList.remove('hidden');
      progressPanel.classList.add('hidden');
      badgeStatus.className = 'status-pill idle';
      badgeStatus.textContent = 'Klar';
      return;
    }

    configForm.classList.add('hidden');
    progressPanel.classList.remove('hidden');

    const current = state.currentCount || 0;
    const target = state.targetCount || 0;

    if (state.status === 'scanning') {
      badgeStatus.className = 'status-pill scanning';
      badgeStatus.textContent = 'Skanner';
      btnPause.textContent = '⏸ Pause';
      btnFinishPdf.disabled = false;
      btnFinishPdf.innerHTML = `
        <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
          <rect x="6" y="6" width="12" height="12" rx="2"></rect>
        </svg>
        STOPP & LAST NED PDF (${current} opptak)`;
    } else if (state.status === 'paused') {
      badgeStatus.className = 'status-pill paused';
      badgeStatus.textContent = 'Pauset';
      btnPause.textContent = '▶ Fortsett';
    } else if (state.status === 'generating_pdf') {
      badgeStatus.className = 'status-pill pdf';
      badgeStatus.textContent = 'Lager PDF...';
      btnFinishPdf.disabled = true;
      btnFinishPdf.textContent = 'Bygger PDF, vennligst vent...';
    }

    if (state.mode === 'chapter' && target > 0) {
      const pct = Math.min(100, Math.round((current / target) * 100));
      progressText.textContent = `Opptak ${current} av ${target}`;
      progressPercent.textContent = `${pct}%`;
      progressBar.style.width = `${pct}%`;
    } else if (state.mode === 'subchapter') {
      progressText.textContent = `Opptak ${current} (Undertema)`;
      progressPercent.textContent = 'Aktiv';
      progressBar.style.width = '100%';
    } else if (state.mode === 'auto_chapter') {
      progressText.textContent = `Opptak ${current} (Helt kapittel)`;
      progressPercent.textContent = 'Aktiv';
      progressBar.style.width = '100%';
    } else {
      progressText.textContent = `Opptak ${current}`;
      progressPercent.textContent = 'Løpende';
      progressBar.style.width = '100%';
    }
  }

  // Initial Sync from Storage
  const storageData = await chrome.storage.local.get('scanState');
  if (storageData && storageData.scanState) {
    renderState(storageData.scanState);
  }

  // Real-time Storage Listener
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.scanState) {
      renderState(changes.scanState.newValue);
    }
  });

  // Start Button Click
  configForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.id) {
      alert('Vennligst åpne boksiden i den aktive fanen før du starter.');
      return;
    }

    const selectedMode = document.querySelector('input[name="scanMode"]:checked')?.value || 'continuous';
    const navMode = navModeSelect.value || 'auto';
    const targetPages = parseInt(targetPagesInput.value, 10) || 15;
    const targetHeading = targetHeadingInput.value.trim();
    const delayMs = Math.round(parseFloat(delaySlider.value) * 1000);
    const pdfFilename = pdfNameInput.value.trim() || 'Bok_Skann';

    await chrome.runtime.sendMessage({
      type: 'START_SCAN',
      config: {
        tabId: tab.id,
        windowId: tab.windowId,
        mode: selectedMode,
        navMode: navMode,
        targetPages: targetPages,
        targetHeading: targetHeading,
        delayMs: delayMs,
        pdfFilename: pdfFilename
      }
    });
  });

  // Pause / Resume Button
  btnPause.addEventListener('click', async () => {
    await chrome.runtime.sendMessage({ type: 'SCAN_TOGGLE_PAUSE' });
  });

  // Finish & Generate PDF Button
  btnFinishPdf.addEventListener('click', async () => {
    btnFinishPdf.disabled = true;
    btnFinishPdf.textContent = 'Bygger PDF...';
    await chrome.runtime.sendMessage({ type: 'SCAN_FINISH_PDF' });
  });

  // Cancel Button
  btnCancel.addEventListener('click', async () => {
    if (confirm('Er du sikker på at du vil avbryte og forkaste opptaket?')) {
      await chrome.runtime.sendMessage({ type: 'CANCEL_SCAN' });
    }
  });

  // Initial Mode UI state
  updateModeUI();
  updateCalcHint();
});
