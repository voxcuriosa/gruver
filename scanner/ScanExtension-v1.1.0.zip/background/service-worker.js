// Background Service Worker for ScanExtension

let scanSession = {
  active: false,
  status: 'idle',
  mode: 'continuous',
  navMode: 'auto',
  tabId: null,
  windowId: null,
  currentCount: 0,
  targetCount: 0,
  targetHeading: '',
  delayMs: 2000,
  pdfFilename: 'Bok_Skann.pdf',
  pages: [], // Array of { image: dataUrl, textNodes: [], bookBounds: {} }
  initialHeadings: [],
  lastPageCropBottomY: null,
  lastPageCropAction: null
};

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

async function updateStoredState() {
  const safeState = {
    active: scanSession.active,
    status: scanSession.status,
    mode: scanSession.mode,
    navMode: scanSession.navMode,
    tabId: scanSession.tabId,
    currentCount: scanSession.currentCount,
    targetCount: scanSession.targetCount,
    targetHeading: scanSession.targetHeading,
    delayMs: scanSession.delayMs,
    pdfFilename: scanSession.pdfFilename,
    pageCount: scanSession.pages.length
  };
  await chrome.storage.local.set({ scanState: safeState });

  if (scanSession.status === 'scanning') {
    await chrome.action.setBadgeText({ text: String(scanSession.currentCount) });
    await chrome.action.setBadgeBackgroundColor({ color: '#4F46E5' });
  } else if (scanSession.status === 'paused') {
    await chrome.action.setBadgeText({ text: '⏸' });
    await chrome.action.setBadgeBackgroundColor({ color: '#F59E0B' });
  } else if (scanSession.status === 'generating_pdf') {
    await chrome.action.setBadgeText({ text: 'PDF' });
    await chrome.action.setBadgeBackgroundColor({ color: '#10B981' });
  } else {
    await chrome.action.setBadgeText({ text: '' });
  }
}

async function captureCurrentTab() {
  try {
    const dataUrl = await chrome.tabs.captureVisibleTab(scanSession.windowId, {
      format: 'png'
    });

    if (dataUrl) {
      let textNodes = [];
      let bookBounds = null;
      try {
        const textRes = await chrome.tabs.sendMessage(scanSession.tabId, { action: 'EXTRACT_PAGE_TEXT' });
        if (textRes) {
          if (textRes.textNodes) textNodes = textRes.textNodes;
          if (textRes.bookBounds) bookBounds = textRes.bookBounds;
        }
      } catch (e) {}

      scanSession.pages.push({
        image: dataUrl,
        textNodes: textNodes,
        bookBounds: bookBounds
      });
      scanSession.currentCount = scanSession.pages.length;
      await updateStoredState();
      return true;
    }
  } catch (err) {
    console.error('Failed to capture tab screenshot:', err);
  }
  return false;
}

const CURRENT_VERSION = '1.1.0';

// Ensure content script is active and matches current version (re-injects dynamically if outdated)
async function ensureContentScriptInjected(tabId) {
  try {
    const res = await chrome.tabs.sendMessage(tabId, { action: 'PING' });
    if (res && res.pong && res.version === CURRENT_VERSION) {
      return true;
    }
  } catch (err) {}

  console.log('Injecting updated content script into tab:', tabId);
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tabId },
      files: ['content/content.js']
    });
    await sleep(150);
    return true;
  } catch (injectErr) {
    console.error('Failed to inject content script:', injectErr);
  }
  return false;
}

async function startScan(config) {
  await ensureContentScriptInjected(config.tabId);

  scanSession = {
    active: true,
    status: 'scanning',
    mode: config.mode || 'continuous',
    navMode: config.navMode || 'auto',
    tabId: config.tabId,
    windowId: config.windowId,
    currentCount: 0,
    targetCount: config.mode === 'chapter' ? parseInt(config.targetPages, 10) : 0,
    targetHeading: config.targetHeading || '',
    delayMs: Math.max(500, parseInt(config.delayMs, 10) || 2000),
    pdfFilename: config.pdfFilename || 'Bok_Skann.pdf',
    pages: [],
    initialHeadings: [],
    lastPageCropBottomY: null,
    lastPageCropAction: null
  };

  try {
    const res = await chrome.tabs.sendMessage(scanSession.tabId, { action: 'GET_HEADINGS' });
    if (res && res.headings) {
      scanSession.initialHeadings = res.headings;
    }
  } catch (e) {}

  await updateStoredState();
  runScanLoop();
}

async function runScanLoop() {
  while (scanSession.active && scanSession.status === 'scanning') {
    await sleep(scanSession.delayMs);

    if (!scanSession.active || scanSession.status !== 'scanning') break;

    await captureCurrentTab();

    if (scanSession.mode === 'chapter' && scanSession.targetCount > 0 && scanSession.currentCount >= scanSession.targetCount) {
      await finishAndGeneratePDF();
      break;
    }

    try {
      const res = await chrome.tabs.sendMessage(scanSession.tabId, {
        action: 'TRIGGER_NEXT_PAGE',
        navMode: scanSession.navMode,
        scanMode: scanSession.mode,
        initialHeadings: scanSession.initialHeadings,
        targetHeading: scanSession.targetHeading,
        currentCount: scanSession.currentCount
      });

      if (res && (res.method === 'subchapter_finished' || res.method === 'chapter_finished')) {
        console.log('Skanning ferdig! Ny overskrift nådd:', res.reachedHeading, 'Handling:', res.cropAction);
        if (res.cropBottomY) {
          scanSession.lastPageCropBottomY = res.cropBottomY;
        }
        if (res.cropAction) {
          scanSession.lastPageCropAction = res.cropAction;
        }
        await finishAndGeneratePDF();
        break;
      }

      if (res && res.atBottom && (scanSession.mode === 'auto_chapter' || scanSession.mode === 'subchapter')) {
        console.log('Nådde bunnen av kapittelet. Tar siste opptak av bunnen...');
        await sleep(scanSession.delayMs);
        await captureCurrentTab();
        await finishAndGeneratePDF();
        break;
      }
    } catch (e) {
      console.warn('Could not trigger navigation on tab:', e);
    }
  }
}

// Compile captured images to PDF with Precise Book Viewport Cropping & 2-Page Boundary Trimming
async function finishAndGeneratePDF() {
  if (scanSession.pages.length === 0) {
    scanSession.status = 'idle';
    scanSession.active = false;
    await updateStoredState();
    return;
  }

  scanSession.status = 'generating_pdf';
  await updateStoredState();

  try {
    const tabId = scanSession.tabId;
    let pageRecords = [...scanSession.pages];
    const isVerticalScroll = scanSession.navMode === 'scroll' || scanSession.navMode === 'auto';
    const lastCropY = scanSession.lastPageCropBottomY;
    const lastCropAction = scanSession.lastPageCropAction;
    const filename = scanSession.pdfFilename.endsWith('.pdf')
      ? scanSession.pdfFilename
      : `${scanSession.pdfFilename}.pdf`;

    // Handle 2-page spread chapter boundary: If the new chapter started on the left page, drop the last spread
    if (lastCropAction === 'discard_last_spread' && pageRecords.length > 1) {
      console.log('Dropper siste opptak fordi nytt kapittel startet på venstre side');
      pageRecords.pop();
    }

    const keepLeftHalfOnlyOnLast = (lastCropAction === 'keep_left_half_only');

    await chrome.scripting.executeScript({
      target: { tabId: tabId },
      files: ['lib/jspdf.umd.min.js']
    });

    await chrome.scripting.executeScript({
      target: { tabId: tabId },
      func: async (pageData, outputFilename, isVertical, lastPageCropY, keepLeftHalf) => {
        const { jsPDF, GState } = window.jspdf;
        if (!jsPDF) {
          throw new Error('jsPDF library not loaded');
        }

        const loadImage = (src) => new Promise((resolve) => {
          const img = new Image();
          img.onload = () => resolve(img);
          img.src = src;
        });

        function findSafeOverlapOffset(canvas1, canvas2) {
          const w = canvas1.width;
          const h1 = canvas1.height;
          const h2 = canvas2.height;

          const ctx1 = canvas1.getContext('2d');
          const ctx2 = canvas2.getContext('2d');

          const stripeH = 30;
          const stripeY1 = Math.max(0, h1 - 160);
          const stripeData1 = ctx1.getImageData(Math.floor(w * 0.15), stripeY1, Math.floor(w * 0.7), stripeH).data;

          const searchMaxY = Math.floor(h2 * 0.65);
          let bestY2 = -1;
          let minDiff = Infinity;

          for (let y2 = 10; y2 < searchMaxY; y2 += 2) {
            const stripeData2 = ctx2.getImageData(Math.floor(w * 0.15), y2, Math.floor(w * 0.7), stripeH).data;
            let diff = 0;
            const step = 8;

            for (let i = 0; i < stripeData1.length; i += step) {
              diff += Math.abs(stripeData1[i] - stripeData2[i]) +
                      Math.abs(stripeData1[i + 1] - stripeData2[i + 1]) +
                      Math.abs(stripeData1[i + 2] - stripeData2[i + 2]);
            }

            if (diff < minDiff) {
              minDiff = diff;
              bestY2 = y2;
            }
          }

          const avgPixelDiff = minDiff / (stripeData1.length / 4);
          if (avgPixelDiff < 18 && bestY2 > 0) {
            const calculatedOverlap = bestY2 + (h1 - stripeY1);
            const safeOverlap = Math.max(0, calculatedOverlap - 45);
            return Math.min(h2 - 100, safeOverlap);
          }

          return 0;
        }

        const loadedImgs = [];
        for (const item of pageData) {
          const imgSrc = typeof item === 'string' ? item : item.image;
          loadedImgs.push(await loadImage(imgSrc));
        }

        const rawW = loadedImgs[0].naturalWidth || loadedImgs[0].width || 1200;
        const rawH = loadedImgs[0].naturalHeight || loadedImgs[0].height || 800;
        const dpr = rawH / window.innerHeight;

        let doc = null;

        const canvas1 = document.createElement('canvas');
        const ctx1 = canvas1.getContext('2d');

        const canvas2 = document.createElement('canvas');
        const ctx2 = canvas2.getContext('2d');

        // Render invisible text layer aligned strictly to cropped book page coordinates
        function renderInvisibleTextLayer(textNodes, originX = 0, originY = 0, offsetY = 0, maxAllowedW = Infinity, maxAllowedY = Infinity) {
          if (!textNodes || textNodes.length === 0) return;

          try {
            doc.saveGraphicsState();
            if (GState) {
              doc.setGState(new GState({ opacity: 0 }));
            }
            doc.internal.write('3 Tr');
            doc.setFont('helvetica', 'normal');

            textNodes.forEach(node => {
              const scaledX = (node.x - originX) * dpr;
              const scaledY = ((node.y - originY) * dpr) - offsetY;
              const fsPx = (node.fontSize || 16) * dpr;

              if (scaledX >= -5 && scaledX + 5 <= maxAllowedW && scaledY >= -8 && scaledY + (fsPx * 0.5) <= maxAllowedY + 12) {
                const ptSize = Math.max(7, Math.round(fsPx * 0.75));
                doc.setFontSize(ptSize);

                const baselineY = Math.round(scaledY + (fsPx * 0.78));
                doc.text(node.text, scaledX, baselineY);
              }
            });

            doc.internal.write('0 Tr');
            doc.restoreGraphicsState();
          } catch (e) {
            console.warn('Could not write invisible text layer:', e);
          }
        }

        for (let i = 0; i < loadedImgs.length; i++) {
          const isLastImage = (i === loadedImgs.length - 1);
          const currentNodes = pageData[i]?.textNodes || [];
          const bounds = pageData[i]?.bookBounds;

          // Determine exact book bounding box on the screen
          let originX = 0;
          let originY = 0;
          let pageW = rawW;
          let pageH = rawH;

          if (bounds && bounds.cropW > 100 && bounds.cropH > 100) {
            originX = Math.round(bounds.cropX);
            originY = Math.round(bounds.cropY);
            pageW = Math.round(bounds.cropW * dpr);
            pageH = Math.round(bounds.cropH * dpr);

            if (isLastImage && keepLeftHalf && bounds.leftPageWidth) {
              pageW = Math.round(bounds.leftPageWidth * dpr);
            }
          }

          const srcX = Math.round(originX * dpr);
          const srcY = Math.round(originY * dpr);

          if (i === 0) {
            canvas1.width = pageW;
            canvas1.height = pageH;
            ctx1.drawImage(loadedImgs[0], srcX, srcY, pageW, pageH, 0, 0, pageW, pageH);

            let finalH = pageH;
            if (isLastImage && lastPageCropY && lastPageCropY > 100) {
              const maxPhysicalH = Math.floor((lastPageCropY - originY) * dpr);
              if (maxPhysicalH > 50 && maxPhysicalH < pageH) {
                finalH = maxPhysicalH;
              }
            }

            const isLandscape = pageW > finalH;
            doc = new jsPDF({
              orientation: isLandscape ? 'landscape' : 'portrait',
              unit: 'px',
              format: [pageW, finalH],
              hotfixes: ['px_scaling']
            });

            if (finalH < pageH) {
              const singleCanvas = document.createElement('canvas');
              singleCanvas.width = pageW;
              singleCanvas.height = finalH;
              singleCanvas.getContext('2d').drawImage(canvas1, 0, 0, pageW, finalH, 0, 0, pageW, finalH);
              doc.addImage(singleCanvas.toDataURL('image/png'), 'PNG', 0, 0, pageW, finalH);
              renderInvisibleTextLayer(currentNodes, originX, originY, 0, pageW, finalH);
            } else {
              doc.addImage(canvas1.toDataURL('image/png'), 'PNG', 0, 0, pageW, pageH);
              renderInvisibleTextLayer(currentNodes, originX, originY, 0, pageW, pageH);
            }
          } else {
            canvas2.width = pageW;
            canvas2.height = pageH;
            ctx2.clearRect(0, 0, pageW, pageH);
            ctx2.drawImage(loadedImgs[i], srcX, srcY, pageW, pageH, 0, 0, pageW, pageH);

            let cropTop = 0;
            if (isVertical) {
              cropTop = findSafeOverlapOffset(canvas1, canvas2);
            }

            let finalHeight = pageH - cropTop;
            if (isLastImage && lastPageCropY && lastPageCropY > 100) {
              const maxPhysicalY = Math.floor((lastPageCropY - originY) * dpr);
              if (maxPhysicalY > cropTop + 50) {
                finalHeight = maxPhysicalY - cropTop;
              }
            }

            const isLandscape = pageW > finalHeight;
            doc.addPage([pageW, finalHeight], isLandscape ? 'landscape' : 'portrait');

            if (cropTop > 10 || finalHeight < pageH - 10) {
              const slicedCanvas = document.createElement('canvas');
              slicedCanvas.width = pageW;
              slicedCanvas.height = finalHeight;
              const sCtx = slicedCanvas.getContext('2d');
              sCtx.drawImage(canvas2, 0, cropTop, pageW, finalHeight, 0, 0, pageW, finalHeight);

              doc.addImage(slicedCanvas.toDataURL('image/png'), 'PNG', 0, 0, pageW, finalHeight);
              renderInvisibleTextLayer(currentNodes, originX, originY, cropTop, pageW, finalHeight);
            } else {
              doc.addImage(canvas2.toDataURL('image/png'), 'PNG', 0, 0, pageW, pageH);
              renderInvisibleTextLayer(currentNodes, originX, originY, 0, pageW, pageH);
            }

            canvas1.width = pageW;
            canvas1.height = pageH;
            ctx1.clearRect(0, 0, pageW, pageH);
            ctx1.drawImage(canvas2, 0, 0);
          }
        }

        doc.save(outputFilename);
      },
      args: [pageRecords, filename, isVerticalScroll, lastCropY, keepLeftHalfOnlyOnLast]
    });
  } catch (err) {
    console.error('Error generating PDF:', err);
  } finally {
    scanSession.status = 'idle';
    scanSession.active = false;
    scanSession.pages = [];
    scanSession.lastPageCropBottomY = null;
    scanSession.lastPageCropAction = null;
    await updateStoredState();
  }
}

async function cancelScan() {
  scanSession.active = false;
  scanSession.status = 'idle';
  scanSession.pages = [];
  scanSession.currentCount = 0;
  scanSession.lastPageCropBottomY = null;
  scanSession.lastPageCropAction = null;
  await updateStoredState();
}

async function togglePause() {
  if (scanSession.status === 'scanning') {
    scanSession.status = 'paused';
    await updateStoredState();
  } else if (scanSession.status === 'paused') {
    scanSession.status = 'scanning';
    await updateStoredState();
    runScanLoop();
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    switch (message.type) {
      case 'START_SCAN':
        await startScan(message.config);
        sendResponse({ success: true });
        break;

      case 'SCAN_TOGGLE_PAUSE':
        await togglePause();
        sendResponse({ success: true, status: scanSession.status });
        break;

      case 'SCAN_FINISH_PDF':
        await finishAndGeneratePDF();
        sendResponse({ success: true });
        break;

      case 'CANCEL_SCAN':
        await cancelScan();
        sendResponse({ success: true });
        break;

      case 'GET_SCAN_STATUS':
        sendResponse({
          active: scanSession.active,
          status: scanSession.status,
          mode: scanSession.mode,
          navMode: scanSession.navMode,
          currentCount: scanSession.currentCount,
          targetCount: scanSession.targetCount,
          targetHeading: scanSession.targetHeading,
          delayMs: scanSession.delayMs,
          pdfFilename: scanSession.pdfFilename,
          pageCount: scanSession.pages.length
        });
        break;

      default:
        sendResponse({ error: 'Unknown message type' });
    }
  })();
  return true;
});
