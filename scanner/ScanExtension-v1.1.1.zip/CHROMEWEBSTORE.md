# Chrome Web Store Listing & Metadata

## Norwegian (no)

### Extension Information
- **Title**: ScanExtension - Bok & PDF Skanner
- **Short Name**: ScanExtension
- **Version**: 1.0.0
- **Summary**: Automatisk sideskanning, høyoppløselig bildeopptak og søkbar PDF-generering for digitale e-bøker og nettbaserte lesere.
- **Category**: Productivity
- **Language**: Norwegian (no)

### Detailed Description
ScanExtension er et produktivitetsverktøy for elever, studenter og forskere som forenkler studiearbeid og offline-lesing.

Hovedfunksjoner:
- Automatisk sideskanning og jevn blaing
- Høyoppløselig opptak i original bildekvalitet
- Automatisk opprettelse av søkbart usynlig tekstlag (Searchable PDF)
- Mulighet til å markere tekst og søke med Cmd+F i PDF-en
- 100% lokalt og sikkert: Ingen data samles inn eller sendes til eksterne servere

---

## English (en)

### Extension Information
- **Title**: ScanExtension - E-Book & PDF Scanner
- **Short Name**: ScanExtension
- **Version**: 1.0.0
- **Summary**: Automated page scanning, high-resolution capture, and searchable PDF generation for web-based e-books and documents.
- **Category**: Productivity
- **Language**: English (en)

### Detailed Description
ScanExtension is a productivity and accessibility tool designed for students, researchers, and educators to streamline reading notes, study workflows, and offline access.

Key Features:
- Automated Page Scanning: Automatically turns pages or scrolls through digital documents smoothly.
- Searchable PDF (Invisible Text Layer): Extracts visible text coordinates into an invisible layer, allowing you to select, highlight, copy text, and search with Ctrl+F / Cmd+F in any PDF reader.
- Crystal-Clear Quality: Captures pages in full native resolution with automatic page overlap alignment.
- Configurable Delay & Modes: Custom timing per page (e.g. 1.5–2.5s) to ensure high-resolution assets and graphics are completely rendered.
- 100% Private & Local: All screen captures and PDF compilation are executed entirely inside your browser. No data is collected, tracked, or sent to external servers.

Ideal for studying, organizing reading materials, creating offline course notes, and assistive reading.

---

## Permissions Justification & Privacy

### Single Purpose
Automate page navigation and capture visible reading viewports to compile local searchable PDF documents for study and offline reading.

### Permission Justifications
- **activeTab / tabs**: Required to capture the visible reading viewport of the active tab and monitor reader window dimensions.
- **scripting**: Required to trigger page navigation commands and compile the PDF file client-side within the browser session.
- **storage**: Required to save user preferences (scan delay, scan mode, page limits) locally across browser sessions.
- **downloads**: Required to save the generated PDF file directly to the user's local Downloads folder.
- **host_permissions (<all_urls>)**: Digital e-books, online journals, and learning platforms are hosted across various educational domains and subdomains. Universal host permission is necessary to capture viewports across any web reader.

### Privacy & Data Use
No personal user data is collected, stored on external servers, or transmitted to third parties. All screenshots and PDF assembly are performed 100% locally in the browser.
