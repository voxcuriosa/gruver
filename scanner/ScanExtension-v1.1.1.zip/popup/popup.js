document.addEventListener('DOMContentLoaded', async () => {
  // DOM Elements
  const configForm = document.getElementById('config-form');
  const progressPanel = document.getElementById('progress-panel');
  const badgeStatus = document.getElementById('badge-status');

  const modeRadios = document.getElementsByName('scanMode');
  const groupTargetPages = document.getElementById('group-target-pages');
  const groupTargetHeading = document.getElementById('group-target-heading');
  const targetHeadingInput = document.getElementById('target-heading');

  const boxContinuous = document.getElementById('box-continuous');
  const boxSubchapter = document.getElementById('box-subchapter');
  const boxAutoChapter = document.getElementById('box-auto-chapter');

  const targetPagesInput = document.getElementById('target-pages');
  const pagesCalcHint = document.getElementById('pages-calc-hint');
  const btnPagesDec = document.getElementById('btn-pages-dec');
  const btnPagesInc = document.getElementById('btn-pages-inc');

  const navModeSelect = document.getElementById('nav-mode');
  const delaySlider = document.getElementById('delay-sec');
  const delayValue = document.getElementById('delay-value');
  const pdfNameInput = document.getElementById('pdf-name');

  const btnStart = document.getElementById('btn-start');
  const btnPause = document.getElementById('btn-pause');
  const btnFinishPdf = document.getElementById('btn-finish-pdf');
  const btnCancel = document.getElementById('btn-cancel');

  const progressText = document.getElementById('progress-text');
  const progressPercent = document.getElementById('progress-percent');
  const progressBar = document.getElementById('progress-bar');

  const langBtnNo = document.getElementById('lang-no');
  const langBtnEn = document.getElementById('lang-en');

  // --- i18n Translations Dictionary ---
  const TRANSLATIONS = {
    no: {
      headerSubtitle: "Digital Bok & Dokument Skanner",
      statusIdle: "Klar",
      statusScanning: "Skanner",
      statusPaused: "Pauset",
      statusBuildingPdf: "Lager PDF...",
      btnStopAndSave: "STOPP & LAST NED PDF",
      btnPause: "Pause",
      btnResume: "Fortsett",
      btnCancel: "Forkast",
      labelScanMode: "Skannemodus",
      modeContinuousTitle: "Løpende",
      modeContinuousDesc: "Til du trykker stopp",
      modeSubchapterTitle: "Undertema",
      modeSubchapterDesc: "Stopper ved neste undertittel",
      modeAutoChapterTitle: "Helt kapittel",
      modeAutoChapterDesc: "Til bunnen av kapittelet",
      modeFixedPagesTitle: "Fast antall",
      modeFixedPagesDesc: "F.eks. 15 opptak",
      labelTargetHeading: "Stopp ved overskrift (valgfritt)",
      hintTargetHeading: "f.eks. Livet som jegere",
      placeholderTargetHeading: "Skriv tittel på neste tema å stoppe ved",
      subtextTargetHeading: "Lar deg skanne gjennom hele undertemaet til neste hovedtittel.",
      labelTargetPages: "Antall opptak / skjermbilder",
      calcHint: "{n} opptak i samlet PDF",
      infoContinuous: "Blar/ruller automatisk gjennom boken. Trykk <b>«STOPP & LAST NED PDF»</b> når du er ferdig.",
      infoSubchapter: "Ruller gjennom undertemaet og stopper automatisk når neste store hovedtittel nås.",
      infoAutoChapter: "Ruller gjennom hele kapittelet til bunnen (eller neste hovedkapittel) og genererer PDF automatisk.",
      labelNavMode: "Boktype / Bla-metode",
      navOptionAuto: "Auto-deteksjon (Anbefalt)",
      navOptionScroll: "Vertikal rulling (EPUB / Dokumenter)",
      navOptionFlip: "Horisontal blaing (Oppslag / Piltast)",
      labelDelay: "Ventetid per opptak",
      delayDesc: "Sikrer at all tekst, bilder og grafer rekker å tegnes 100% skarpt.",
      labelPdfName: "PDF Filnavn",
      placeholderPdfName: "Filnavn",
      btnStart: "Start Skanning",
      footerText: "Sikker skanning: 100% innhold bevares uten kutt i tekst eller bilder.",
      alertOpenTab: "Vennligst åpne boksiden i den aktive fanen før du starter.",
      confirmCancel: "Er du sikker på at du vil avbryte og forkaste opptaket?",
      buildingPdfWait: "Bygger PDF, vennligst vent...",
      progressScanText: "Opptak {current} av {target}",
      progressSubchapterText: "Opptak {current} (Undertema)",
      progressChapterText: "Opptak {current} (Helt kapittel)",
      progressContinuousText: "Opptak {current}",
      statusActive: "Aktiv",
      statusContinuous: "Løpende"
    },
    en: {
      headerSubtitle: "Digital E-Book & Document Scanner",
      statusIdle: "Ready",
      statusScanning: "Scanning",
      statusPaused: "Paused",
      statusBuildingPdf: "Generating PDF...",
      btnStopAndSave: "STOP & DOWNLOAD PDF",
      btnPause: "Pause",
      btnResume: "Resume",
      btnCancel: "Discard",
      labelScanMode: "Scanning Mode",
      modeContinuousTitle: "Continuous",
      modeContinuousDesc: "Until you press stop",
      modeSubchapterTitle: "Subchapter",
      modeSubchapterDesc: "Stops at next subsection",
      modeAutoChapterTitle: "Full Chapter",
      modeAutoChapterDesc: "Until end of chapter",
      modeFixedPagesTitle: "Fixed Count",
      modeFixedPagesDesc: "e.g. 15 captures",
      labelTargetHeading: "Stop at heading (optional)",
      hintTargetHeading: "e.g. Life of Hunters",
      placeholderTargetHeading: "Enter heading of next topic to stop at",
      subtextTargetHeading: "Scans through the full subchapter until the next main title.",
      labelTargetPages: "Target captures / pages",
      calcHint: "{n} captures in combined PDF",
      infoContinuous: "Automatically flips/scrolls through the book. Press <b>\"STOP & DOWNLOAD PDF\"</b> when finished.",
      infoSubchapter: "Scrolls through the subchapter and stops automatically when the next major heading is reached.",
      infoAutoChapter: "Scrolls through the full chapter to the end (or next chapter) and generates PDF automatically.",
      labelNavMode: "Reader Type / Navigation",
      navOptionAuto: "Auto-detection (Recommended)",
      navOptionScroll: "Vertical Scrolling (EPUB / Documents)",
      navOptionFlip: "Horizontal Flipping (Spread / Arrow Key)",
      labelDelay: "Delay per capture",
      delayDesc: "Ensures all text, images, and graphics render crisp and clear.",
      labelPdfName: "PDF Filename",
      placeholderPdfName: "Filename",
      btnStart: "Start Scanning",
      footerText: "Safe scanning: 100% content preserved without cropping text or images.",
      alertOpenTab: "Please open the reader tab in your active window before starting.",
      confirmCancel: "Are you sure you want to cancel and discard this scan?",
      buildingPdfWait: "Building PDF, please wait...",
      progressScanText: "Capture {current} of {target}",
      progressSubchapterText: "Capture {current} (Subchapter)",
      progressChapterText: "Capture {current} (Full Chapter)",
      progressContinuousText: "Capture {current}",
      statusActive: "Active",
      statusContinuous: "Continuous"
    }
  };

  let currentLang = 'no';

  function applyLanguage(lang) {
    currentLang = lang;
    const t = TRANSLATIONS[lang] || TRANSLATIONS.no;

    if (lang === 'en') {
      langBtnEn.classList.add('active');
      langBtnNo.classList.remove('active');
    } else {
      langBtnNo.classList.add('active');
      langBtnEn.classList.remove('active');
    }

    document.querySelectorAll('[data-i18n]').forEach(el => {
      const key = el.getAttribute('data-i18n');
      if (t[key]) {
        el.innerHTML = t[key];
      }
    });

    document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
      const key = el.getAttribute('data-i18n-placeholder');
      if (t[key]) {
        el.placeholder = t[key];
      }
    });

    updateCalcHint();
    chrome.storage.local.set({ uiLang: lang });
  }

  langBtnNo.addEventListener('click', () => applyLanguage('no'));
  langBtnEn.addEventListener('click', () => applyLanguage('en'));

  // Load saved language preference or detect browser locale
  const storedLangData = await chrome.storage.local.get('uiLang');
  if (storedLangData && storedLangData.uiLang) {
    applyLanguage(storedLangData.uiLang);
  } else {
    const navLang = (navigator.language || 'no').toLowerCase();
    if (navLang.startsWith('no') || navLang.startsWith('nb') || navLang.startsWith('nn')) {
      applyLanguage('no');
    } else {
      applyLanguage('en');
    }
  }

  // Mode Toggle Behavior
  function updateModeUI() {
    const selectedMode = document.querySelector('input[name="scanMode"]:checked')?.value || 'continuous';
    
    groupTargetPages.classList.add('hidden');
    groupTargetHeading.classList.add('hidden');
    boxContinuous.classList.add('hidden');
    boxSubchapter.classList.add('hidden');
    boxAutoChapter.classList.add('hidden');

    if (selectedMode === 'chapter') {
      groupTargetPages.classList.remove('hidden');
    } else if (selectedMode === 'subchapter') {
      groupTargetHeading.classList.remove('hidden');
      boxSubchapter.classList.remove('hidden');
    } else if (selectedMode === 'auto_chapter') {
      boxAutoChapter.classList.remove('hidden');
    } else {
      boxContinuous.classList.remove('hidden');
    }
  }

  modeRadios.forEach((radio) => {
    radio.addEventListener('change', updateModeUI);
  });

  // Target pages calculation hint
  function updateCalcHint() {
    const t = TRANSLATIONS[currentLang] || TRANSLATIONS.no;
    const val = parseInt(targetPagesInput.value, 10) || 1;
    pagesCalcHint.textContent = t.calcHint.replace('{n}', val);
  }

  targetPagesInput.addEventListener('input', updateCalcHint);

  // Delay Slider Live Display
  delaySlider.addEventListener('input', () => {
    delayValue.textContent = `${parseFloat(delaySlider.value).toFixed(1)}s`;
  });

  // Page Stepper Buttons
  btnPagesDec.addEventListener('click', () => {
    const val = parseInt(targetPagesInput.value, 10) || 1;
    targetPagesInput.value = Math.max(1, val - 1);
    updateCalcHint();
  });

  btnPagesInc.addEventListener('click', () => {
    const val = parseInt(targetPagesInput.value, 10) || 1;
    targetPagesInput.value = Math.min(500, val + 1);
    updateCalcHint();
  });

  // Auto-detect reader type based on URL
  const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (activeTab && activeTab.url) {
    if (activeTab.url.includes('unibok.no')) {
      navModeSelect.value = 'scroll';
    } else if (activeTab.url.includes('smartbok.no')) {
      navModeSelect.value = 'flip';
    }
  }

  if (activeTab && activeTab.title) {
    const cleanTitle = activeTab.title.replace(/[^a-zA-Z0-9æøåÆØÅ_-]/g, '_').substring(0, 30);
    if (cleanTitle && (!pdfNameInput.value || pdfNameInput.value === 'Bok_Skann' || pdfNameInput.value === 'Book_Scan')) {
      pdfNameInput.value = cleanTitle;
    }
  }

  // Render State
  function renderState(state) {
    const t = TRANSLATIONS[currentLang] || TRANSLATIONS.no;

    if (!state || state.status === 'idle') {
      configForm.classList.remove('hidden');
      progressPanel.classList.add('hidden');
      badgeStatus.className = 'status-pill idle';
      badgeStatus.textContent = t.statusIdle;
      return;
    }

    configForm.classList.add('hidden');
    progressPanel.classList.remove('hidden');

    const current = state.currentCount || 0;
    const target = state.targetCount || 0;

    if (state.status === 'scanning') {
      badgeStatus.className = 'status-pill scanning';
      badgeStatus.textContent = t.statusScanning;
      btnPause.textContent = `⏸ ${t.btnPause}`;
      btnFinishPdf.disabled = false;
      btnFinishPdf.innerHTML = `
        <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
          <rect x="6" y="6" width="12" height="12" rx="2"></rect>
        </svg>
        ${t.btnStopAndSave} (${current})`;
    } else if (state.status === 'paused') {
      badgeStatus.className = 'status-pill paused';
      badgeStatus.textContent = t.statusPaused;
      btnPause.textContent = `▶ ${t.btnResume}`;
    } else if (state.status === 'generating_pdf') {
      badgeStatus.className = 'status-pill pdf';
      badgeStatus.textContent = t.statusBuildingPdf;
      btnFinishPdf.disabled = true;
      btnFinishPdf.textContent = t.buildingPdfWait;
    }

    if (state.mode === 'chapter' && target > 0) {
      const pct = Math.min(100, Math.round((current / target) * 100));
      progressText.textContent = t.progressScanText.replace('{current}', current).replace('{target}', target);
      progressPercent.textContent = `${pct}%`;
      progressBar.style.width = `${pct}%`;
    } else if (state.mode === 'subchapter') {
      progressText.textContent = t.progressSubchapterText.replace('{current}', current);
      progressPercent.textContent = t.statusActive;
      progressBar.style.width = '100%';
    } else if (state.mode === 'auto_chapter') {
      progressText.textContent = t.progressChapterText.replace('{current}', current);
      progressPercent.textContent = t.statusActive;
      progressBar.style.width = '100%';
    } else {
      progressText.textContent = t.progressContinuousText.replace('{current}', current);
      progressPercent.textContent = t.statusContinuous;
      progressBar.style.width = '100%';
    }
  }

  // Initial Sync from Storage
  const storageData = await chrome.storage.local.get('scanState');
  if (storageData && storageData.scanState) {
    renderState(storageData.scanState);
  }

  // Real-time Storage Listener
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.scanState) {
      renderState(changes.scanState.newValue);
    }
  });

  // Start Button Click
  configForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const t = TRANSLATIONS[currentLang] || TRANSLATIONS.no;

    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.id) {
      alert(t.alertOpenTab);
      return;
    }

    const selectedMode = document.querySelector('input[name="scanMode"]:checked')?.value || 'continuous';
    const navMode = navModeSelect.value || 'auto';
    const targetPages = parseInt(targetPagesInput.value, 10) || 15;
    const targetHeading = targetHeadingInput.value.trim();
    const delayMs = Math.round(parseFloat(delaySlider.value) * 1000);
    const pdfFilename = pdfNameInput.value.trim() || (currentLang === 'en' ? 'Book_Scan' : 'Bok_Skann');

    await chrome.runtime.sendMessage({
      type: 'START_SCAN',
      config: {
        tabId: tab.id,
        windowId: tab.windowId,
        mode: selectedMode,
        navMode: navMode,
        targetPages: targetPages,
        targetHeading: targetHeading,
        delayMs: delayMs,
        pdfFilename: pdfFilename
      }
    });
  });

  // Pause / Resume Button
  btnPause.addEventListener('click', async () => {
    await chrome.runtime.sendMessage({ type: 'SCAN_TOGGLE_PAUSE' });
  });

  // Finish & Generate PDF Button
  btnFinishPdf.addEventListener('click', async () => {
    const t = TRANSLATIONS[currentLang] || TRANSLATIONS.no;
    btnFinishPdf.disabled = true;
    btnFinishPdf.textContent = t.statusBuildingPdf;
    await chrome.runtime.sendMessage({ type: 'SCAN_FINISH_PDF' });
  });

  // Cancel Button
  btnCancel.addEventListener('click', async () => {
    const t = TRANSLATIONS[currentLang] || TRANSLATIONS.no;
    if (confirm(t.confirmCancel)) {
      await chrome.runtime.sendMessage({ type: 'CANCEL_SCAN' });
    }
  });

  // Initial Mode UI state
  updateModeUI();
  updateCalcHint();
});
