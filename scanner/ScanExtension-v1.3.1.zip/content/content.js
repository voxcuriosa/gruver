(() => {
  if (window.top !== window) {
    return;
  }

  let hiddenElements = [];

  const existingOverlay = document.getElementById('scanext-overlay');
  if (existingOverlay) {
    existingOverlay.remove();
  }

  function hideObstructingToolbars() {
    const isUnibok = window.location.hostname.includes('unibok.no');
    if (!isUnibok) return;

    const selectors = [
      '.topbar',
      '#topbar',
      '.bottombar',
      '#bottombar',
      '.audioWrapper',
      '.chapter-navigation--top',
      '.chapter-navigation--bottom',
      '[class*="chapter-navigation"]',
      '[class*="top-bar"]',
      '[class*="header-bar"]',
      '#bookmark-popup',
      '#contextmenu',
      '#aiContextMenu'
    ];

    selectors.forEach(sel => {
      document.querySelectorAll(sel).forEach(el => {
        if (el && el.id !== 'scanext-overlay' && el.style.display !== 'none' && !el.dataset.scanextHidden) {
          el.dataset.scanextOrigDisplay = el.style.display || '';
          el.style.display = 'none';
          el.dataset.scanextHidden = 'true';
          hiddenElements.push(el);
        }
      });
    });
  }

  function restoreToolbars() {
    hiddenElements.forEach(el => {
      if (el && el.dataset.scanextHidden) {
        el.style.display = el.dataset.scanextOrigDisplay || '';
        delete el.dataset.scanextHidden;
        delete el.dataset.scanextOrigDisplay;
      }
    });
    hiddenElements = [];
  }

  function isConclusionHeading(text) {
    if (!text) return false;
    return /sammendrag|oppsummering|dybdelæring|dybdelaring|oppgaver|oppgåver|repetisjon|kilder|kjelder|arbeidsoppgaver|litteraturliste|dette kapitlet|dette kapittelet|har du fått med deg|å gjere|å gjøre|samanhengar|sammenhenger|perspektiv|tilbakeblikk|hva har du lært|kva har du lært/i.test(text);
  }

  function isChapterOpeningMarker(text) {
    if (!text) return false;
    if (isConclusionHeading(text)) return false;
    const clean = text.trim();

    if (/^(innhald|innhold|slik såg det ut|slik så det ut|dette har hendt|dette har skjedd)\b/i.test(clean)) {
      return true;
    }

    if (/^(kapittel\s*\d+|del\s*\d+|unit\s*\d+|chapter\s*\d+|tema\s*\d+)\b/i.test(clean)) {
      return true;
    }

    if (/^(?:verda|verden|norge|noreg|noregs|europa|norden)\s+(?:\d{3,4}\s*[-–—]\s*\d{3,4}|\d{3,4}\s+og\s+\d{3,4})/i.test(clean)) {
      return true;
    }

    return false;
  }

  function isIframeCurrentlyVisible(iframe) {
    if (!iframe) return false;
    const style = window.getComputedStyle(iframe);
    if (style.display === 'none' || style.visibility === 'hidden' || parseFloat(style.opacity) < 0.1) {
      return false;
    }
    const rect = iframe.getBoundingClientRect();
    if (rect.width < 50 || rect.height < 50) return false;
    if (rect.right < 0 || rect.left > window.innerWidth) return false;
    return true;
  }

  function parseSmartbokChapter(pageAttr) {
    if (!pageAttr) return null;
    const clean = pageAttr.replace(/^\d+[\s_.-]+/, '').trim();
    if (!clean || isConclusionHeading(clean)) return null;

    const prefixMatch = clean.match(/^((?:del|kapittel|kap|unit|chapter|tema)\s*\d+)/i);
    if (prefixMatch) {
      return { fullSection: clean, mainChapter: prefixMatch[1].toUpperCase() };
    }

    const codeMatch = clean.match(/^([A-Za-z]?\d+)[A-Za-z.-]?/);
    if (codeMatch && codeMatch[1].length <= 5) {
      return { fullSection: clean, mainChapter: codeMatch[1].toUpperCase() };
    }

    const split = clean.split(/[:–-]/)[0].trim();
    if (/^(del|kapittel|kap|unit|chapter|tema)\b/i.test(split) || /^[A-Z]\d+/i.test(split)) {
      return { fullSection: clean, mainChapter: split.toUpperCase() };
    }

    return null;
  }

  // Group individual words into natural horizontal lines strictly matching 2D column and block boundaries
  function assembleWordsIntoLines(words) {
    if (!words || words.length === 0) return [];

    // Step 1: Group words into horizontal line segments (words on same Y with normal word gaps)
    words.sort((a, b) => {
      if (Math.abs(a.y - b.y) <= 5) {
        return a.x - b.x;
      }
      return a.y - b.y;
    });

    const rawLines = [];
    let curLine = null;

    words.forEach(word => {
      if (!curLine) {
        curLine = {
          words: [word.text],
          x: word.x,
          y: word.y,
          maxX: word.x + word.w,
          h: word.h,
          fontSize: word.fontSize
        };
      } else {
        const sameY = Math.abs(word.y - curLine.y) <= 5;
        const xGap = word.x - curLine.maxX;
        const maxWordGap = Math.min(12, (word.fontSize || 14) * 0.7);

        if (sameY && xGap >= -4 && xGap <= maxWordGap) {
          curLine.words.push(word.text);
          curLine.maxX = Math.max(curLine.maxX, word.x + word.w);
          curLine.h = Math.max(curLine.h, word.h);
        } else {
          rawLines.push({
            text: curLine.words.join(' '),
            x: curLine.x,
            y: curLine.y,
            maxX: curLine.maxX,
            w: curLine.maxX - curLine.x,
            h: curLine.h,
            fontSize: curLine.fontSize
          });
          curLine = {
            words: [word.text],
            x: word.x,
            y: word.y,
            maxX: word.x + word.w,
            h: word.h,
            fontSize: word.fontSize
          };
        }
      }
    });

    if (curLine) {
      rawLines.push({
        text: curLine.words.join(' '),
        x: curLine.x,
        y: curLine.y,
        maxX: curLine.maxX,
        w: curLine.maxX - curLine.x,
        h: curLine.h,
        fontSize: curLine.fontSize
      });
    }

    if (rawLines.length <= 1) return rawLines;

    // Step 2: Cluster lines into Column Blocks (2D Spatial Block Clustering)
    const blocks = [];

    rawLines.forEach(line => {
      let bestBlock = null;
      let minDist = Infinity;

      for (const block of blocks) {
        const overlap = Math.min(line.maxX, block.maxX) - Math.max(line.x, block.minX);
        const xStartDiff = Math.abs(line.x - block.minX);
        const yGap = line.y - block.maxY;

        // Belongs to the same column block if horizontal overlap exists or left margins align, and vertical gap is within 45px
        if ((overlap > 10 || (xStartDiff <= 18 && overlap >= -5)) && yGap >= -8 && yGap <= 45) {
          if (yGap < minDist) {
            minDist = yGap;
            bestBlock = block;
          }
        }
      }

      if (bestBlock) {
        bestBlock.lines.push(line);
        bestBlock.minX = Math.min(bestBlock.minX, line.x);
        bestBlock.maxX = Math.max(bestBlock.maxX, line.maxX);
        bestBlock.maxY = Math.max(bestBlock.maxY, line.y + line.h);
      } else {
        blocks.push({
          minX: line.x,
          maxX: line.maxX,
          minY: line.y,
          maxY: line.y + line.h,
          lines: [line]
        });
      }
    });

    // Step 3: Sort Blocks in natural reading order (left-to-right columns, top-to-bottom within each column)
    blocks.sort((a, b) => {
      const colDiff = a.minX - b.minX;
      if (Math.abs(colDiff) > 20) {
        return colDiff;
      }
      return a.minY - b.minY;
    });

    // Step 4: Emit all lines within each block in order
    const finalLines = [];
    blocks.forEach(block => {
      block.lines.sort((a, b) => a.y - b.y);
      block.lines.forEach(l => {
        finalLines.push({
          text: l.text,
          x: l.x,
          y: l.y,
          w: l.w,
          h: l.h,
          fontSize: l.fontSize
        });
      });
    });

    return finalLines;
  }

  // Order page text nodes into distinct vertical columns (Left Column first, Right Column second)
  function orderPageTextNodes(nodes, iframeRect) {
    if (!nodes || nodes.length <= 1) return nodes;

    const iframeMidX = iframeRect.left + (iframeRect.width / 2);

    const leftCol = [];
    const rightCol = [];

    nodes.forEach(n => {
      const nodeMidX = n.x + (n.w / 2);
      if (nodeMidX < iframeMidX) {
        leftCol.push(n);
      } else {
        rightCol.push(n);
      }
    });

    if (leftCol.length >= 3 && rightCol.length >= 3) {
      leftCol.sort((a, b) => a.y - b.y);
      rightCol.sort((a, b) => a.y - b.y);
      return [...leftCol, ...rightCol];
    }

    nodes.sort((a, b) => a.y - b.y);
    return nodes;
  }

  // Extract all visible text nodes with exact visual coordinates
  function getVisibleTextNodes() {
    const allLines = [];
    const windowW = window.innerWidth || document.documentElement.clientWidth;
    const windowH = window.innerHeight || document.documentElement.clientHeight;

    const isSmartbok = window.location.hostname.includes('smartbok.no') ||
                       document.querySelector('#default_next_bttn, rightnavigation-view, .kitaboo-right-arrow') !== null;

    // --- SMARTBOK ENGINE ---
    if (isSmartbok) {
      const smartbokIframes = Array.from(document.querySelectorAll('iframe.epub_container_active, iframe[id^="epub_"], iframe'))
        .filter(isIframeCurrentlyVisible)
        .sort((a, b) => a.getBoundingClientRect().left - b.getBoundingClientRect().left);

      smartbokIframes.forEach(iframe => {
        try {
          const iframeDoc = iframe.contentDocument || iframe.contentWindow?.document;
          if (iframeDoc && iframeDoc.body) {
            const iframeRect = iframe.getBoundingClientRect();
            const bodyW = iframeDoc.body.clientWidth || iframeDoc.documentElement.clientWidth || iframeRect.width;
            const bodyH = iframeDoc.body.clientHeight || iframeDoc.documentElement.clientHeight || iframeRect.height;

            const scaleX = bodyW > 0 ? (iframeRect.width / bodyW) : 1;
            const scaleY = bodyH > 0 ? (iframeRect.height / bodyH) : 1;

            const pageNodes = [];

            const textNodes = iframeDoc.querySelectorAll('.smartbok-span, span[id*="textid"], p, text, tspan, h1, h2, h3, h4, [role="text"]');
            textNodes.forEach(node => {
              const txt = node.textContent.trim();
              if (txt.length > 0 && node.children.length === 0) {
                const r = node.getBoundingClientRect();
                const absX = iframeRect.left + (r.left * scaleX);
                const absY = iframeRect.top + (r.top * scaleY);
                const trueW = r.width * scaleX;
                const trueH = r.height * scaleY;

                if (absX >= -20 && absX <= windowW && absY >= -20 && absY <= windowH && trueW > 0 && trueH > 0) {
                  const fs = (parseFloat(window.getComputedStyle(node).fontSize) || 14) * scaleY;
                  pageNodes.push({
                    text: txt,
                    x: Math.round(absX),
                    y: Math.round(absY),
                    w: Math.round(trueW),
                    h: Math.round(trueH),
                    fontSize: fs
                  });
                }
              }
            });

            if (pageNodes.length > 0) {
              const ordered = orderPageTextNodes(pageNodes, iframeRect);
              allLines.push(...ordered);
            }
          }
        } catch (e) {}
      });

      return allLines;
    }

    // --- UNIBOK / HTML EPUB ENGINE ---
    const targetDocs = [];

    document.querySelectorAll('iframe').forEach(iframe => {
      try {
        const iframeDoc = iframe.contentDocument || iframe.contentWindow?.document;
        if (iframeDoc && iframeDoc.body) {
          targetDocs.push({ doc: iframeDoc, offset: iframe.getBoundingClientRect() });
        }
      } catch (e) {}
    });

    targetDocs.push({ doc: document, offset: { left: 0, top: 0 } });

    targetDocs.forEach(({ doc, offset }) => {
      try {
        if (!doc.body) return;

        const walker = doc.createTreeWalker(doc.body, NodeFilter.SHOW_TEXT, {
          acceptNode: (n) => {
            if (!n.textContent || !n.textContent.trim()) return NodeFilter.FILTER_REJECT;
            const parent = n.parentElement;
            if (!parent) return NodeFilter.FILTER_REJECT;
            const tag = parent.tagName.toLowerCase();
            if (tag === 'script' || tag === 'style' || tag === 'noscript' || tag === 'svg') return NodeFilter.FILTER_REJECT;
            if (parent.closest('#scanext-overlay, .topbar, .bottombar, #topbar, #bottombar')) return NodeFilter.FILTER_REJECT;
            return NodeFilter.FILTER_ACCEPT;
          }
        });

        const docWords = [];
        let textNode;

        while ((textNode = walker.nextNode())) {
          const rawText = textNode.textContent;
          if (!rawText || !rawText.trim()) continue;

          const parentEl = textNode.parentElement;
          const fs = parentEl ? (parseFloat(window.getComputedStyle(parentEl).fontSize) || 16) : 16;

          // Split text node into word boundaries using RegEx to measure individual visual line positions
          const wordRegex = /\S+/g;
          let match;

          while ((match = wordRegex.exec(rawText)) !== null) {
            const startIdx = match.index;
            const endIdx = match.index + match[0].length;

            try {
              const wordRange = doc.createRange();
              wordRange.setStart(textNode, startIdx);
              wordRange.setEnd(textNode, endIdx);

              const r = wordRange.getBoundingClientRect();
              const absX = offset.left + r.left;
              const absY = offset.top + r.top;

              if (absX >= -20 && absX <= windowW && absY >= -20 && absY <= windowH && r.width > 1 && r.height > 1) {
                docWords.push({
                  text: match[0],
                  x: Math.round(absX),
                  y: Math.round(absY),
                  w: Math.round(r.width),
                  h: Math.round(r.height),
                  fontSize: fs
                });
              }
            } catch (rErr) {}
          }
        }

        if (docWords.length > 0) {
          const lines = assembleWordsIntoLines(docWords);
          allLines.push(...lines);
        }
      } catch (e) {
        console.warn('Error reading Unibok text:', e);
      }
    });

    return allLines;
  }

  function getVisibleHeadings(onlyMajor = true) {
    const headings = [];
    const windowH = window.innerHeight || document.documentElement.clientHeight;

    const smartbokIframes = document.querySelectorAll('iframe.epub_container_active, iframe[id^="epub_"], iframe');
    smartbokIframes.forEach(iframe => {
      if (!isIframeCurrentlyVisible(iframe)) return;

      try {
        const iframeDoc = iframe.contentDocument || iframe.contentWindow?.document;
        if (iframeDoc && iframeDoc.body) {
          const iframeRect = iframe.getBoundingClientRect();
          const pageAttr = iframeDoc.body.getAttribute('page');
          if (pageAttr) {
            const parsed = parseSmartbokChapter(pageAttr);
            if (parsed && !headings.some(h => h.text === parsed.fullSection)) {
              headings.push({
                text: parsed.fullSection,
                mainChapter: parsed.mainChapter,
                isSmartbokMainChapter: true,
                isChapterOpening: false,
                left: iframeRect.left,
                top: iframeRect.top
              });
            }
          }

          const titleNodes = iframeDoc.querySelectorAll('h1, h2, h3, [class*="title"], [class*="heading"], .smartbok-span, text');
          titleNodes.forEach(node => {
            const text = node.textContent.trim();
            if (text.length >= 3) {
              const fontSize = parseFloat(window.getComputedStyle(node).fontSize) || 0;
              const isOpening = isChapterOpeningMarker(text);

              if (isOpening || fontSize >= 28 || node.tagName === 'H1') {
                if (!isConclusionHeading(text) && !headings.some(h => h.text === text)) {
                  const r = node.getBoundingClientRect();
                  headings.push({
                    text: text,
                    mainChapter: isOpening ? text.toUpperCase() : null,
                    isSmartbokMainChapter: isOpening,
                    isChapterOpening: isOpening,
                    left: iframeRect.left + r.left,
                    top: iframeRect.top + r.top
                  });
                }
              }
            }
          });
        }
      } catch (e) {}
    });

    const unibokSelector = onlyMajor
      ? 'h2, .delkapittel, .undertema, [epub\\:type*="chapter-title"], [class*="section-title"]'
      : 'h1, h2, h3, h4, [class*="title"], [class*="heading"]';

    document.querySelectorAll('iframe').forEach(iframe => {
      if (!isIframeCurrentlyVisible(iframe)) return;

      try {
        const iframeDoc = iframe.contentDocument || iframe.contentWindow?.document;
        if (iframeDoc) {
          const iframeRect = iframe.getBoundingClientRect();
          const nodes = iframeDoc.querySelectorAll(unibokSelector);
          
          nodes.forEach(node => {
            const nodeRect = node.getBoundingClientRect();
            const actualTop = iframeRect.top + nodeRect.top;
            const text = node.textContent.trim();

            if (actualTop >= 40 && actualTop <= windowH - 80 && text.length > 2) {
              if (!isConclusionHeading(text) && !headings.some(h => h.text === text)) {
                headings.push({ text, mainChapter: text.substring(0, 4), top: actualTop });
              }
            }
          });
        }
      } catch (e) {}
    });

    const mainNodes = document.querySelectorAll(unibokSelector);
    mainNodes.forEach(node => {
      const rect = node.getBoundingClientRect();
      const text = node.textContent.trim();
      if (rect.top >= 40 && rect.top <= windowH - 80 && text.length > 2) {
        if (!isConclusionHeading(text) && !headings.some(h => h.text === text)) {
          headings.push({ text, mainChapter: text.substring(0, 4), top: rect.top });
        }
      }
    });

    return headings;
  }

  function normalizeSearchText(str) {
    if (!str) return '';
    return str.toLowerCase()
      .replace(/[\u2013\u2014\u2212-]/g, '-')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function findTargetHeadingPosition(targetText) {
    if (!targetText || !targetText.trim()) return null;
    const search = normalizeSearchText(targetText);
    const windowH = window.innerHeight || document.documentElement.clientHeight;

    let match = null;

    document.querySelectorAll('iframe').forEach(iframe => {
      if (!isIframeCurrentlyVisible(iframe)) return;

      try {
        const iframeDoc = iframe.contentDocument || iframe.contentWindow?.document;
        if (iframeDoc) {
          const pageAttr = iframeDoc.body?.getAttribute('page');
          if (pageAttr && normalizeSearchText(pageAttr).includes(search)) {
            match = { text: pageAttr, top: 0 };
            return;
          }

          const iframeRect = iframe.getBoundingClientRect();
          const nodes = iframeDoc.querySelectorAll('h1, h2, h3, h4, p, div, span, text, tspan, .smartbok-span');
          
          for (const node of nodes) {
            const t = normalizeSearchText(node.textContent);
            if (t.includes(search) && node.children.length === 0) {
              const nodeRect = node.getBoundingClientRect();
              const actualTop = iframeRect.top + nodeRect.top;
              if (actualTop >= 0 && actualTop <= windowH - 20) {
                match = { text: node.textContent.trim(), top: actualTop };
                break;
              }
            }
          }
        }
      } catch (e) {}
    });

    if (match) return match;

    const mainNodes = document.querySelectorAll('h1, h2, h3, h4, p, div, span, text');
    for (const node of mainNodes) {
      const t = normalizeSearchText(node.textContent);
      if (t.includes(search) && node.children.length === 0) {
        const rect = node.getBoundingClientRect();
        if (rect.top >= 0 && rect.top <= windowH - 20) {
          match = { text: node.textContent.trim(), top: rect.top };
          break;
        }
      }
    }

    return match;
  }

  function executeVerticalScroll() {
    const unibokFrame = document.getElementById('scrolled-content-frame');
    const container = (unibokFrame && unibokFrame.scrollHeight > unibokFrame.clientHeight)
      ? unibokFrame
      : (document.querySelector('#reader.layout-scroll, main, [role="main"], article, .pendel-content, .reader-container') || document.documentElement);

    const clientH = container.clientHeight || window.innerHeight;
    const scrollStep = Math.max(220, Math.floor(clientH * 0.65));

    if (container === document.documentElement || container === document.body) {
      window.scrollBy({ top: scrollStep, behavior: 'instant' });
    } else {
      container.scrollTop += scrollStep;
      container.dispatchEvent(new Event('scroll', { bubbles: true }));
    }

    return true;
  }

  function executeHorizontalFlip() {
    let flipped = false;

    const flipSelectors = [
      // Smartbok / Kitaboo
      '#default_next_bttn',
      '#default_next_bttn md-icon',
      'rightnavigation-view md-icon',
      'rightnavigation-view',
      'button[aria-label="Neste side"]',
      'button[aria-label="Next Page"]',
      '.kitaboo-right-arrow',
      '#nextPageBtn',
      // Brettboka
      '.bb-nav-next',
      '.bb-next-btn',
      '#btnNextPage',
      '.nav-arrow.right',
      '[data-action="next-page"]',
      // Kindle Cloud Reader
      '#kindleReader_button_nextPage',
      '.kindleReader_button_nextPage',
      '#kindleReader_pageTurnAreaRight',
      '#page_next',
      // Generic readers (NDLA, Fagbokforlaget, etc.)
      '.pagination-next',
      '.page-next',
      'button[title*="Neste"]',
      'button[aria-label*="Neste"]'
    ];

    for (const sel of flipSelectors) {
      const btn = document.querySelector(sel);
      if (btn && btn.offsetParent !== null && !btn.disabled && !btn.classList.contains('disabled')) {
        btn.click();
        flipped = true;
        break;
      }
    }

    if (!flipped) {
      const keyOpts = {
        key: 'ArrowRight',
        code: 'ArrowRight',
        keyCode: 39,
        which: 39,
        bubbles: true,
        cancelable: true
      };
      document.dispatchEvent(new KeyboardEvent('keydown', keyOpts));
      document.dispatchEvent(new KeyboardEvent('keyup', keyOpts));
      flipped = true;
    }

    return flipped;
  }

  function getBookViewportBounds() {
    const isSmartbok = window.location.hostname.includes('smartbok.no') ||
                       document.querySelector('#default_next_bttn, rightnavigation-view, .kitaboo-right-arrow') !== null;

    if (isSmartbok) {
      const activeIframes = Array.from(document.querySelectorAll('iframe.epub_container_active, iframe[id^="epub_"], iframe'))
        .filter(isIframeCurrentlyVisible)
        .sort((a, b) => a.getBoundingClientRect().left - b.getBoundingClientRect().left);

      if (activeIframes.length > 0) {
        const firstRect = activeIframes[0].getBoundingClientRect();
        const lastRect = activeIframes[activeIframes.length - 1].getBoundingClientRect();
        const minX = Math.max(0, Math.floor(firstRect.left));
        const minY = Math.max(0, Math.floor(Math.min(...activeIframes.map(f => f.getBoundingClientRect().top))));
        const maxX = Math.min(window.innerWidth, Math.ceil(lastRect.right));
        const maxY = Math.min(window.innerHeight, Math.ceil(Math.max(...activeIframes.map(f => f.getBoundingClientRect().bottom))));
        const dividerX = activeIframes.length >= 2 ? Math.round(firstRect.right) : null;

        return {
          cropX: minX,
          cropY: minY,
          cropW: Math.max(100, maxX - minX),
          cropH: Math.max(100, maxY - minY),
          isTwoPageSpread: activeIframes.length >= 2,
          dividerX: dividerX,
          leftPageWidth: dividerX ? Math.round(dividerX - minX) : (maxX - minX)
        };
      }
    }

    const unibokFrame = document.getElementById('scrolled-content-frame');
    const container = (unibokFrame && unibokFrame.scrollHeight > unibokFrame.clientHeight)
      ? unibokFrame
      : (document.querySelector('#reader.layout-scroll, #reader') || document.body);

    if (container && container !== document.body) {
      const r = container.getBoundingClientRect();
      if (r.width > 200 && r.height > 200) {
        return {
          cropX: Math.max(0, Math.floor(r.left)),
          cropY: Math.max(0, Math.floor(r.top)),
          cropW: Math.min(window.innerWidth, Math.ceil(r.width)),
          cropH: Math.min(window.innerHeight, Math.ceil(r.height)),
          isTwoPageSpread: false,
          dividerX: null
        };
      }
    }

    return null;
  }

  function triggerNextPage(navMode = 'auto', scanMode = 'continuous', initialHeadings = [], targetHeading = '', currentCount = 0) {
    if (document.activeElement && document.activeElement !== document.body) {
      const tag = document.activeElement.tagName.toLowerCase();
      if (tag === 'input' || tag === 'textarea' || tag === 'select' || document.activeElement.getAttribute('role') === 'slider') {
        document.activeElement.blur();
      }
    }

    hideObstructingToolbars();

    const isSmartbok = window.location.hostname.includes('smartbok.no') ||
                       document.querySelector('#default_next_bttn, rightnavigation-view, .kitaboo-right-arrow, #nextPageBtn') !== null;
    const unibokFrame = document.getElementById('scrolled-content-frame');
    const isUnibok = window.location.hostname.includes('unibok.no') || unibokFrame !== null;

    let isVerticalScroll = false;
    if (navMode === 'scroll') {
      isVerticalScroll = true;
    } else if (navMode === 'flip') {
      isVerticalScroll = false;
    } else {
      isVerticalScroll = isUnibok && !isSmartbok;
    }

    const initialTexts = initialHeadings.map(h => typeof h === 'string' ? h : h.text);
    const initialMainChapters = initialHeadings
      .filter(h => typeof h === 'object' && h.isSmartbokMainChapter && h.mainChapter)
      .map(h => h.mainChapter);

    // --- CASE A: VERTICAL SCROLL (UNIBOK) ---
    if (isVerticalScroll) {
      const container = (unibokFrame && unibokFrame.scrollHeight > unibokFrame.clientHeight)
        ? unibokFrame
        : document.documentElement;

      const initialScroll = container.scrollTop || window.scrollY || 0;
      const clientHeight = container.clientHeight || window.innerHeight;
      const scrollHeight = container.scrollHeight || document.documentElement.scrollHeight;

      if (scanMode === 'subchapter' && currentCount >= 2) {
        if (targetHeading) {
          const match = findTargetHeadingPosition(targetHeading);
          if (match) {
            console.log('Undertema-slutt: Måloverskrift er nådd ved Y:', match.top, match.text);
            return {
              success: true,
              method: 'subchapter_finished',
              atBottom: false,
              reachedHeading: targetHeading,
              cropBottomY: Math.max(100, Math.floor(match.top - 10))
            };
          }
        }

        if (!targetHeading && initialTexts.length > 0) {
          const currentMajorHeadings = getVisibleHeadings(true);
          const newHeadingObj = currentMajorHeadings.find(h => !initialTexts.includes(h.text));
          if (newHeadingObj) {
            console.log('Undertema-slutt: Ny H2-hovedoverskrift nådd ved Y:', newHeadingObj.top, newHeadingObj.text);
            return {
              success: true,
              method: 'subchapter_finished',
              atBottom: false,
              reachedHeading: newHeadingObj.text,
              cropBottomY: Math.max(100, Math.floor(newHeadingObj.top - 10))
            };
          }
        }
      }

      executeVerticalScroll();

      const newScroll = container.scrollTop || window.scrollY || 0;
      const isAtBottom = (newScroll + clientHeight >= scrollHeight - 35) || (newScroll === initialScroll && initialScroll > 200);

      if (!isAtBottom) {
        return { success: true, method: 'vertical_scroll', atBottom: false };
      } else {
        if (scanMode === 'auto_chapter' || scanMode === 'subchapter') {
          return { success: true, method: 'chapter_finished', atBottom: true };
        }

        const nextChapterSelectors = [
          '.chapter-navigation--bottom a',
          '.chapter-navigation--top a',
          'a[href*="/5251/"]',
          '[aria-label*="Neste kapittel"]',
          '[title*="Neste kapittel"]',
          'a.next-chapter',
          'button.next-chapter'
        ];

        for (const sel of nextChapterSelectors) {
          const btn = document.querySelector(sel);
          if (btn && btn.offsetParent !== null) {
            btn.click();
            setTimeout(() => {
              if (container) container.scrollTop = 0;
              window.scrollTo(0, 0);
            }, 300);
            return { success: true, method: 'next_chapter_click', atBottom: true };
          }
        }

        return { success: true, method: 'chapter_finished', atBottom: true };
      }
    }

    // --- CASE B: HORIZONTAL FLIP (SMARTBOK / KITABOO) ---
    if (currentCount >= 2) {
      const bounds = getBookViewportBounds();

      function determineSpreadCropAction(matchingHeadings) {
        if (!bounds || !bounds.isTwoPageSpread || !bounds.dividerX) {
          return 'discard_last_spread';
        }
        
        const list = Array.isArray(matchingHeadings) ? matchingHeadings : [matchingHeadings];

        for (const h of list) {
          const x = (typeof h === 'object' && typeof h.left === 'number') ? h.left : 0;
          if (x < (bounds.dividerX - 20)) {
            console.log('Smartbok: Nytt kapittel oppdaget på venstre side -> forkaster hele oppslaget');
            return 'discard_last_spread';
          }
        }

        // Deep check of the left-side iframe directly
        const activeIframes = Array.from(document.querySelectorAll('iframe.epub_container_active, iframe[id^="epub_"], iframe'))
          .filter(isIframeCurrentlyVisible)
          .sort((a, b) => a.getBoundingClientRect().left - b.getBoundingClientRect().left);

        if (activeIframes.length >= 2) {
          const leftIframe = activeIframes[0];
          try {
            const leftDoc = leftIframe.contentDocument || leftIframe.contentWindow?.document;
            if (leftDoc && leftDoc.body) {
              const leftPageAttr = leftDoc.body.getAttribute('page') || '';
              const leftParsed = parseSmartbokChapter(leftPageAttr);
              if (leftParsed && initialMainChapters.length > 0 && !initialMainChapters.includes(leftParsed.mainChapter)) {
                console.log('Smartbok: Venstre iframe har nytt kapittel i pageAttr -> forkaster oppslag');
                return 'discard_last_spread';
              }

              const leftText = leftDoc.body.textContent || '';
              if (isChapterOpeningMarker(leftText.substring(0, 80)) || /kapittel\s*\d+/i.test(leftText.substring(0, 100))) {
                console.log('Smartbok: Venstre iframe har kapittelstart-tekst -> forkaster oppslag');
                return 'discard_last_spread';
              }
            }
          } catch (e) {}
        }

        return 'keep_left_half_only';
      }

      if (targetHeading) {
        const match = findTargetHeadingPosition(targetHeading);
        if (match) {
          console.log('Smartbok: Måloverskrift nådd:', targetHeading);
          const cropAction = determineSpreadCropAction(match);
          return { success: true, method: 'subchapter_finished', atBottom: false, reachedHeading: targetHeading, cropAction };
        }
      }

      if (scanMode === 'subchapter' && !targetHeading && initialTexts.length > 0) {
        const currentHeadings = getVisibleHeadings(true);
        const newHeadings = currentHeadings.filter(h => !initialTexts.includes(h.text));
        if (newHeadings.length > 0) {
          console.log('Smartbok: Nytt undertema nådd:', newHeadings[0].text);
          const cropAction = determineSpreadCropAction(newHeadings);
          return { success: true, method: 'subchapter_finished', atBottom: false, reachedHeading: newHeadings[0].text, cropAction };
        }
      }

      if (scanMode === 'auto_chapter') {
        const currentHeadings = getVisibleHeadings(true);

        if (initialMainChapters.length > 0) {
          const newMainChaps = currentHeadings.filter(h => h.isSmartbokMainChapter && h.mainChapter && !initialMainChapters.includes(h.mainChapter));
          if (newMainChaps.length > 0) {
            console.log('Smartbok: Nytt hovedkapittel nådd:', newMainChaps[0].mainChapter, newMainChaps[0].text);
            const cropAction = determineSpreadCropAction(newMainChaps);
            return { success: true, method: 'chapter_finished', atBottom: false, reachedHeading: newMainChaps[0].text, cropAction };
          }
        }

        const openingHeadings = currentHeadings.filter(h => h.isChapterOpening && !initialTexts.includes(h.text));
        if (openingHeadings.length > 0) {
          console.log('Smartbok: Ny kapittelstart-side nådd:', openingHeadings[0].text);
          const cropAction = determineSpreadCropAction(openingHeadings);
          return { success: true, method: 'chapter_finished', atBottom: false, reachedHeading: openingHeadings[0].text, cropAction };
        }
      }
    }

    executeHorizontalFlip();
    return { success: true, method: 'horizontal_flip', atBottom: false };
  }

  const CONTENT_SCRIPT_VERSION = '1.3.1';

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'PING') {
      sendResponse({ pong: true, version: CONTENT_SCRIPT_VERSION });
      return false;
    }

    if (message.action === 'EXTRACT_PAGE_TEXT') {
      const lines = getVisibleTextNodes();
      const bounds = getBookViewportBounds();
      sendResponse({ textNodes: lines, bookBounds: bounds });
      return false;
    }

    if (message.action === 'TRIGGER_NEXT_PAGE') {
      const result = triggerNextPage(
        message.navMode,
        message.scanMode,
        message.initialHeadings,
        message.targetHeading,
        message.currentCount
      );
      sendResponse(result);
      return false;
    }

    if (message.action === 'GET_HEADINGS') {
      const headings = getVisibleHeadings(true);
      sendResponse({ headings: headings });
      return false;
    }

    if (message.action === 'SET_SCAN_STATE') {
      if (message.status === 'scanning') {
        hideObstructingToolbars();
      } else {
        restoreToolbars();
      }
      sendResponse({ received: true });
      return false;
    }

    return false;
  });

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.scanState) {
      const st = changes.scanState.newValue;
      if (st && st.status === 'scanning') {
        hideObstructingToolbars();
      } else {
        restoreToolbars();
      }
    }
  });
})();
