# Chrome Web Store Listing & Metadata

## Norwegian (no)

### Extension Information
- **Title**: ScanExtension - Bok & PDF Skanner
- **Short Name**: ScanExtension
- **Version**: 1.3.7
- **Summary**: Automatisk sideskanning, høyoppløselig bildeopptak, klippeverktøy og søkbar PDF-generering for digitale e-bøker og nettbaserte lesere.
- **Category**: Productivity
- **Language**: Norwegian (no)

### Detailed Description
ScanExtension er et profesjonelt produktivitets- og tilgjengelighetsverktøy for elever, studenter, lærere og forskere som forenkler studiearbeid, notater og offline-lesing fra nettbaserte e-bøker og dokumenter.

Utvidelsen automatiserer opptak av boksider og genererer automatisk en samlet, høyoppløselig PDF med et innebygd usynlig tekstlag, slik at teksten kan markeres, kopieres og søkes i med Cmd+F / Ctrl+F.

HOVEDFUNKSJONER:

⚡ 1. Automatisert Kapittel- og Sideskanning
- Skanner og blar automatisk gjennom nettbaserte bøker og dokumenter.
- 4 fleksible moduser: Helt kapittel (avslutter automatisk ved kapittelslutt), Løpende skanning, Undertema (stopper ved neste overskrift), og Fast antall opptak.
- Automatisk gjenkjenning av både vertikal rulling og horisontal blaing.

🔍 2. Søkbar PDF med Usynlig Tekstlag (Searchable PDF)
- Plasserer et usynlig tekstlag nøyaktig over ordene på boksiden.
- Gjør det mulig å søke med Cmd+F / Ctrl+F, markere enkeltkolonner og kopiere avsnitt direkte inn i Word, OneNote eller Notion.

✂️ 3. Innebygd Klippeverktøy (Snipping Tool)
- Trykk Option+Shift+C (Mac) eller Alt+Shift+C (Windows) for å åpne klippeverktøyet.
- Dra et rektangel over ønsket figur, tabell eller graf.
- 1-klikk hurtigkopiering av bildet direkte til utklippstavlen (Cmd+V), uthenting av ren tekst, eller lagring som HD PNG.

🖼️ 4. Galleri & Forhåndsvisning
- Forhåndsvis opptakene som miniatyrbilder før PDF-en lagres.
- Slett uønskede sider eller sideskift med ett klikk.
- Velg mellom Maksimal kvalitet (300 DPI) eller Kompakt webstørrelse (150 DPI).

🔒 5. 100% Lokalt og Sikkert
- Kjører utelukkende lokalt i din egen nettleser.
- Ingen bilder, tekster eller filer samles inn eller sendes til eksterne servere.

---

## English (en)

### Extension Information
- **Title**: ScanExtension - E-Book & PDF Scanner
- **Short Name**: ScanExtension
- **Version**: 1.3.7
- **Summary**: Automated page scanning, high-resolution capture, snippet tool, and searchable PDF generation for web-based e-books and documents.
- **Category**: Productivity
- **Language**: English (en)

### Detailed Description
ScanExtension is a high-performance productivity and accessibility extension designed for students, researchers, and educators to streamline reading notes, study workflows, and offline access to online e-books and web documents.

The extension automates page navigation, captures crisp high-resolution viewports, and compiles them directly into a unified, searchable PDF with an invisible text layer.

KEY FEATURES:

⚡ 1. Automated Page & Chapter Scanning
- Smoothly scrolls or turns pages across digital textbooks and online readers.
- 4 flexible scanning modes: Full Chapter (auto-detects chapter completion), Continuous Scan, Subchapter (stops at next major heading), and Fixed Page Count.
- Supports both vertical scrolling readers and horizontal spread page-flipping.

🔍 2. Searchable PDF with Invisible Text Layer
- Accurately aligns an invisible text layer over rendered text on each page.
- Enables native Cmd+F / Ctrl+F searching, column-aware text selection, and direct copying into Word, Google Docs, or Notion.

✂️ 3. Quick Snippet & Cropping Tool
- Press Option+Shift+C (Mac) or Alt+Shift+C (Windows) to activate the snipping overlay anytime.
- Click and drag a bounding box around diagrams, charts, formulas, or text blocks.
- Instant 1-click clipboard copy (Cmd+V), text extraction, or high-definition PNG export.

🖼️ 4. Review Gallery & Page Management
- Preview thumbnail captures before generating the final PDF.
- Delete accidental blank pages or chapter boundary spreads with a single click.
- Choose between Maximum Quality (300 DPI) and Compact Web Size (150 DPI).

🔒 5. 100% Private & Client-Side
- All image rendering, OCR text alignment, and PDF compilation execute locally inside your browser session.
- Zero data collection, tracking, or transmission to third-party servers.

---

## Permissions Justification & Privacy

### Single Purpose
Automate page navigation, capture visible reading viewports, and provide cropping tools to compile local searchable PDF documents for study and offline reading.

### Permission Justifications
- **activeTab / tabs**: Required to capture the visible reading viewport of the active tab, monitor reader window dimensions, and trigger snipping overlays.
- **scripting**: Required to trigger page navigation commands and compile the PDF file client-side within the browser session.
- **storage**: Required to save user preferences (scan delay, scan mode, quality) locally across browser sessions.
- **downloads**: Required to save the generated PDF file and text exports directly to the user's local Downloads folder.
- **host_permissions (<all_urls>)**: Digital e-books, online journals, and learning platforms are hosted across diverse educational domains and subdomains. Universal host permission is necessary to capture viewports across any web reader.

### Privacy & Data Use
No personal user data is collected, stored on external servers, or transmitted to third parties. All screenshots, snipping, and PDF assembly are performed 100% locally in the browser.

---

## Store Media / Screenshots
- `store_screenshot1.png` (1280x800): Automated Page Scanning & Searchable PDF Creation (Active popup over reader).
- `store_screenshot2.png` (1280x800): Review Gallery & Searchable Text Layer (Page thumbnails, deletion, and PDF compile).
- `store_screenshot3.png` (1280x800): Interactive Snippet Tool (Cropping diagram with 1-click clipboard copy).
