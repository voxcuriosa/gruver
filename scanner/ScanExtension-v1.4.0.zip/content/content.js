(() => {
  if (window.top !== window) {
    return;
  }

  let hiddenElements = [];

  const existingOverlay = document.getElementById('scanext-overlay');
  if (existingOverlay) {
    existingOverlay.remove();
  }

  function hideObstructingToolbars() {
    const isUnibok = window.location.hostname.includes('unibok.no');
    if (!isUnibok) return;

    const selectors = [
      '.topbar',
      '#topbar',
      '.bottombar',
      '#bottombar',
      '.audioWrapper',
      '.chapter-navigation--top',
      '.chapter-navigation--bottom',
      '[class*="chapter-navigation"]',
      '[class*="top-bar"]',
      '[class*="header-bar"]',
      '#bookmark-popup',
      '#contextmenu',
      '#aiContextMenu'
    ];

    selectors.forEach(sel => {
      document.querySelectorAll(sel).forEach(el => {
        if (el && el.id !== 'scanext-overlay' && el.style.display !== 'none' && !el.dataset.scanextHidden) {
          el.dataset.scanextOrigDisplay = el.style.display || '';
          el.style.display = 'none';
          el.dataset.scanextHidden = 'true';
          hiddenElements.push(el);
        }
      });
    });
  }

  function restoreToolbars() {
    hiddenElements.forEach(el => {
      if (el && el.dataset.scanextHidden) {
        el.style.display = el.dataset.scanextOrigDisplay || '';
        delete el.dataset.scanextHidden;
        delete el.dataset.scanextOrigDisplay;
      }
    });
    hiddenElements = [];
  }

  function isConclusionHeading(text) {
    if (!text) return false;
    return /sammendrag|oppsummering|dybdelæring|dybdelaring|oppgaver|oppgåver|repetisjon|kilder|kjelder|arbeidsoppgaver|litteraturliste|dette kapitlet|dette kapittelet|har du fått med deg|å gjere|å gjøre|samanhengar|sammenhenger|perspektiv|tilbakeblikk|hva har du lært|kva har du lært/i.test(text);
  }

  function isChapterOpeningMarker(text) {
    if (!text) return false;
    if (isConclusionHeading(text)) return false;
    const clean = text.trim();

    if (/^(innhald|innhold|slik såg det ut|slik så det ut|dette har hendt|dette har skjedd)\b/i.test(clean)) {
      return true;
    }

    if (/^(kapittel\s*\d+|del\s*\d+|unit\s*\d+|chapter\s*\d+|tema\s*\d+)\b/i.test(clean)) {
      return true;
    }

    if (/^(?:verda|verden|norge|noreg|noregs|europa|norden)\s+(?:\d{3,4}\s*[-–—]\s*\d{3,4}|\d{3,4}\s+og\s+\d{3,4})/i.test(clean)) {
      return true;
    }

    return false;
  }

  function isIframeCurrentlyVisible(iframe) {
    if (!iframe) return false;
    const style = window.getComputedStyle(iframe);
    if (style.display === 'none' || style.visibility === 'hidden' || parseFloat(style.opacity) < 0.1) {
      return false;
    }
    const rect = iframe.getBoundingClientRect();
    if (rect.width < 50 || rect.height < 50) return false;
    if (rect.right < 0 || rect.left > window.innerWidth) return false;
    return true;
  }

  function parseSmartbokChapter(pageAttr) {
    if (!pageAttr) return null;
    const clean = pageAttr.replace(/^\d+[\s_.-]+/, '').trim();
    if (!clean || isConclusionHeading(clean)) return null;

    const prefixMatch = clean.match(/^((?:del|kapittel|kap|unit|chapter|tema)\s*\d+)/i);
    if (prefixMatch) {
      return { fullSection: clean, mainChapter: prefixMatch[1].toUpperCase() };
    }

    const codeMatch = clean.match(/^([A-Za-z]?\d+)[A-Za-z.-]?/);
    if (codeMatch && codeMatch[1].length <= 5) {
      return { fullSection: clean, mainChapter: codeMatch[1].toUpperCase() };
    }

    const split = clean.split(/[:–-]/)[0].trim();
    if (/^(del|kapittel|kap|unit|chapter|tema)\b/i.test(split) || /^[A-Z]\d+/i.test(split)) {
      return { fullSection: clean, mainChapter: split.toUpperCase() };
    }

    return null;
  }

  // Group individual words into natural horizontal lines strictly matching 2D column and block boundaries
  function assembleWordsIntoLines(words) {
    if (!words || words.length === 0) return [];

    // Step 1: Group words into horizontal line segments (words on same Y with normal word gaps)
    words.sort((a, b) => {
      if (Math.abs(a.y - b.y) <= 5) {
        return a.x - b.x;
      }
      return a.y - b.y;
    });

    const rawLines = [];
    let curLine = null;

    words.forEach(word => {
      if (!curLine) {
        curLine = {
          words: [word.text],
          x: word.x,
          y: word.y,
          maxX: word.x + word.w,
          h: word.h,
          fontSize: word.fontSize
        };
      } else {
        const sameY = Math.abs(word.y - curLine.y) <= 5;
        const xGap = word.x - curLine.maxX;
        const maxWordGap = Math.min(12, (word.fontSize || 14) * 0.7);

        if (sameY && xGap >= -4 && xGap <= maxWordGap) {
          curLine.words.push(word.text);
          curLine.maxX = Math.max(curLine.maxX, word.x + word.w);
          curLine.h = Math.max(curLine.h, word.h);
        } else {
          rawLines.push({
            text: curLine.words.join(' '),
            x: curLine.x,
            y: curLine.y,
            maxX: curLine.maxX,
            w: curLine.maxX - curLine.x,
            h: curLine.h,
            fontSize: curLine.fontSize
          });
          curLine = {
            words: [word.text],
            x: word.x,
            y: word.y,
            maxX: word.x + word.w,
            h: word.h,
            fontSize: word.fontSize
          };
        }
      }
    });

    if (curLine) {
      rawLines.push({
        text: curLine.words.join(' '),
        x: curLine.x,
        y: curLine.y,
        maxX: curLine.maxX,
        w: curLine.maxX - curLine.x,
        h: curLine.h,
        fontSize: curLine.fontSize
      });
    }

    if (rawLines.length <= 1) return rawLines;

    // Step 2: Cluster lines into Column Blocks (2D Spatial Block Clustering)
    const blocks = [];

    rawLines.forEach(line => {
      let bestBlock = null;
      let minDist = Infinity;

      for (const block of blocks) {
        const overlap = Math.min(line.maxX, block.maxX) - Math.max(line.x, block.minX);
        const xStartDiff = Math.abs(line.x - block.minX);
        const yGap = line.y - block.maxY;

        // Belongs to the same column block if horizontal overlap exists or left margins align, and vertical gap is within 45px
        if ((overlap > 10 || (xStartDiff <= 18 && overlap >= -5)) && yGap >= -8 && yGap <= 45) {
          if (yGap < minDist) {
            minDist = yGap;
            bestBlock = block;
          }
        }
      }

      if (bestBlock) {
        bestBlock.lines.push(line);
        bestBlock.minX = Math.min(bestBlock.minX, line.x);
        bestBlock.maxX = Math.max(bestBlock.maxX, line.maxX);
        bestBlock.maxY = Math.max(bestBlock.maxY, line.y + line.h);
      } else {
        blocks.push({
          minX: line.x,
          maxX: line.maxX,
          minY: line.y,
          maxY: line.y + line.h,
          lines: [line]
        });
      }
    });

    // Step 3: Sort Blocks in natural reading order (left-to-right columns, top-to-bottom within each column)
    blocks.sort((a, b) => {
      const colDiff = a.minX - b.minX;
      if (Math.abs(colDiff) > 20) {
        return colDiff;
      }
      return a.minY - b.minY;
    });

    // Step 4: Emit all lines within each block in order
    const finalLines = [];
    blocks.forEach(block => {
      block.lines.sort((a, b) => a.y - b.y);
      block.lines.forEach(l => {
        finalLines.push({
          text: l.text,
          x: l.x,
          y: l.y,
          w: l.w,
          h: l.h,
          fontSize: l.fontSize
        });
      });
    });

    return finalLines;
  }

  // Assemble page text nodes into complete sentences/lines and preserve true multi-column layouts
  function assemblePageLines(nodes, iframeRect) {
    if (!nodes || nodes.length === 0) return [];

    // Step 1: Sort raw nodes vertically top-to-bottom, then horizontally left-to-right
    nodes.sort((a, b) => {
      const yDiff = a.y - b.y;
      if (Math.abs(yDiff) > 4) return yDiff;
      return a.x - b.x;
    });

    // Step 2: Cluster into horizontal lines
    const lineBuckets = [];
    nodes.forEach(node => {
      let placed = false;
      const fs = node.fontSize || 14;
      const yTol = Math.max(4, fs * 0.4);

      for (const bucket of lineBuckets) {
        if (Math.abs(bucket.avgY - node.y) <= yTol) {
          bucket.nodes.push(node);
          bucket.avgY = bucket.nodes.reduce((s, n) => s + n.y, 0) / bucket.nodes.length;
          placed = true;
          break;
        }
      }

      if (!placed) {
        lineBuckets.push({
          avgY: node.y,
          nodes: [node]
        });
      }
    });

    // Sort buckets by avgY
    lineBuckets.sort((a, b) => a.avgY - b.avgY);

    // Step 3: Within each line bucket, sort words by X and merge contiguous text spans
    // Also detect if there are multi-column segments on the same line (separated by large gap > 55px)
    const columnSegments = [];

    lineBuckets.forEach(bucket => {
      bucket.nodes.sort((a, b) => a.x - b.x);

      let currentSegment = null;

      bucket.nodes.forEach(wordNode => {
        if (!currentSegment) {
          currentSegment = {
            text: wordNode.text,
            x: wordNode.x,
            y: wordNode.y,
            w: wordNode.w,
            h: wordNode.h,
            fontSize: wordNode.fontSize
          };
          return;
        }

        const prevRight = currentSegment.x + currentSegment.w;
        const gap = wordNode.x - prevRight;

        // If gap is large (> 55px) and spans distinct columns across the page, treat as separate column segment
        if (gap > 55) {
          columnSegments.push(currentSegment);
          currentSegment = {
            text: wordNode.text,
            x: wordNode.x,
            y: wordNode.y,
            w: wordNode.w,
            h: wordNode.h,
            fontSize: wordNode.fontSize
          };
        } else {
          // Contiguous word on the same sentence/line
          if (currentSegment.text.endsWith('-') && !currentSegment.text.endsWith(' -')) {
            currentSegment.text = currentSegment.text.slice(0, -1) + wordNode.text;
          } else {
            currentSegment.text += ' ' + wordNode.text;
          }
          currentSegment.w = (wordNode.x + wordNode.w) - currentSegment.x;
          currentSegment.h = Math.max(currentSegment.h, wordNode.h);
        }
      });

      if (currentSegment) {
        columnSegments.push(currentSegment);
      }
    });

    // Step 4: Check if columnSegments belong to 2 distinct columns (Left & Right)
    // A true 2-column layout exists ONLY if left segments end before midX and right segments start after midX
    if (iframeRect && columnSegments.length >= 6) {
      const midX = iframeRect.left + (iframeRect.width / 2);
      const leftCol = [];
      const rightCol = [];
      let bridgingCount = 0;

      columnSegments.forEach(seg => {
        const segRight = seg.x + seg.w;
        if (seg.x < midX - 25 && segRight > midX + 25) {
          // This line bridges across the middle axis -> It's a full-width paragraph/heading!
          bridgingCount++;
        } else if (seg.x + (seg.w / 2) < midX) {
          leftCol.push(seg);
        } else {
          rightCol.push(seg);
        }
      });

      // If lines bridge across the middle (single wide column or mixed headings), preserve top-to-bottom reading order!
      if (bridgingCount > 2 || leftCol.length < 3 || rightCol.length < 3) {
        columnSegments.sort((a, b) => a.y - b.y);
        return columnSegments;
      }

      // If true two-column sidebar/article layout with 0 bridging:
      leftCol.sort((a, b) => a.y - b.y);
      rightCol.sort((a, b) => a.y - b.y);
      return [...leftCol, ...rightCol];
    }

    columnSegments.sort((a, b) => a.y - b.y);
    return columnSegments;
  }

  // Extract all visible text nodes with exact visual coordinates
  function getVisibleTextNodes() {
    const allLines = [];
    const windowW = window.innerWidth || document.documentElement.clientWidth;
    const windowH = window.innerHeight || document.documentElement.clientHeight;

    const isSmartbok = window.location.hostname.includes('smartbok.no') ||
                       document.querySelector('#default_next_bttn, rightnavigation-view, .kitaboo-right-arrow') !== null;

    // --- SMARTBOK ENGINE ---
    if (isSmartbok) {
      const smartbokIframes = Array.from(document.querySelectorAll('iframe.epub_container_active, iframe[id^="epub_"], iframe'))
        .filter(isIframeCurrentlyVisible)
        .sort((a, b) => a.getBoundingClientRect().left - b.getBoundingClientRect().left);

      smartbokIframes.forEach(iframe => {
        try {
          const iframeDoc = iframe.contentDocument || iframe.contentWindow?.document;
          if (iframeDoc && iframeDoc.body) {
            const iframeRect = iframe.getBoundingClientRect();
            const bodyW = iframeDoc.body.clientWidth || iframeDoc.documentElement.clientWidth || iframeRect.width;
            const bodyH = iframeDoc.body.clientHeight || iframeDoc.documentElement.clientHeight || iframeRect.height;

            const scaleX = bodyW > 0 ? (iframeRect.width / bodyW) : 1;
            const scaleY = bodyH > 0 ? (iframeRect.height / bodyH) : 1;

            const pageNodes = [];

            const textNodes = iframeDoc.querySelectorAll('.smartbok-span, span[id*="textid"], p, text, tspan, h1, h2, h3, h4, [role="text"]');
            textNodes.forEach(node => {
              const txt = node.textContent.trim();
              if (txt.length > 0 && node.children.length === 0) {
                const r = node.getBoundingClientRect();
                const absX = iframeRect.left + (r.left * scaleX);
                const absY = iframeRect.top + (r.top * scaleY);
                const trueW = r.width * scaleX;
                const trueH = r.height * scaleY;

                if (absX >= -20 && absX <= windowW && absY >= -20 && absY <= windowH && trueW > 0 && trueH > 0) {
                  const fs = (parseFloat(window.getComputedStyle(node).fontSize) || 14) * scaleY;
                  pageNodes.push({
                    text: txt,
                    x: Math.round(absX),
                    y: Math.round(absY),
                    w: Math.round(trueW),
                    h: Math.round(trueH),
                    fontSize: fs
                  });
                }
              }
            });

            if (pageNodes.length > 0) {
              const ordered = assemblePageLines(pageNodes, iframeRect);
              allLines.push(...ordered);
            }
          }
        } catch (e) {}
      });

      return allLines;
    }

    // --- UNIBOK / HTML EPUB ENGINE ---
    const targetDocs = [];

    document.querySelectorAll('iframe').forEach(iframe => {
      try {
        const iframeDoc = iframe.contentDocument || iframe.contentWindow?.document;
        if (iframeDoc && iframeDoc.body) {
          targetDocs.push({ doc: iframeDoc, offset: iframe.getBoundingClientRect() });
        }
      } catch (e) {}
    });

    targetDocs.push({ doc: document, offset: { left: 0, top: 0 } });

    targetDocs.forEach(({ doc, offset }) => {
      try {
        if (!doc.body) return;

        const walker = doc.createTreeWalker(doc.body, NodeFilter.SHOW_TEXT, {
          acceptNode: (n) => {
            if (!n.textContent || !n.textContent.trim()) return NodeFilter.FILTER_REJECT;
            const parent = n.parentElement;
            if (!parent) return NodeFilter.FILTER_REJECT;
            const tag = parent.tagName.toLowerCase();
            if (tag === 'script' || tag === 'style' || tag === 'noscript' || tag === 'svg') return NodeFilter.FILTER_REJECT;
            if (parent.closest('#scanext-overlay, .topbar, .bottombar, #topbar, #bottombar')) return NodeFilter.FILTER_REJECT;
            return NodeFilter.FILTER_ACCEPT;
          }
        });

        const docWords = [];
        let textNode;

        while ((textNode = walker.nextNode())) {
          const rawText = textNode.textContent;
          if (!rawText || !rawText.trim()) continue;

          const parentEl = textNode.parentElement;
          const fs = parentEl ? (parseFloat(window.getComputedStyle(parentEl).fontSize) || 16) : 16;

          // Split text node into word boundaries using RegEx to measure individual visual line positions
          const wordRegex = /\S+/g;
          let match;

          while ((match = wordRegex.exec(rawText)) !== null) {
            const startIdx = match.index;
            const endIdx = match.index + match[0].length;

            try {
              const wordRange = doc.createRange();
              wordRange.setStart(textNode, startIdx);
              wordRange.setEnd(textNode, endIdx);

              const r = wordRange.getBoundingClientRect();
              const absX = offset.left + r.left;
              const absY = offset.top + r.top;

              if (absX >= -20 && absX <= windowW && absY >= -20 && absY <= windowH && r.width > 1 && r.height > 1) {
                docWords.push({
                  text: match[0],
                  x: Math.round(absX),
                  y: Math.round(absY),
                  w: Math.round(r.width),
                  h: Math.round(r.height),
                  fontSize: fs
                });
              }
            } catch (rErr) {}
          }
        }

        if (docWords.length > 0) {
          const lines = assembleWordsIntoLines(docWords);
          allLines.push(...lines);
        }
      } catch (e) {
        console.warn('Error reading Unibok text:', e);
      }
    });

    return allLines;
  }

  function getVisibleHeadings(onlyMajor = true) {
    const headings = [];
    const windowH = window.innerHeight || document.documentElement.clientHeight;

    const smartbokIframes = document.querySelectorAll('iframe.epub_container_active, iframe[id^="epub_"], iframe');
    smartbokIframes.forEach(iframe => {
      if (!isIframeCurrentlyVisible(iframe)) return;

      try {
        const iframeDoc = iframe.contentDocument || iframe.contentWindow?.document;
        if (iframeDoc && iframeDoc.body) {
          const iframeRect = iframe.getBoundingClientRect();
          const pageAttr = iframeDoc.body.getAttribute('page');
          if (pageAttr) {
            const parsed = parseSmartbokChapter(pageAttr);
            if (parsed && !headings.some(h => h.text === parsed.fullSection)) {
              headings.push({
                text: parsed.fullSection,
                mainChapter: parsed.mainChapter,
                isSmartbokMainChapter: true,
                isChapterOpening: false,
                left: iframeRect.left,
                top: iframeRect.top
              });
            }
          }

          const titleNodes = iframeDoc.querySelectorAll('h1, h2, h3, [class*="title"], [class*="heading"], .smartbok-span, text');
          titleNodes.forEach(node => {
            const text = node.textContent.trim();
            if (text.length >= 3) {
              const fontSize = parseFloat(window.getComputedStyle(node).fontSize) || 0;
              const isOpening = isChapterOpeningMarker(text);

              if (isOpening || fontSize >= 28 || node.tagName === 'H1') {
                if (!isConclusionHeading(text) && !headings.some(h => h.text === text)) {
                  const r = node.getBoundingClientRect();
                  headings.push({
                    text: text,
                    mainChapter: isOpening ? text.toUpperCase() : null,
                    isSmartbokMainChapter: isOpening,
                    isChapterOpening: isOpening,
                    left: iframeRect.left + r.left,
                    top: iframeRect.top + r.top
                  });
                }
              }
            }
          });
        }
      } catch (e) {}
    });

    const unibokSelector = onlyMajor
      ? 'h2, .delkapittel, .undertema, [epub\\:type*="chapter-title"], [class*="section-title"]'
      : 'h1, h2, h3, h4, [class*="title"], [class*="heading"]';

    document.querySelectorAll('iframe').forEach(iframe => {
      if (!isIframeCurrentlyVisible(iframe)) return;

      try {
        const iframeDoc = iframe.contentDocument || iframe.contentWindow?.document;
        if (iframeDoc) {
          const iframeRect = iframe.getBoundingClientRect();
          const nodes = iframeDoc.querySelectorAll(unibokSelector);
          
          nodes.forEach(node => {
            const nodeRect = node.getBoundingClientRect();
            const actualTop = iframeRect.top + nodeRect.top;
            const text = node.textContent.trim();

            if (actualTop >= 40 && actualTop <= windowH - 80 && text.length > 2) {
              if (!isConclusionHeading(text) && !headings.some(h => h.text === text)) {
                headings.push({ text, mainChapter: text.substring(0, 4), top: actualTop });
              }
            }
          });
        }
      } catch (e) {}
    });

    const mainNodes = document.querySelectorAll(unibokSelector);
    mainNodes.forEach(node => {
      const rect = node.getBoundingClientRect();
      const text = node.textContent.trim();
      if (rect.top >= 40 && rect.top <= windowH - 80 && text.length > 2) {
        if (!isConclusionHeading(text) && !headings.some(h => h.text === text)) {
          headings.push({ text, mainChapter: text.substring(0, 4), top: rect.top });
        }
      }
    });

    return headings;
  }

  function normalizeSearchText(str) {
    if (!str) return '';
    return str.toLowerCase()
      .replace(/[\u2013\u2014\u2212-]/g, '-')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function findTargetHeadingPosition(targetText) {
    if (!targetText || !targetText.trim()) return null;
    const search = normalizeSearchText(targetText);
    const windowH = window.innerHeight || document.documentElement.clientHeight;

    let match = null;

    document.querySelectorAll('iframe').forEach(iframe => {
      if (!isIframeCurrentlyVisible(iframe)) return;

      try {
        const iframeDoc = iframe.contentDocument || iframe.contentWindow?.document;
        if (iframeDoc) {
          const pageAttr = iframeDoc.body?.getAttribute('page');
          if (pageAttr && normalizeSearchText(pageAttr).includes(search)) {
            match = { text: pageAttr, top: 0 };
            return;
          }

          const iframeRect = iframe.getBoundingClientRect();
          const nodes = iframeDoc.querySelectorAll('h1, h2, h3, h4, p, div, span, text, tspan, .smartbok-span');
          
          for (const node of nodes) {
            const t = normalizeSearchText(node.textContent);
            if (t.includes(search) && node.children.length === 0) {
              const nodeRect = node.getBoundingClientRect();
              const actualTop = iframeRect.top + nodeRect.top;
              if (actualTop >= 0 && actualTop <= windowH - 20) {
                match = { text: node.textContent.trim(), top: actualTop };
                break;
              }
            }
          }
        }
      } catch (e) {}
    });

    if (match) return match;

    const mainNodes = document.querySelectorAll('h1, h2, h3, h4, p, div, span, text');
    for (const node of mainNodes) {
      const t = normalizeSearchText(node.textContent);
      if (t.includes(search) && node.children.length === 0) {
        const rect = node.getBoundingClientRect();
        if (rect.top >= 0 && rect.top <= windowH - 20) {
          match = { text: node.textContent.trim(), top: rect.top };
          break;
        }
      }
    }

    return match;
  }

  function executeVerticalScroll() {
    const unibokFrame = document.getElementById('scrolled-content-frame');
    const container = (unibokFrame && unibokFrame.scrollHeight > unibokFrame.clientHeight)
      ? unibokFrame
      : (document.querySelector('#reader.layout-scroll, main, [role="main"], article, .pendel-content, .reader-container') || document.documentElement);

    const clientH = container.clientHeight || window.innerHeight;
    const scrollStep = Math.max(220, Math.floor(clientH * 0.65));

    if (container === document.documentElement || container === document.body) {
      window.scrollBy({ top: scrollStep, behavior: 'instant' });
    } else {
      container.scrollTop += scrollStep;
      container.dispatchEvent(new Event('scroll', { bubbles: true }));
    }

    return true;
  }

  function executeHorizontalFlip() {
    let flipped = false;

    const flipSelectors = [
      // Smartbok / Kitaboo
      '#default_next_bttn',
      '#default_next_bttn md-icon',
      'rightnavigation-view md-icon',
      'rightnavigation-view',
      'button[aria-label="Neste side"]',
      'button[aria-label="Next Page"]',
      '.kitaboo-right-arrow',
      '#nextPageBtn',
      // Brettboka
      '.bb-nav-next',
      '.bb-next-btn',
      '#btnNextPage',
      '.nav-arrow.right',
      '[data-action="next-page"]',
      // Kindle Cloud Reader
      '#kindleReader_button_nextPage',
      '.kindleReader_button_nextPage',
      '#kindleReader_pageTurnAreaRight',
      '#page_next',
      // Generic readers (NDLA, Fagbokforlaget, etc.)
      '.pagination-next',
      '.page-next',
      'button[title*="Neste"]',
      'button[aria-label*="Neste"]'
    ];

    for (const sel of flipSelectors) {
      const btn = document.querySelector(sel);
      if (btn && btn.offsetParent !== null && !btn.disabled && !btn.classList.contains('disabled')) {
        btn.click();
        flipped = true;
        break;
      }
    }

    if (!flipped) {
      const keyOpts = {
        key: 'ArrowRight',
        code: 'ArrowRight',
        keyCode: 39,
        which: 39,
        bubbles: true,
        cancelable: true
      };
      document.dispatchEvent(new KeyboardEvent('keydown', keyOpts));
      document.dispatchEvent(new KeyboardEvent('keyup', keyOpts));
      flipped = true;
    }

    return flipped;
  }

  function getBookViewportBounds() {
    const isSmartbok = window.location.hostname.includes('smartbok.no') ||
                       document.querySelector('#default_next_bttn, rightnavigation-view, .kitaboo-right-arrow') !== null;

    if (isSmartbok) {
      const activeIframes = Array.from(document.querySelectorAll('iframe.epub_container_active, iframe[id^="epub_"], iframe'))
        .filter(isIframeCurrentlyVisible)
        .sort((a, b) => a.getBoundingClientRect().left - b.getBoundingClientRect().left);

      if (activeIframes.length > 0) {
        const firstRect = activeIframes[0].getBoundingClientRect();
        const lastRect = activeIframes[activeIframes.length - 1].getBoundingClientRect();
        const minX = Math.max(0, Math.floor(firstRect.left));
        const minY = Math.max(0, Math.floor(Math.min(...activeIframes.map(f => f.getBoundingClientRect().top))));
        const maxX = Math.min(window.innerWidth, Math.ceil(lastRect.right));
        const maxY = Math.min(window.innerHeight, Math.ceil(Math.max(...activeIframes.map(f => f.getBoundingClientRect().bottom))));
        const dividerX = activeIframes.length >= 2 ? Math.round(firstRect.right) : null;

        return {
          cropX: minX,
          cropY: minY,
          cropW: Math.max(100, maxX - minX),
          cropH: Math.max(100, maxY - minY),
          isTwoPageSpread: activeIframes.length >= 2,
          dividerX: dividerX,
          leftPageWidth: dividerX ? Math.round(dividerX - minX) : (maxX - minX)
        };
      }
    }

    const unibokFrame = document.getElementById('scrolled-content-frame');
    const container = (unibokFrame && unibokFrame.scrollHeight > unibokFrame.clientHeight)
      ? unibokFrame
      : (document.querySelector('#reader.layout-scroll, #reader') || document.body);

    if (container && container !== document.body) {
      const r = container.getBoundingClientRect();
      if (r.width > 200 && r.height > 200) {
        return {
          cropX: Math.max(0, Math.floor(r.left)),
          cropY: Math.max(0, Math.floor(r.top)),
          cropW: Math.min(window.innerWidth, Math.ceil(r.width)),
          cropH: Math.min(window.innerHeight, Math.ceil(r.height)),
          isTwoPageSpread: false,
          dividerX: null
        };
      }
    }

    return null;
  }

  function triggerNextPage(navMode = 'auto', scanMode = 'continuous', initialHeadings = [], targetHeading = '', currentCount = 0) {
    if (document.activeElement && document.activeElement !== document.body) {
      const tag = document.activeElement.tagName.toLowerCase();
      if (tag === 'input' || tag === 'textarea' || tag === 'select' || document.activeElement.getAttribute('role') === 'slider') {
        document.activeElement.blur();
      }
    }

    hideObstructingToolbars();

    const isSmartbok = window.location.hostname.includes('smartbok.no') ||
                       document.querySelector('#default_next_bttn, rightnavigation-view, .kitaboo-right-arrow, #nextPageBtn') !== null;
    const unibokFrame = document.getElementById('scrolled-content-frame');
    const isUnibok = window.location.hostname.includes('unibok.no') || unibokFrame !== null;

    let isVerticalScroll = false;
    if (navMode === 'scroll') {
      isVerticalScroll = true;
    } else if (navMode === 'flip') {
      isVerticalScroll = false;
    } else {
      isVerticalScroll = isUnibok && !isSmartbok;
    }

    const initialTexts = initialHeadings.map(h => typeof h === 'string' ? h : h.text);
    const initialMainChapters = initialHeadings
      .filter(h => typeof h === 'object' && h.isSmartbokMainChapter && h.mainChapter)
      .map(h => h.mainChapter);

    // --- CASE A: VERTICAL SCROLL (UNIBOK) ---
    if (isVerticalScroll) {
      const container = (unibokFrame && unibokFrame.scrollHeight > unibokFrame.clientHeight)
        ? unibokFrame
        : document.documentElement;

      const initialScroll = container.scrollTop || window.scrollY || 0;
      const clientHeight = container.clientHeight || window.innerHeight;
      const scrollHeight = container.scrollHeight || document.documentElement.scrollHeight;

      if (scanMode === 'subchapter' && currentCount >= 2) {
        if (targetHeading) {
          const match = findTargetHeadingPosition(targetHeading);
          if (match) {
            console.log('Undertema-slutt: Måloverskrift er nådd ved Y:', match.top, match.text);
            return {
              success: true,
              method: 'subchapter_finished',
              atBottom: false,
              reachedHeading: targetHeading,
              cropBottomY: Math.max(100, Math.floor(match.top - 10))
            };
          }
        }

        if (!targetHeading && initialTexts.length > 0) {
          const currentMajorHeadings = getVisibleHeadings(true);
          const newHeadingObj = currentMajorHeadings.find(h => !initialTexts.includes(h.text));
          if (newHeadingObj) {
            console.log('Undertema-slutt: Ny H2-hovedoverskrift nådd ved Y:', newHeadingObj.top, newHeadingObj.text);
            return {
              success: true,
              method: 'subchapter_finished',
              atBottom: false,
              reachedHeading: newHeadingObj.text,
              cropBottomY: Math.max(100, Math.floor(newHeadingObj.top - 10))
            };
          }
        }
      }

      executeVerticalScroll();

      const newScroll = container.scrollTop || window.scrollY || 0;
      const isAtBottom = (newScroll + clientHeight >= scrollHeight - 35) || (newScroll === initialScroll && initialScroll > 200);

      if (!isAtBottom) {
        return { success: true, method: 'vertical_scroll', atBottom: false };
      } else {
        if (scanMode === 'auto_chapter' || scanMode === 'subchapter') {
          return { success: true, method: 'chapter_finished', atBottom: true };
        }

        const nextChapterSelectors = [
          '.chapter-navigation--bottom a',
          '.chapter-navigation--top a',
          'a[href*="/5251/"]',
          '[aria-label*="Neste kapittel"]',
          '[title*="Neste kapittel"]',
          'a.next-chapter',
          'button.next-chapter'
        ];

        for (const sel of nextChapterSelectors) {
          const btn = document.querySelector(sel);
          if (btn && btn.offsetParent !== null) {
            btn.click();
            setTimeout(() => {
              if (container) container.scrollTop = 0;
              window.scrollTo(0, 0);
            }, 300);
            return { success: true, method: 'next_chapter_click', atBottom: true };
          }
        }

        return { success: true, method: 'chapter_finished', atBottom: true };
      }
    }

    // --- CASE B: HORIZONTAL FLIP (SMARTBOK / KITABOO) ---
    if (currentCount >= 2) {
      const bounds = getBookViewportBounds();

      function determineSpreadCropAction(matchingHeadings) {
        if (!bounds || !bounds.isTwoPageSpread || !bounds.dividerX) {
          return 'discard_last_spread';
        }
        
        const list = Array.isArray(matchingHeadings) ? matchingHeadings : [matchingHeadings];

        for (const h of list) {
          const x = (typeof h === 'object' && typeof h.left === 'number') ? h.left : 0;
          if (x < (bounds.dividerX - 20)) {
            console.log('Smartbok: Nytt kapittel oppdaget på venstre side -> forkaster hele oppslaget');
            return 'discard_last_spread';
          }
        }

        // Deep check of the left-side iframe directly
        const activeIframes = Array.from(document.querySelectorAll('iframe.epub_container_active, iframe[id^="epub_"], iframe'))
          .filter(isIframeCurrentlyVisible)
          .sort((a, b) => a.getBoundingClientRect().left - b.getBoundingClientRect().left);

        if (activeIframes.length >= 2) {
          const leftIframe = activeIframes[0];
          try {
            const leftDoc = leftIframe.contentDocument || leftIframe.contentWindow?.document;
            if (leftDoc && leftDoc.body) {
              const leftPageAttr = leftDoc.body.getAttribute('page') || '';
              const leftParsed = parseSmartbokChapter(leftPageAttr);
              if (leftParsed && initialMainChapters.length > 0 && !initialMainChapters.includes(leftParsed.mainChapter)) {
                console.log('Smartbok: Venstre iframe har nytt kapittel i pageAttr -> forkaster oppslag');
                return 'discard_last_spread';
              }

              const leftText = leftDoc.body.textContent || '';
              if (isChapterOpeningMarker(leftText.substring(0, 80)) || /kapittel\s*\d+/i.test(leftText.substring(0, 100))) {
                console.log('Smartbok: Venstre iframe har kapittelstart-tekst -> forkaster oppslag');
                return 'discard_last_spread';
              }
            }
          } catch (e) {}
        }

        return 'keep_left_half_only';
      }

      if (targetHeading) {
        const match = findTargetHeadingPosition(targetHeading);
        if (match) {
          console.log('Smartbok: Måloverskrift nådd:', targetHeading);
          const cropAction = determineSpreadCropAction(match);
          return { success: true, method: 'subchapter_finished', atBottom: false, reachedHeading: targetHeading, cropAction };
        }
      }

      if (scanMode === 'subchapter' && !targetHeading && initialTexts.length > 0) {
        const currentHeadings = getVisibleHeadings(true);
        const newHeadings = currentHeadings.filter(h => !initialTexts.includes(h.text));
        if (newHeadings.length > 0) {
          console.log('Smartbok: Nytt undertema nådd:', newHeadings[0].text);
          const cropAction = determineSpreadCropAction(newHeadings);
          return { success: true, method: 'subchapter_finished', atBottom: false, reachedHeading: newHeadings[0].text, cropAction };
        }
      }

      if (scanMode === 'auto_chapter') {
        const currentHeadings = getVisibleHeadings(true);

        if (initialMainChapters.length > 0) {
          const newMainChaps = currentHeadings.filter(h => h.isSmartbokMainChapter && h.mainChapter && !initialMainChapters.includes(h.mainChapter));
          if (newMainChaps.length > 0) {
            console.log('Smartbok: Nytt hovedkapittel nådd:', newMainChaps[0].mainChapter, newMainChaps[0].text);
            const cropAction = determineSpreadCropAction(newMainChaps);
            return { success: true, method: 'chapter_finished', atBottom: false, reachedHeading: newMainChaps[0].text, cropAction };
          }
        }

        const openingHeadings = currentHeadings.filter(h => h.isChapterOpening && !initialTexts.includes(h.text));
        if (openingHeadings.length > 0) {
          console.log('Smartbok: Ny kapittelstart-side nådd:', openingHeadings[0].text);
          const cropAction = determineSpreadCropAction(openingHeadings);
          return { success: true, method: 'chapter_finished', atBottom: false, reachedHeading: openingHeadings[0].text, cropAction };
        }
      }
    }

    executeHorizontalFlip();
    return { success: true, method: 'horizontal_flip', atBottom: false };
  }

  // --- SNIPPING / CLIPBOARD CROP TOOL ---
  function showToast(message, icon = '✓') {
    const existing = document.querySelector('.scanext-toast');
    if (existing) existing.remove();

    const toast = document.createElement('div');
    toast.className = 'scanext-toast';
    toast.innerHTML = `
      <span style="color: #10b981; font-weight: 800; font-size: 14px;">${icon}</span>
      <span>${message}</span>
    `;
    document.body.appendChild(toast);

    setTimeout(() => {
      toast.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
      toast.style.opacity = '0';
      toast.style.transform = 'translateX(-50%) translateY(10px)';
      setTimeout(() => toast.remove(), 300);
    }, 2800);
  }

  function cropScreenshotBlob(dataUrl, rect) {
    return new Promise((resolve) => {
      const img = new Image();
      img.onload = () => {
        const dpr = img.naturalHeight / window.innerHeight;
        const cropX = Math.round(rect.x * dpr);
        const cropY = Math.round(rect.y * dpr);
        const cropW = Math.round(rect.w * dpr);
        const cropH = Math.round(rect.h * dpr);

        const canvas = document.createElement('canvas');
        canvas.width = cropW;
        canvas.height = cropH;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, cropX, cropY, cropW, cropH, 0, 0, cropW, cropH);

        canvas.toBlob((blob) => {
          resolve(blob);
        }, 'image/png');
      };
      img.onerror = () => resolve(null);
      img.src = dataUrl;
    });
  }

  function ensureSnipperStyles() {
    if (document.getElementById('scanext-snipper-styles')) return;
    const style = document.createElement('style');
    style.id = 'scanext-snipper-styles';
    style.textContent = `
      #scanext-snipper-overlay {
        position: fixed !important;
        top: 0 !important;
        left: 0 !important;
        width: 100vw !important;
        height: 100vh !important;
        z-index: 2147483646 !important;
        cursor: crosshair !important;
        background: rgba(0, 0, 0, 0.18) !important;
        user-select: none !important;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important;
      }
      .scanext-snip-selection {
        position: absolute !important;
        border: 2px solid #38bdf8 !important;
        box-shadow: 0 0 0 99999px rgba(0, 0, 0, 0.18) !important;
        pointer-events: auto !important;
        border-radius: 2px !important;
        background: transparent !important;
      }
      .scanext-snip-dimensions {
        position: absolute !important;
        top: -24px !important;
        left: 0 !important;
        background: #0f172a !important;
        color: #38bdf8 !important;
        font-size: 11px !important;
        font-weight: 700 !important;
        padding: 2px 6px !important;
        border-radius: 4px !important;
        border: 1px solid rgba(56, 189, 248, 0.4) !important;
        white-space: nowrap !important;
      }
      .scanext-snip-toolbar {
        position: fixed !important;
        z-index: 2147483647 !important;
        background: #0f172a !important;
        border: 1px solid rgba(255, 255, 255, 0.25) !important;
        border-radius: 8px !important;
        padding: 5px 8px !important;
        display: flex !important;
        align-items: center !important;
        gap: 5px !important;
        box-shadow: 0 12px 30px rgba(0, 0, 0, 0.75) !important;
        pointer-events: auto !important;
        box-sizing: border-box !important;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important;
      }
      .scanext-snip-btn {
        background: #1e293b !important;
        color: #f8fafc !important;
        border: 1px solid rgba(255, 255, 255, 0.2) !important;
        padding: 6px 10px !important;
        border-radius: 6px !important;
        font-size: 12px !important;
        font-weight: 600 !important;
        line-height: 1 !important;
        cursor: pointer !important;
        display: inline-flex !important;
        align-items: center !important;
        gap: 6px !important;
        transition: all 0.15s ease !important;
        white-space: nowrap !important;
        text-decoration: none !important;
        text-transform: none !important;
        box-shadow: none !important;
        height: auto !important;
        min-height: 28px !important;
      }
      .scanext-snip-btn:hover {
        background: #334155 !important;
        border-color: #38bdf8 !important;
        color: #ffffff !important;
      }
      .scanext-snip-btn-active {
        background: #0284c7 !important;
        color: #ffffff !important;
        border-color: #38bdf8 !important;
        box-shadow: 0 0 10px rgba(56, 189, 248, 0.5) !important;
      }
      .scanext-snip-btn:disabled {
        opacity: 0.4 !important;
        cursor: not-allowed !important;
        border-color: rgba(255, 255, 255, 0.1) !important;
      }
      .scanext-snip-btn-primary {
        background: linear-gradient(135deg, #0284c7, #0369a1) !important;
        color: #ffffff !important;
        border: 1px solid #38bdf8 !important;
        box-shadow: 0 2px 8px rgba(2, 132, 199, 0.5) !important;
      }
      .scanext-snip-btn-primary:hover {
        background: linear-gradient(135deg, #38bdf8, #0284c7) !important;
        color: #0f172a !important;
      }
      .scanext-snip-btn-close {
        background: transparent !important;
        border: none !important;
        color: #94a3b8 !important;
        padding: 6px 8px !important;
        font-size: 13px !important;
        cursor: pointer !important;
        border-radius: 4px !important;
        display: inline-flex !important;
        align-items: center !important;
        justify-content: center !important;
      }
      .scanext-snip-btn-close:hover {
        color: #ef4444 !important;
        background: rgba(239, 68, 68, 0.15) !important;
      }
      .scanext-snip-color-bar {
        display: flex !important;
        align-items: center !important;
        gap: 5px !important;
        background: rgba(30, 41, 59, 0.95) !important;
        border: 1px solid rgba(255, 255, 255, 0.2) !important;
        border-radius: 20px !important;
        padding: 3px 6px !important;
        margin-left: 2px !important;
      }
      .scanext-snip-sub-btn {
        background: transparent !important;
        color: #cbd5e1 !important;
        border: 1px solid rgba(255, 255, 255, 0.18) !important;
        border-radius: 12px !important;
        padding: 2px 8px !important;
        font-size: 11px !important;
        font-weight: 600 !important;
        cursor: pointer !important;
        white-space: nowrap !important;
        transition: all 0.15s ease !important;
      }
      .scanext-snip-sub-btn:hover {
        background: rgba(255, 255, 255, 0.1) !important;
        color: #ffffff !important;
      }
      .scanext-snip-sub-btn.active {
        background: #38bdf8 !important;
        color: #0f172a !important;
        border-color: #38bdf8 !important;
        font-weight: 700 !important;
      }
      .scanext-snip-handle {
        position: absolute !important;
        width: 9px !important;
        height: 9px !important;
        background: #ffffff !important;
        border: 1.5px solid #0284c7 !important;
        border-radius: 2px !important;
        box-sizing: border-box !important;
        z-index: 10 !important;
        pointer-events: auto !important;
        box-shadow: 0 1px 3px rgba(0,0,0,0.5) !important;
      }
      .scanext-snip-handle-nw { top: -5px !important; left: -5px !important; cursor: nwse-resize !important; }
      .scanext-snip-handle-ne { top: -5px !important; right: -5px !important; cursor: nesw-resize !important; }
      .scanext-snip-handle-se { bottom: -5px !important; right: -5px !important; cursor: nwse-resize !important; }
      .scanext-snip-handle-sw { bottom: -5px !important; left: -5px !important; cursor: nesw-resize !important; }
      .scanext-snip-handle-n  { top: -5px !important; left: calc(50% - 4.5px) !important; cursor: ns-resize !important; }
      .scanext-snip-handle-s  { bottom: -5px !important; left: calc(50% - 4.5px) !important; cursor: ns-resize !important; }
      .scanext-snip-handle-w  { top: calc(50% - 4.5px) !important; left: -5px !important; cursor: ew-resize !important; }
      .scanext-snip-handle-e  { top: calc(50% - 4.5px) !important; right: -5px !important; cursor: ew-resize !important; }
      .scanext-color-dot {
        width: 15px !important;
        height: 15px !important;
        border-radius: 50% !important;
        cursor: pointer !important;
        border: 2px solid transparent !important;
        transition: transform 0.15s ease, border-color 0.15s ease !important;
        box-sizing: border-box !important;
      }
      .scanext-color-dot:hover {
        transform: scale(1.2) !important;
      }
      .scanext-color-dot.active {
        border-color: #ffffff !important;
        transform: scale(1.25) !important;
        box-shadow: 0 0 6px rgba(255, 255, 255, 0.8) !important;
      }
      .scanext-snip-canvas-wrap {
        position: absolute !important;
        top: 0 !important;
        left: 0 !important;
        width: 100% !important;
        height: 100% !important;
        overflow: hidden !important;
        pointer-events: auto !important;
        border-radius: 0 !important;
      }
      .scanext-snip-canvas {
        position: absolute !important;
        top: 0 !important;
        left: 0 !important;
        width: 100% !important;
        height: 100% !important;
        display: block !important;
        box-sizing: border-box !important;
        touch-action: none !important;
        cursor: crosshair !important;
      }
      .scanext-snip-preview-box {
        position: absolute !important;
        border: 2px dashed #38bdf8 !important;
        background: rgba(56, 189, 248, 0.2) !important;
        pointer-events: none !important;
        border-radius: 3px !important;
        z-index: 10 !important;
      }
    `;
    (document.head || document.documentElement).appendChild(style);
  }

  async function startDesktopSnippingTool() {
    ensureSnipperStyles();
    document.querySelectorAll('#scanext-snipper-overlay, .scanext-snip-toolbar, .scanext-snip-selection, .scanext-snip-handle').forEach(el => el.remove());

    let stream = null;
    try {
      stream = await navigator.mediaDevices.getDisplayMedia({
        video: { cursor: 'never', displaySurface: 'monitor' },
        audio: false
      });
    } catch (err) {
      if (err.name !== 'NotAllowedError') {
        console.warn('ScanExtension: Desktop capture permission error:', err);
      }
      return;
    }

    if (!stream) return;

    try {
      const video = document.createElement('video');
      video.srcObject = stream;
      await video.play();
      await new Promise(r => setTimeout(r, 160));

      const canvas = document.createElement('canvas');
      canvas.width = video.videoWidth || window.innerWidth;
      canvas.height = video.videoHeight || window.innerHeight;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(video, 0, 0);

      stream.getTracks().forEach(t => t.stop());

      const dataUrl = canvas.toDataURL('image/png');
      const desktopImg = new Image();
      desktopImg.onload = () => {
        startSnippingTool(desktopImg);
      };
      desktopImg.src = dataUrl;
    } catch (vErr) {
      console.warn('ScanExtension: Video frame capture error:', vErr);
      stream.getTracks().forEach(t => t.stop());
    }
  }

  async function startSnippingTool(customPristineImg = null) {
    ensureSnipperStyles();
    // Clean up any stale overlays first
    document.querySelectorAll('#scanext-snipper-overlay, .scanext-snip-toolbar, .scanext-snip-selection, .scanext-snip-handle').forEach(el => el.remove());

    // 1. Capture 100% pristine, clean screenshot of the viewport BEFORE the dark overlay is added
    let pristineImg = customPristineImg;
    if (!pristineImg) {
      try {
        const res = await chrome.runtime.sendMessage({ type: 'CAPTURE_FOR_SNIP' });
        if (res && res.dataUrl) {
          pristineImg = new Image();
          pristineImg.src = res.dataUrl;
        }
      } catch (err) {
        console.warn('ScanExtension: Early pristine screenshot capture error:', err);
      }
    }

    // 2. Now attach the interactive dimmed overlay for selection
    const overlay = document.createElement('div');
    overlay.id = 'scanext-snipper-overlay';
    overlay.style.cssText = 'position:fixed!important;top:0!important;left:0!important;width:100vw!important;height:100vh!important;z-index:2147483647!important;background:rgba(0,0,0,0.18)!important;cursor:crosshair!important;user-select:none!important;margin:0!important;padding:0!important;box-sizing:border-box!important;';

    let isDrawing = false;
    let startX = 0;
    let startY = 0;
    let currentBox = null;
    let currentToolbar = null;
    let finalRect = null;

    function cleanup() {
      document.removeEventListener('keydown', onKeyDown);
      document.querySelectorAll('#scanext-snipper-overlay, .scanext-snip-toolbar, .scanext-snip-selection, .scanext-snip-handle').forEach(el => el.remove());
      if (overlay && overlay.parentNode) overlay.remove();
      if (currentToolbar && currentToolbar.parentNode) currentToolbar.remove();
      if (currentBox && currentBox.parentNode) currentBox.remove();
    }

    function onKeyDown(e) {
      if (e.key === 'Escape') {
        cleanup();
      }
    }
    document.addEventListener('keydown', onKeyDown);

    overlay.addEventListener('mousedown', (e) => {
      // Only start a new selection if clicking directly on the dimmed overlay backdrop
      if (e.target !== overlay) return;

      if (currentToolbar) {
        currentToolbar.remove();
        currentToolbar = null;
      }
      if (currentBox) {
        currentBox.remove();
        currentBox = null;
        overlay.style.background = 'rgba(0,0,0,0.18)';
      }

      isDrawing = true;
      startX = e.clientX;
      startY = e.clientY;

      overlay.style.background = 'transparent';

      currentBox = document.createElement('div');
      currentBox.className = 'scanext-snip-selection';
      currentBox.style.cssText = `position:absolute!important;border:2px solid #38bdf8!important;box-shadow:0 0 0 99999px rgba(0,0,0,0.18)!important;pointer-events:auto!important;border-radius:2px!important;background:transparent!important;left:${startX}px!important;top:${startY}px!important;width:0px!important;height:0px!important;box-sizing:border-box!important;`;
      currentBox.addEventListener('mousedown', (evt) => evt.stopPropagation());

      const dim = document.createElement('div');
      dim.className = 'scanext-snip-dimensions';
      dim.style.cssText = 'position:absolute;top:-24px;left:0;background:#0f172a;color:#38bdf8;font-size:11px;font-weight:700;padding:2px 6px;border-radius:4px;border:1px solid rgba(56,189,248,0.4);white-space:nowrap;font-family:-apple-system,sans-serif;';
      dim.textContent = '0 x 0 px';
      currentBox.appendChild(dim);

      overlay.appendChild(currentBox);
    });

    overlay.addEventListener('mousemove', (e) => {
      if (!isDrawing || !currentBox) return;

      const currentX = e.clientX;
      const currentY = e.clientY;

      const x = Math.min(startX, currentX);
      const y = Math.min(startY, currentY);
      const w = Math.abs(currentX - startX);
      const h = Math.abs(currentY - startY);

      currentBox.style.left = `${x}px`;
      currentBox.style.top = `${y}px`;
      currentBox.style.width = `${w}px`;
      currentBox.style.height = `${h}px`;

      const dim = currentBox.querySelector('.scanext-snip-dimensions');
      if (dim) {
        dim.textContent = `${Math.round(w)} × ${Math.round(h)} px`;
        if (y < 30) {
          dim.style.top = '6px';
          dim.style.left = '6px';
        } else {
          dim.style.top = '-24px';
          dim.style.left = '0px';
        }
      }
    });

    overlay.addEventListener('mouseup', (e) => {
      if (!isDrawing || !currentBox) return;
      isDrawing = false;

      const currentX = e.clientX;
      const currentY = e.clientY;

      const x = Math.min(startX, currentX);
      const y = Math.min(startY, currentY);
      const w = Math.abs(currentX - startX);
      const h = Math.abs(currentY - startY);

      if (w < 12 || h < 12) {
        currentBox.remove();
        currentBox = null;
        overlay.style.background = 'rgba(0,0,0,0.18)';
        return;
      }

      finalRect = { x, y, w, h };

      // Initialize Interactive Canvas Inside Selection Box Wrap
      const canvasWrap = document.createElement('div');
      canvasWrap.className = 'scanext-snip-canvas-wrap';
      canvasWrap.style.cssText = 'position:absolute!important;top:0!important;left:0!important;width:100%!important;height:100%!important;overflow:hidden!important;pointer-events:auto!important;';

      const snipCanvas = document.createElement('canvas');
      snipCanvas.className = 'scanext-snip-canvas';
      snipCanvas.style.cssText = 'position:absolute!important;top:0!important;left:0!important;width:100%!important;height:100%!important;display:block!important;box-sizing:border-box!important;touch-action:none!important;cursor:crosshair!important;';
      canvasWrap.appendChild(snipCanvas);
      currentBox.appendChild(canvasWrap);

      const dpr = window.devicePixelRatio || 1;
      const snipCtx = snipCanvas.getContext('2d');
      const undoStack = [];
      let activeEditorTool = 'none'; // 'none' | 'blur' | 'pen' | 'highlighter'
      let activeBlurMode = 'box'; // 'box' | 'brush'
      let activeBlurBrushRadius = 26; // 26px radius = 52px wide brush
      let activePenColor = '#ef4444';
      let activeHighlighterColor = 'rgba(254, 240, 138, 0.70)';
      let isEditorDrawing = false;
      let editStartX = 0;
      let editStartY = 0;
      let penPoints = [];
      let strokeSnapshot = null;
      let previewBox = null;

      // Draw pristine, undarkened crop onto canvas immediately with exact 1:1 pixel mapping
      function renderPristineCrop(imgSource) {
        if (!imgSource || !imgSource.naturalWidth) return;
        const vw = window.innerWidth;
        const vh = window.innerHeight;
        const scaleX = imgSource.naturalWidth / vw;
        const scaleY = imgSource.naturalHeight / vh;

        const cropW = Math.max(1, Math.round(finalRect.w * scaleX));
        const cropH = Math.max(1, Math.round(finalRect.h * scaleY));
        snipCanvas.width = cropW;
        snipCanvas.height = cropH;

        const srcX = Math.round(finalRect.x * scaleX);
        const srcY = Math.round(finalRect.y * scaleY);
        snipCtx.drawImage(imgSource, srcX, srcY, cropW, cropH, 0, 0, cropW, cropH);
      }

      if (pristineImg && pristineImg.complete && pristineImg.naturalWidth > 0) {
        renderPristineCrop(pristineImg);
      } else if (pristineImg) {
        pristineImg.onload = () => renderPristineCrop(pristineImg);
      } else {
        // Fallback: hide overlay briefly to capture pristine tab without dimming
        overlay.style.visibility = 'hidden';
        setTimeout(async () => {
          try {
            const res = await chrome.runtime.sendMessage({ type: 'CAPTURE_FOR_SNIP' });
            overlay.style.visibility = 'visible';
            if (res && res.dataUrl) {
              const fallbackImg = new Image();
              fallbackImg.onload = () => renderPristineCrop(fallbackImg);
              fallbackImg.src = res.dataUrl;
            }
          } catch (err) {
            overlay.style.visibility = 'visible';
          }
        }, 30);
      }

      // Add 8 Interactive Corner & Edge Resize Handles
      const handles = ['nw', 'ne', 'se', 'sw', 'n', 's', 'e', 'w'];
      handles.forEach(dir => {
        const hEl = document.createElement('div');
        hEl.className = `scanext-snip-handle scanext-snip-handle-${dir}`;
        hEl.dataset.dir = dir;
        currentBox.appendChild(hEl);

        hEl.addEventListener('pointerdown', (evt) => {
          evt.stopPropagation();
          evt.preventDefault();
          try { hEl.setPointerCapture(evt.pointerId); } catch (e) {}

          const startMouseX = evt.clientX;
          const startMouseY = evt.clientY;
          const initX = finalRect.x;
          const initY = finalRect.y;
          const initW = finalRect.w;
          const initH = finalRect.h;

          function onHandleMove(mEvt) {
            mEvt.stopPropagation();
            mEvt.preventDefault();
            const dx = mEvt.clientX - startMouseX;
            const dy = mEvt.clientY - startMouseY;

            let newX = initX;
            let newY = initY;
            let newW = initW;
            let newH = initH;

            if (dir.includes('e')) newW = Math.max(20, initW + dx);
            if (dir.includes('s')) newH = Math.max(20, initH + dy);
            if (dir.includes('w')) {
              const proposedW = initW - dx;
              if (proposedW >= 20) {
                newW = proposedW;
                newX = initX + dx;
              }
            }
            if (dir.includes('n')) {
              const proposedH = initH - dy;
              if (proposedH >= 20) {
                newH = proposedH;
                newY = initY + dy;
              }
            }

            finalRect = { x: newX, y: newY, w: newW, h: newH };
            currentBox.style.left = `${newX}px`;
            currentBox.style.top = `${newY}px`;
            currentBox.style.width = `${newW}px`;
            currentBox.style.height = `${newH}px`;

            const dimBadge = currentBox.querySelector('.scanext-snip-dimensions');
            if (dimBadge) {
              dimBadge.textContent = `${Math.round(newW)} × ${Math.round(newH)} px`;
            }

            renderPristineCrop(pristineImg);
            positionToolbar();
          }

          function onHandleUp(uEvt) {
            try { hEl.releasePointerCapture(uEvt.pointerId); } catch (e) {}
            window.removeEventListener('pointermove', onHandleMove);
            window.removeEventListener('pointerup', onHandleUp);
          }

          window.addEventListener('pointermove', onHandleMove);
          window.addEventListener('pointerup', onHandleUp);
        });
      });

      function pushUndo() {
        if (undoStack.length >= 25) undoStack.shift();
        undoStack.push(snipCtx.getImageData(0, 0, snipCanvas.width, snipCanvas.height));
        updateUndoButton();
      }

      function updateUndoButton() {
        const undoBtn = currentToolbar.querySelector('#scanext-snip-undo');
        if (undoBtn) {
          undoBtn.disabled = (undoStack.length === 0);
        }
      }

      function applyMosaicBlur(ctx, rx, ry, rw, rh) {
        if (rw < 2 || rh < 2) return;
        const factor = Math.max(8, Math.round(Math.min(rw, rh) / 4));
        const sw = Math.max(1, Math.floor(rw / factor));
        const sh = Math.max(1, Math.floor(rh / factor));

        const subData = ctx.getImageData(rx, ry, rw, rh);
        const tempCanvas = document.createElement('canvas');
        tempCanvas.width = rw;
        tempCanvas.height = rh;
        tempCanvas.getContext('2d').putImageData(subData, 0, 0);

        const offCanvas = document.createElement('canvas');
        offCanvas.width = sw;
        offCanvas.height = sh;
        const offCtx = offCanvas.getContext('2d');
        offCtx.drawImage(tempCanvas, 0, 0, sw, sh);

        ctx.save();
        ctx.imageSmoothingEnabled = false;
        ctx.drawImage(offCanvas, 0, 0, sw, sh, rx, ry, rw, rh);
        ctx.strokeStyle = 'rgba(0, 0, 0, 0.12)';
        ctx.lineWidth = 1;
        ctx.strokeRect(rx + 0.5, ry + 0.5, rw - 1, rh - 1);
        ctx.restore();
      }

      function applyBrushBlur(ctx, points, radius) {
        if (!points || points.length === 0) return;
        const w = ctx.canvas.width;
        const h = ctx.canvas.height;
        if (w < 2 || h < 2) return;

        // 1. Generate full-res pixelated mosaic in an offscreen canvas
        const factor = Math.max(8, Math.round(radius / 2.2));
        const sw = Math.max(1, Math.floor(w / factor));
        const sh = Math.max(1, Math.floor(h / factor));

        const offCanvas = document.createElement('canvas');
        offCanvas.width = sw;
        offCanvas.height = sh;
        const offCtx = offCanvas.getContext('2d');
        offCtx.drawImage(ctx.canvas, 0, 0, sw, sh);

        const mosaicCanvas = document.createElement('canvas');
        mosaicCanvas.width = w;
        mosaicCanvas.height = h;
        const mosaicCtx = mosaicCanvas.getContext('2d');
        mosaicCtx.imageSmoothingEnabled = false;
        mosaicCtx.drawImage(offCanvas, 0, 0, sw, sh, 0, 0, w, h);

        // 2. Draw the actual brush stroke path on a mask canvas
        const maskCanvas = document.createElement('canvas');
        maskCanvas.width = w;
        maskCanvas.height = h;
        const maskCtx = maskCanvas.getContext('2d');

        maskCtx.strokeStyle = '#000000';
        maskCtx.fillStyle = '#000000';
        maskCtx.lineWidth = radius * 2;
        maskCtx.lineCap = 'round';
        maskCtx.lineJoin = 'round';

        if (points.length === 1) {
          maskCtx.beginPath();
          maskCtx.arc(points[0].x, points[0].y, radius, 0, Math.PI * 2);
          maskCtx.fill();
        } else if (points.length === 2) {
          maskCtx.beginPath();
          maskCtx.moveTo(points[0].x, points[0].y);
          maskCtx.lineTo(points[1].x, points[1].y);
          maskCtx.stroke();
        } else {
          maskCtx.beginPath();
          maskCtx.moveTo(points[0].x, points[0].y);
          for (let i = 1; i < points.length - 1; i++) {
            const xc = (points[i].x + points[i + 1].x) / 2;
            const yc = (points[i].y + points[i + 1].y) / 2;
            maskCtx.quadraticCurveTo(points[i].x, points[i].y, xc, yc);
          }
          maskCtx.lineTo(points[points.length - 1].x, points[points.length - 1].y);
          maskCtx.stroke();
        }

        // 3. Clip mosaic to the brush stroke mask (source-in)
        maskCtx.globalCompositeOperation = 'source-in';
        maskCtx.drawImage(mosaicCanvas, 0, 0);

        // 4. Draw the smooth pixelated stroke onto main canvas
        ctx.save();
        ctx.drawImage(maskCanvas, 0, 0);
        ctx.restore();
      }

      // Pointer event handlers on interactive canvas
      snipCanvas.addEventListener('pointerdown', (e) => {
        if (activeEditorTool === 'none') return;
        e.stopPropagation();
        e.preventDefault();
        isEditorDrawing = true;
        try { snipCanvas.setPointerCapture(e.pointerId); } catch (err) {}

        const rect = snipCanvas.getBoundingClientRect();
        editStartX = (e.clientX - rect.left) * (snipCanvas.width / rect.width);
        editStartY = (e.clientY - rect.top) * (snipCanvas.height / rect.height);

        if (activeEditorTool === 'pen' || activeEditorTool === 'highlighter') {
          strokeSnapshot = snipCtx.getImageData(0, 0, snipCanvas.width, snipCanvas.height);
          pushUndo();
          penPoints = [{ x: editStartX, y: editStartY }];
        } else if (activeEditorTool === 'blur') {
          if (activeBlurMode === 'brush') {
            strokeSnapshot = snipCtx.getImageData(0, 0, snipCanvas.width, snipCanvas.height);
            pushUndo();
            penPoints = [{ x: editStartX, y: editStartY }];
          } else {
            previewBox = document.createElement('div');
            previewBox.className = 'scanext-snip-preview-box';
            currentBox.appendChild(previewBox);
          }
        }
      });

      snipCanvas.addEventListener('pointermove', (e) => {
        if (!isEditorDrawing) return;
        e.stopPropagation();
        e.preventDefault();

        const rect = snipCanvas.getBoundingClientRect();
        const curX = (e.clientX - rect.left) * (snipCanvas.width / rect.width);
        const curY = (e.clientY - rect.top) * (snipCanvas.height / rect.height);

        if (activeEditorTool === 'pen' && strokeSnapshot) {
          penPoints.push({ x: curX, y: curY });
          snipCtx.putImageData(strokeSnapshot, 0, 0);

          snipCtx.save();
          snipCtx.strokeStyle = activePenColor;
          snipCtx.lineWidth = Math.max(2.5, 3 * dpr);
          snipCtx.lineCap = 'round';
          snipCtx.lineJoin = 'round';
          snipCtx.beginPath();
          snipCtx.moveTo(penPoints[0].x, penPoints[0].y);

          if (penPoints.length === 2) {
            snipCtx.lineTo(penPoints[1].x, penPoints[1].y);
          } else {
            for (let i = 1; i < penPoints.length - 1; i++) {
              const xc = (penPoints[i].x + penPoints[i + 1].x) / 2;
              const yc = (penPoints[i].y + penPoints[i + 1].y) / 2;
              snipCtx.quadraticCurveTo(penPoints[i].x, penPoints[i].y, xc, yc);
            }
            snipCtx.lineTo(penPoints[penPoints.length - 1].x, penPoints[penPoints.length - 1].y);
          }
          snipCtx.stroke();
          snipCtx.restore();

        } else if (activeEditorTool === 'highlighter' && strokeSnapshot) {
          penPoints.push({ x: curX, y: curY });
          snipCtx.putImageData(strokeSnapshot, 0, 0);

          snipCtx.save();
          snipCtx.globalCompositeOperation = 'multiply';
          snipCtx.strokeStyle = activeHighlighterColor;
          snipCtx.lineWidth = Math.max(14, 18 * dpr);
          snipCtx.lineCap = 'round';
          snipCtx.lineJoin = 'round';
          snipCtx.beginPath();
          snipCtx.moveTo(penPoints[0].x, penPoints[0].y);

          if (penPoints.length === 2) {
            snipCtx.lineTo(penPoints[1].x, penPoints[1].y);
          } else {
            for (let i = 1; i < penPoints.length - 1; i++) {
              const xc = (penPoints[i].x + penPoints[i + 1].x) / 2;
              const yc = (penPoints[i].y + penPoints[i + 1].y) / 2;
              snipCtx.quadraticCurveTo(penPoints[i].x, penPoints[i].y, xc, yc);
            }
            snipCtx.lineTo(penPoints[penPoints.length - 1].x, penPoints[penPoints.length - 1].y);
          }
          snipCtx.stroke();
          snipCtx.restore();

        } else if (activeEditorTool === 'blur') {
          if (activeBlurMode === 'brush' && strokeSnapshot) {
            penPoints.push({ x: curX, y: curY });
            snipCtx.putImageData(strokeSnapshot, 0, 0);
            applyBrushBlur(snipCtx, penPoints, Math.max(10, activeBlurBrushRadius * dpr));
          } else if (previewBox) {
            const cssStartX = Math.min(e.clientX - rect.left, editStartX * (rect.width / snipCanvas.width));
            const cssStartY = Math.min(e.clientY - rect.top, editStartY * (rect.height / snipCanvas.height));
            const cssW = Math.abs((e.clientX - rect.left) - (editStartX * (rect.width / snipCanvas.width)));
            const cssH = Math.abs((e.clientY - rect.top) - (editStartY * (rect.height / snipCanvas.height)));

            previewBox.style.left = `${cssStartX}px`;
            previewBox.style.top = `${cssStartY}px`;
            previewBox.style.width = `${cssW}px`;
            previewBox.style.height = `${cssH}px`;
          }
        }
      });

      snipCanvas.addEventListener('pointerup', (e) => {
        if (!isEditorDrawing) return;
        isEditorDrawing = false;
        e.stopPropagation();

        try { snipCanvas.releasePointerCapture(e.pointerId); } catch (err) {}

        if (activeEditorTool === 'pen' || activeEditorTool === 'highlighter') {
          strokeSnapshot = null;
          penPoints = [];
        } else if (activeEditorTool === 'blur') {
          if (activeBlurMode === 'brush') {
            strokeSnapshot = null;
            penPoints = [];
          } else {
            if (previewBox) {
              previewBox.remove();
              previewBox = null;
            }
            const rect = snipCanvas.getBoundingClientRect();
            const curX = (e.clientX - rect.left) * (snipCanvas.width / rect.width);
            const curY = (e.clientY - rect.top) * (snipCanvas.height / rect.height);

            const rx = Math.min(editStartX, curX);
            const ry = Math.min(editStartY, curY);
            const rw = Math.abs(curX - editStartX);
            const rh = Math.abs(curY - editStartY);

            if (rw >= 4 && rh >= 4) {
              pushUndo();
              applyMosaicBlur(snipCtx, Math.round(rx), Math.round(ry), Math.round(rw), Math.round(rh));
            }
          }
        }
      });

      // Render Floating Toolbar
      currentToolbar = document.createElement('div');
      currentToolbar.className = 'scanext-snip-toolbar';

      function positionToolbar() {
        if (!currentToolbar || !finalRect) return;
        let toolbarTop = finalRect.y + finalRect.h + 10;
        if (toolbarTop + 55 > window.innerHeight) {
          if (finalRect.y - 52 >= 10) {
            toolbarTop = finalRect.y - 52;
          } else {
            toolbarTop = Math.max(10, finalRect.y + finalRect.h - 55);
          }
        }
        toolbarTop = Math.max(10, Math.min(window.innerHeight - 55, toolbarTop));

        let toolbarLeft = Math.round(finalRect.x + (finalRect.w / 2) - 250);
        toolbarLeft = Math.max(12, Math.min(window.innerWidth - 530, toolbarLeft));

        currentToolbar.style.top = `${toolbarTop}px`;
        currentToolbar.style.left = `${toolbarLeft}px`;
      }

      currentToolbar.style.cssText = `position:fixed!important;top:0px!important;left:0px!important;z-index:2147483647!important;background:#0f172a!important;border:1px solid rgba(255,255,255,0.25)!important;border-radius:8px!important;padding:5px 8px!important;display:flex!important;align-items:center!important;gap:5px!important;box-shadow:0 12px 30px rgba(0,0,0,0.75)!important;pointer-events:auto!important;box-sizing:border-box!important;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif!important;animation:none!important;`;
      positionToolbar();

      currentToolbar.innerHTML = `
        <button type="button" class="scanext-snip-btn scanext-snip-btn-primary" id="scanext-snip-copy-img" title="Kopier bilde til utklippstavlen (Cmd+V / Ctrl+V)">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2">
            <rect width="18" height="18" x="3" y="3" rx="2" ry="2"></rect>
            <circle cx="9" cy="9" r="2"></circle>
            <path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"></path>
          </svg>
          <span>Kopier Bilde</span>
        </button>

        <button type="button" class="scanext-snip-btn" id="scanext-snip-tool-blur" title="Sladd / Blur (Skjerm personopplysninger)">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2">
            <rect width="18" height="18" x="3" y="3" rx="2" ry="2" stroke-dasharray="3 3"></rect>
            <path d="M9 9h6v6H9z" fill="currentColor" fill-opacity="0.3"></path>
          </svg>
          <span>Sladd</span>
        </button>

        <button type="button" class="scanext-snip-btn" id="scanext-snip-tool-pen" title="Tegn frihånd med penn">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2">
            <path d="M12 19l7-7 3 3-7 7-3-3z"></path>
            <path d="M18 13l-1.5-7.5L2 2l3.5 14.5L13 18l5-5z"></path>
            <path d="M2 2l7.586 7.586"></path>
          </svg>
          <span>Penn</span>
        </button>

        <button type="button" class="scanext-snip-btn" id="scanext-snip-tool-highlighter" title="Merk med overstrykingstusj">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2">
            <path d="m9 11-6 6v3h3l6-6"></path>
            <path d="m22 12-4.6 4.6a2 2 0 0 1-2.8 0l-5.2-5.2a2 2 0 0 1 0-2.8L14 4"></path>
          </svg>
          <span>Tusj</span>
        </button>

        <div id="scanext-snip-colors" class="scanext-snip-color-bar" style="display:none;"></div>

        <button type="button" class="scanext-snip-btn" id="scanext-snip-undo" title="Angre siste endring (Ctrl+Z / Cmd+Z)" disabled>
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2">
            <path d="M3 7v6h6"></path>
            <path d="M21 17a9 9 0 0 0-9-9 9 9 0 0 0-6 2.3L3 13"></path>
          </svg>
          <span>Angre</span>
        </button>

        <button type="button" class="scanext-snip-btn" id="scanext-snip-copy-txt" title="Kopier kun teksten i dette utsnittet">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2">
            <polyline points="4 7 4 4 20 4 20 7"></polyline>
            <line x1="9" y1="20" x2="15" y2="20"></line>
            <line x1="12" y1="4" x2="12" y2="20"></line>
          </svg>
          <span>Kopier Tekst</span>
        </button>

        <button type="button" class="scanext-snip-btn" id="scanext-snip-download" title="Last ned bildet som .PNG">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2">
            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
            <polyline points="7 10 12 15 17 10"></polyline>
            <line x1="12" y1="15" x2="12" y2="3"></line>
          </svg>
          <span>.PNG</span>
        </button>

        <button type="button" class="scanext-snip-btn-close" id="scanext-snip-close" title="Lukk (Esc)">✕</button>
      `;

      currentToolbar.addEventListener('mousedown', (evt) => evt.stopPropagation());
      currentToolbar.addEventListener('pointerdown', (evt) => evt.stopPropagation());
      currentToolbar.addEventListener('mouseup', (evt) => evt.stopPropagation());
      currentToolbar.addEventListener('click', (evt) => evt.stopPropagation());

      overlay.appendChild(currentToolbar);

      const PEN_COLORS = [
        { id: '#ef4444', title: 'Rød', dotBg: '#ef4444' },
        { id: '#3b82f6', title: 'Blå', dotBg: '#3b82f6' },
        { id: '#10b981', title: 'Grønn', dotBg: '#10b981' },
        { id: '#0f172a', title: 'Svart', dotBg: '#0f172a' }
      ];

      const HIGHLIGHTER_COLORS = [
        { id: 'rgba(254, 240, 138, 0.70)', title: 'Gul', dotBg: '#fde047' },
        { id: 'rgba(187, 247, 208, 0.70)', title: 'Grønn', dotBg: '#4ade80' },
        { id: 'rgba(251, 207, 232, 0.70)', title: 'Rosa', dotBg: '#f472b6' },
        { id: 'rgba(186, 230, 253, 0.70)', title: 'Blå', dotBg: '#38bdf8' }
      ];

      // Tool Switcher Logic
      function updateColorBar() {
        const colorBar = currentToolbar.querySelector('#scanext-snip-colors');
        if (!colorBar) return;

        if (activeEditorTool === 'blur') {
          colorBar.style.display = 'flex';
          colorBar.innerHTML = `
            <button type="button" class="scanext-snip-sub-btn ${activeBlurMode === 'box' ? 'active' : ''}" id="scanext-blur-mode-box" title="Dra en boks over området">🔲 Boks</button>
            <button type="button" class="scanext-snip-sub-btn ${activeBlurMode === 'brush' ? 'active' : ''}" id="scanext-blur-mode-brush" title="Tegn over med bred børste">🖌️ Børste</button>
            ${activeBlurMode === 'brush' ? `
              <span style="width:1px;height:14px;background:rgba(255,255,255,0.25);margin:0 2px;"></span>
              <button type="button" class="scanext-snip-sub-btn ${activeBlurBrushRadius === 14 ? 'active' : ''}" data-radius="14" title="Tynn børste (28px)">S</button>
              <button type="button" class="scanext-snip-sub-btn ${activeBlurBrushRadius === 26 ? 'active' : ''}" data-radius="26" title="Medium børste (52px)">M</button>
              <button type="button" class="scanext-snip-sub-btn ${activeBlurBrushRadius === 45 ? 'active' : ''}" data-radius="45" title="Ekstra bred børste (90px)">L</button>
            ` : ''}
          `;

          colorBar.querySelector('#scanext-blur-mode-box').addEventListener('click', (e) => {
            e.stopPropagation();
            activeBlurMode = 'box';
            updateColorBar();
          });
          colorBar.querySelector('#scanext-blur-mode-brush').addEventListener('click', (e) => {
            e.stopPropagation();
            activeBlurMode = 'brush';
            updateColorBar();
          });

          if (activeBlurMode === 'brush') {
            colorBar.querySelectorAll('[data-radius]').forEach(btn => {
              btn.addEventListener('click', (e) => {
                e.stopPropagation();
                activeBlurBrushRadius = parseInt(btn.getAttribute('data-radius'), 10);
                updateColorBar();
              });
            });
          }
        } else if (activeEditorTool === 'pen') {
          colorBar.style.display = 'flex';
          colorBar.innerHTML = PEN_COLORS.map(c => `
            <div class="scanext-color-dot ${c.id === activePenColor ? 'active' : ''}" 
                 style="background:${c.dotBg};${c.id === '#0f172a' ? 'border:1px solid rgba(255,255,255,0.4);' : ''}" 
                 data-color="${c.id}" 
                 title="${c.title}"></div>
          `).join('');

          colorBar.querySelectorAll('.scanext-color-dot').forEach(dot => {
            dot.addEventListener('click', (e) => {
              e.stopPropagation();
              activePenColor = dot.getAttribute('data-color');
              updateColorBar();
            });
          });
        } else if (activeEditorTool === 'highlighter') {
          colorBar.style.display = 'flex';
          colorBar.innerHTML = HIGHLIGHTER_COLORS.map(c => `
            <div class="scanext-color-dot ${c.id === activeHighlighterColor ? 'active' : ''}" 
                 style="background:${c.dotBg};" 
                 data-color="${c.id}" 
                 title="${c.title}"></div>
          `).join('');

          colorBar.querySelectorAll('.scanext-color-dot').forEach(dot => {
            dot.addEventListener('click', (e) => {
              e.stopPropagation();
              activeHighlighterColor = dot.getAttribute('data-color');
              updateColorBar();
            });
          });
        } else {
          colorBar.style.display = 'none';
          colorBar.innerHTML = '';
        }
      }

      function setTool(toolName) {
        activeEditorTool = (activeEditorTool === toolName) ? 'none' : toolName;
        currentToolbar.querySelectorAll('.scanext-snip-btn').forEach(b => {
          if (b.id.startsWith('scanext-snip-tool-')) {
            b.classList.remove('scanext-snip-btn-active');
          }
        });
        if (activeEditorTool !== 'none') {
          const activeBtn = currentToolbar.querySelector(`#scanext-snip-tool-${activeEditorTool}`);
          if (activeBtn) activeBtn.classList.add('scanext-snip-btn-active');
          snipCanvas.style.cursor = 'crosshair';
        } else {
          snipCanvas.style.cursor = 'default';
        }
        updateColorBar();
      }

      currentToolbar.querySelector('#scanext-snip-tool-blur').addEventListener('click', (e) => {
        e.stopPropagation();
        setTool('blur');
      });

      currentToolbar.querySelector('#scanext-snip-tool-pen').addEventListener('click', (e) => {
        e.stopPropagation();
        setTool('pen');
      });

      currentToolbar.querySelector('#scanext-snip-tool-highlighter').addEventListener('click', (e) => {
        e.stopPropagation();
        setTool('highlighter');
      });

      currentToolbar.querySelector('#scanext-snip-undo').addEventListener('click', (e) => {
        e.stopPropagation();
        if (undoStack.length > 0) {
          const prev = undoStack.pop();
          snipCtx.putImageData(prev, 0, 0);
          updateUndoButton();
        }
      });

      // Helper to get Canvas Blob
      function getCanvasBlob() {
        return new Promise(resolve => {
          snipCanvas.toBlob(blob => resolve(blob), 'image/png');
        });
      }

      // 1. Copy Image Handler
      currentToolbar.querySelector('#scanext-snip-copy-img').addEventListener('click', async (evt) => {
        evt.stopPropagation();
        const btn = evt.currentTarget;
        btn.disabled = true;
        btn.textContent = 'Kopierer...';

        try {
          let blob = await getCanvasBlob();
          if (!blob) {
            // Fallback: capture tab if canvas was empty
            overlay.style.display = 'none';
            await new Promise(r => setTimeout(r, 60));
            const res = await chrome.runtime.sendMessage({ type: 'CAPTURE_FOR_SNIP' });
            overlay.style.display = 'block';
            if (res && res.dataUrl) {
              blob = await cropScreenshotBlob(res.dataUrl, finalRect);
            }
          }

          if (blob) {
            await navigator.clipboard.write([
              new ClipboardItem({ 'image/png': blob })
            ]);
            cleanup();
            showToast('Utsnitt kopiert til utklippstavlen! (Trykk Cmd+V / Ctrl+V)');
            return;
          }
          alert('Kunne ikke ta skjermbilde.');
        } catch (err) {
          console.error('Kopier bilde feilet:', err);
          alert('Feil ved kopiering av bilde: ' + err.message);
        } finally {
          cleanup();
        }
      });

      // 2. Copy Text Handler
      currentToolbar.querySelector('#scanext-snip-copy-txt').addEventListener('click', async (evt) => {
        evt.stopPropagation();
        try {
          const allNodes = getVisibleTextNodes();
          const insideNodes = allNodes.filter(n => {
            const midX = n.x + (n.w / 2);
            const midY = n.y + (n.h / 2);
            return midX >= finalRect.x - 5 && midX <= finalRect.x + finalRect.w + 5 &&
                   midY >= finalRect.y - 5 && midY <= finalRect.y + finalRect.h + 5;
          });

          if (insideNodes.length === 0) {
            showToast('Fant ingen tekst i det markerte utsnittet.', 'ℹ️');
            cleanup();
            return;
          }

          let textOutput = '';
          let prev = null;
          for (const curr of insideNodes) {
            const str = (curr.text || '').trim();
            if (!str) continue;
            if (!prev) {
              textOutput += str;
              prev = curr;
              continue;
            }
            const fs = curr.fontSize || prev.fontSize || 14;
            const yDiff = curr.y - prev.y;
            const isSameLine = Math.abs(yDiff) <= Math.max(5, fs * 0.48);

            if (isSameLine) {
              if (textOutput.endsWith('-') && !textOutput.endsWith(' -')) {
                textOutput = textOutput.slice(0, -1) + str;
              } else {
                textOutput += ' ' + str;
              }
            } else {
              if (yDiff > fs * 1.5 || yDiff < -fs) {
                textOutput += '\n\n' + str;
              } else {
                textOutput += '\n' + str;
              }
            }
            prev = curr;
          }

          const cleanText = textOutput.replace(/[ \t]+/g, ' ').replace(/\n{3,}/g, '\n\n').trim();
          await navigator.clipboard.writeText(cleanText);
          cleanup();
          showToast('Tekst i utsnittet er kopiert til utklippstavlen!');
        } catch (err) {
          console.error('Kopier tekst feilet:', err);
          cleanup();
        }
      });

      // 3. Download PNG Handler
      currentToolbar.querySelector('#scanext-snip-download').addEventListener('click', async (evt) => {
        evt.stopPropagation();
        try {
          let blob = await getCanvasBlob();
          if (!blob) {
            overlay.style.display = 'none';
            await new Promise(r => setTimeout(r, 60));
            const res = await chrome.runtime.sendMessage({ type: 'CAPTURE_FOR_SNIP' });
            overlay.style.display = 'block';
            if (res && res.dataUrl) {
              blob = await cropScreenshotBlob(res.dataUrl, finalRect);
            }
          }

          if (blob) {
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            const dateStr = new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-');
            a.download = `ScanExtension_Utsnitt_${dateStr}.png`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            cleanup();
            showToast('Utsnitt lastet ned som PNG!');
            return;
          }
        } catch (err) {
          console.error('Download feilet:', err);
        } finally {
          cleanup();
        }
      });

      // 4. Close Button Handler
      currentToolbar.querySelector('#scanext-snip-close').addEventListener('click', (evt) => {
        evt.stopPropagation();
        cleanup();
      });
    });

    (document.documentElement || document.body).appendChild(overlay);
  }

  const CONTENT_SCRIPT_VERSION = '1.4.0';

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'PING') {
      sendResponse({ pong: true, version: CONTENT_SCRIPT_VERSION });
      return false;
    }

    if (message.action === 'START_SNIPPER') {
      startSnippingTool();
      sendResponse({ success: true });
      return false;
    }

    if (message.action === 'START_DESKTOP_SNIPPER') {
      startDesktopSnippingTool();
      sendResponse({ success: true });
      return false;
    }

    if (message.action === 'EXTRACT_PAGE_TEXT') {
      const lines = getVisibleTextNodes();
      const bounds = getBookViewportBounds();
      sendResponse({ textNodes: lines, bookBounds: bounds });
      return false;
    }

    if (message.action === 'TRIGGER_NEXT_PAGE') {
      const result = triggerNextPage(
        message.navMode,
        message.scanMode,
        message.initialHeadings,
        message.targetHeading,
        message.currentCount
      );
      sendResponse(result);
      return false;
    }

    if (message.action === 'GET_HEADINGS') {
      const headings = getVisibleHeadings(true);
      sendResponse({ headings: headings });
      return false;
    }

    if (message.action === 'SET_SCAN_STATE') {
      if (message.status === 'scanning') {
        hideObstructingToolbars();
      } else {
        restoreToolbars();
      }
      sendResponse({ received: true });
      return false;
    }

    return false;
  });

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.scanState) {
      const st = changes.scanState.newValue;
      if (st && st.status === 'scanning') {
        hideObstructingToolbars();
      } else {
        restoreToolbars();
      }
    }
  });
})();
