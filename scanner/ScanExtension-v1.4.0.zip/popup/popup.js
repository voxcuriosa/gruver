document.addEventListener('DOMContentLoaded', () => {
  // 1. Grab all DOM Elements immediately
  const configForm = document.getElementById('config-form');
  const progressPanel = document.getElementById('progress-panel');
  const badgeStatus = document.getElementById('badge-status');

  const modeRadios = document.getElementsByName('scanMode');
  const groupTargetPages = document.getElementById('group-target-pages');
  const groupTargetHeading = document.getElementById('group-target-heading');
  const targetHeadingInput = document.getElementById('target-heading');

  const boxContinuous = document.getElementById('box-continuous');
  const boxSubchapter = document.getElementById('box-subchapter');
  const boxAutoChapter = document.getElementById('box-auto-chapter');

  const targetPagesInput = document.getElementById('target-pages');
  const pagesCalcHint = document.getElementById('pages-calc-hint');
  const btnPagesDec = document.getElementById('btn-pages-dec');
  const btnPagesInc = document.getElementById('btn-pages-inc');

  const navModeSelect = document.getElementById('nav-mode');
  const delaySlider = document.getElementById('delay-sec');
  const delayValue = document.getElementById('delay-value');
  const pdfQualitySelect = document.getElementById('pdf-quality');
  const pdfNameInput = document.getElementById('pdf-name');
  const previewBeforeSaveCheckbox = document.getElementById('preview-before-save');
  const autoDownloadTxtCheckbox = document.getElementById('auto-download-txt');

  const lastScanCard = document.getElementById('last-scan-card');
  const lastScanTitle = document.getElementById('last-scan-title');
  const btnCopyLastText = document.getElementById('btn-copy-last-text');
  const btnDownloadLastTxt = document.getElementById('btn-download-last-txt');

  const btnStart = document.getElementById('btn-start');
  const btnPause = document.getElementById('btn-pause');
  const btnFinishPdf = document.getElementById('btn-finish-pdf');
  const btnCancel = document.getElementById('btn-cancel');
  const btnOpenReview = document.getElementById('btn-open-review');
  const btnOpenSnipper = document.getElementById('btn-open-snipper');
  const btnOpenDesktopSnipper = document.getElementById('btn-open-desktop-snipper');

  const progressText = document.getElementById('progress-text');
  const progressPercent = document.getElementById('progress-percent');
  const progressBar = document.getElementById('progress-bar');

  const langBtnNo = document.getElementById('lang-no');
  const langBtnEn = document.getElementById('lang-en');

  // --- i18n Translations Dictionary ---
  const TRANSLATIONS = {
    no: {
      headerSubtitle: "Digital Bok & Dokument Skanner",
      btnSnipTab: "Fane",
      btnSnipDesktop: "Hele PC-en",
      statusIdle: "Klar",
      statusScanning: "Skanner",
      statusPaused: "Pauset",
      statusBuildingPdf: "Lager PDF...",
      btnStopAndSave: "STOPP & LAST NED PDF",
      btnPause: "Pause",
      btnResume: "Fortsett",
      btnCancel: "Forkast",
      btnReviewCaptures: "Se / Rediger opptak",
      labelPreviewBeforeSave: "Forhåndsvis og slett sider før PDF lagres",
      labelAutoDownloadTxt: "Last også ned .TXT-fil automatisk",
      lastScanLabel: "Siste skanning:",
      btnCopyLastText: "Kopier tekst",
      textCopied: "Kopiert!",
      labelScanMode: "Skannemodus",
      modeContinuousTitle: "Løpende",
      modeContinuousDesc: "Til du trykker stopp",
      modeSubchapterTitle: "Undertema",
      modeSubchapterDesc: "Stopp ved undertittel",
      modeAutoChapterTitle: "Helt kapittel",
      modeAutoChapterDesc: "Til bunnen av kapittelet",
      modeFixedPagesTitle: "Fast antall",
      modeFixedPagesDesc: "F.eks. 15 opptak",
      labelTargetHeading: "Stopp ved overskrift",
      hintTargetHeading: "f.eks. Livet som jegere",
      placeholderTargetHeading: "Skriv tittel på neste tema å stoppe ved",
      labelTargetPages: "Antall opptak",
      calcHint: "{n} opptak",
      infoContinuous: "Blar automatisk. Trykk <b>«STOPP & LAST NED PDF»</b> når ferdig.",
      infoSubchapter: "Stopper automatisk når neste store hovedtittel nås.",
      infoAutoChapter: "Ruller gjennom hele kapittelet til bunnen og lagrer PDF automatisk.",
      labelNavMode: "Boktype",
      navOptionAuto: "Auto-deteksjon",
      navOptionScroll: "Rulling (EPUB)",
      navOptionFlip: "Blaing (Oppslag)",
      labelDelay: "Ventetid per opptak",
      labelPdfQuality: "Kvalitet & Størrelse",
      qualityHigh: "💎 Maks (300 DPI)",
      qualityCompact: "⚡ Kompakt (150 DPI)",
      labelPdfName: "PDF Filnavn",
      placeholderPdfName: "Filnavn",
      btnStart: "Start Skanning",
      privacyLink: "Personvern",
      alertOpenTab: "Vennligst åpne boksiden i den aktive fanen før du starter.",
      confirmCancel: "Er du sikker på at du vil avbryte og forkaste opptaket?",
      buildingPdfWait: "Bygger PDF, vennligst vent...",
      progressScanText: "Opptak {current} av {target}",
      progressSubchapterText: "Opptak {current} (Undertema)",
      progressChapterText: "Opptak {current} (Helt kapittel)",
      progressContinuousText: "Opptak {current}",
      statusActive: "Aktiv",
      statusContinuous: "Løpende"
    },
    en: {
      headerSubtitle: "Digital E-Book & Document Scanner",
      btnSnipTab: "Tab",
      btnSnipDesktop: "Entire PC",
      statusIdle: "Ready",
      statusScanning: "Scanning",
      statusPaused: "Paused",
      statusBuildingPdf: "Building PDF...",
      btnStopAndSave: "STOP & DOWNLOAD PDF",
      btnPause: "Pause",
      btnResume: "Resume",
      btnCancel: "Discard",
      btnReviewCaptures: "View / Edit Captures",
      labelPreviewBeforeSave: "Preview and delete pages before saving PDF",
      labelAutoDownloadTxt: "Also download .TXT file automatically",
      lastScanLabel: "Last scan:",
      btnCopyLastText: "Copy Text",
      textCopied: "Copied!",
      labelScanMode: "Scanning Mode",
      modeContinuousTitle: "Continuous",
      modeContinuousDesc: "Until you press stop",
      modeSubchapterTitle: "Subchapter",
      modeSubchapterDesc: "Stops at next subsection",
      modeAutoChapterTitle: "Full Chapter",
      modeAutoChapterDesc: "Until end of chapter",
      modeFixedPagesTitle: "Fixed Count",
      modeFixedPagesDesc: "e.g. 15 captures",
      labelTargetHeading: "Stop at heading",
      hintTargetHeading: "e.g. Life as hunters",
      placeholderTargetHeading: "Enter heading text to stop at",
      labelTargetPages: "Number of captures",
      calcHint: "{n} captures",
      infoContinuous: "Automatically flips/scrolls. Press <b>\"STOP & DOWNLOAD PDF\"</b> when finished.",
      infoSubchapter: "Automatically stops when next major heading is reached.",
      infoAutoChapter: "Scrolls through entire chapter to bottom and generates PDF automatically.",
      labelNavMode: "Reader Type",
      navOptionAuto: "Auto-detection",
      navOptionScroll: "Scrolling (EPUB)",
      navOptionFlip: "Flipping (Spread)",
      labelDelay: "Delay per capture",
      labelPdfQuality: "Quality & Size",
      qualityHigh: "💎 Max (300 DPI)",
      qualityCompact: "⚡ Compact (150 DPI)",
      labelPdfName: "PDF Filename",
      placeholderPdfName: "Filename",
      btnStart: "Start Scanning",
      privacyLink: "Privacy",
      alertOpenTab: "Please navigate to the book tab in your active browser window before starting.",
      confirmCancel: "Are you sure you want to cancel and discard captures?",
      buildingPdfWait: "Building PDF, please wait...",
      progressScanText: "Capture {current} of {target}",
      progressSubchapterText: "Capture {current} (Subchapter)",
      progressChapterText: "Capture {current} (Full Chapter)",
      progressContinuousText: "Capture {current}",
      statusActive: "Active",
      statusContinuous: "Continuous"
    }
  };

  let currentLang = 'no';

  function applyLanguage(lang) {
    currentLang = lang;
    const t = TRANSLATIONS[lang] || TRANSLATIONS.no;

    if (lang === 'en') {
      if (langBtnEn) langBtnEn.classList.add('active');
      if (langBtnNo) langBtnNo.classList.remove('active');
    } else {
      if (langBtnNo) langBtnNo.classList.add('active');
      if (langBtnEn) langBtnEn.classList.remove('active');
    }

    document.querySelectorAll('[data-i18n]').forEach(el => {
      const key = el.getAttribute('data-i18n');
      if (t[key]) {
        el.innerHTML = t[key];
      }
    });

    document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
      const key = el.getAttribute('data-i18n-placeholder');
      if (t[key]) {
        el.placeholder = t[key];
      }
    });

    updateCalcHint();
    chrome.storage.local.set({ uiLang: lang });
  }

  function updateCalcHint() {
    const t = TRANSLATIONS[currentLang] || TRANSLATIONS.no;
    const count = parseInt(targetPagesInput?.value, 10) || 0;
    if (pagesCalcHint) {
      pagesCalcHint.textContent = t.calcHint.replace('{n}', count);
    }
  }

  // ==========================================
  // 2. ATTACH ALL EVENT LISTENERS SYNCHRONOUSLY FIRST!
  // ==========================================

  // Open Snipping Tool Button (Active Tab)
  if (btnOpenSnipper) {
    btnOpenSnipper.addEventListener('click', async (e) => {
      e.preventDefault();
      try {
        const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
        if (tab && tab.id) {
          try {
            await chrome.tabs.sendMessage(tab.id, { action: 'START_SNIPPER' });
          } catch (err) {
            await chrome.scripting.insertCSS({ target: { tabId: tab.id }, files: ['content/content.css'] });
            await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content/content.js'] });
            await chrome.tabs.sendMessage(tab.id, { action: 'START_SNIPPER' });
          }
        }
      } catch (err) {
        console.warn('ScanExtension: Tab snipper error:', err);
      }
      window.close();
    });
  }

  // Open Desktop / Multi-App Snipping Tool Button (Entire PC)
  if (btnOpenDesktopSnipper) {
    btnOpenDesktopSnipper.addEventListener('click', async (e) => {
      e.preventDefault();
      let stream = null;
      try {
        stream = await navigator.mediaDevices.getDisplayMedia({
          video: { cursor: 'never', displaySurface: 'monitor' },
          audio: false
        });
      } catch (err) {
        console.warn('Desktop capture cancelled:', err);
        return;
      }

      if (!stream) return;

      try {
        const video = document.createElement('video');
        video.srcObject = stream;
        await video.play();
        // Wait 650ms for share dialog to fade out completely
        await new Promise(r => setTimeout(r, 650));

        const canvas = document.createElement('canvas');
        canvas.width = video.videoWidth || window.screen.width;
        canvas.height = video.videoHeight || window.screen.height;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(video, 0, 0);

        stream.getTracks().forEach(t => t.stop());

        const dataUrl = canvas.toDataURL('image/png');
        await chrome.storage.local.set({ desktopCapture: dataUrl });
        await chrome.windows.create({
          url: chrome.runtime.getURL('editor/editor.html'),
          type: 'popup',
          state: 'fullscreen',
          focused: true
        });
      } catch (err) {
        console.warn('Frame capture error:', err);
        if (stream) stream.getTracks().forEach(t => t.stop());
      } finally {
        window.close();
      }
    });
  }

  if (langBtnNo) langBtnNo.addEventListener('click', () => applyLanguage('no'));
  if (langBtnEn) langBtnEn.addEventListener('click', () => applyLanguage('en'));

  if (btnOpenHelp) {
    btnOpenHelp.addEventListener('click', () => {
      chrome.tabs.create({ url: chrome.runtime.getURL('help/help.html') });
    });
  }

  if (btnCopyLastText) {
    btnCopyLastText.addEventListener('click', async () => {
      const t = TRANSLATIONS[currentLang] || TRANSLATIONS.no;
      const data = await chrome.storage.local.get('lastScanText');
      if (data && data.lastScanText) {
        await navigator.clipboard.writeText(data.lastScanText);
        const span = btnCopyLastText.querySelector('span');
        if (span) {
          const originalText = span.textContent;
          span.textContent = t.textCopied;
          setTimeout(() => {
            span.textContent = originalText;
          }, 1800);
        }
      }
    });
  }

  if (btnDownloadLastTxt) {
    btnDownloadLastTxt.addEventListener('click', async () => {
      const data = await chrome.storage.local.get(['lastScanText', 'lastScanFilename']);
      if (data && data.lastScanText) {
        const blob = new Blob([data.lastScanText], { type: 'text/plain;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        const cleanName = (data.lastScanFilename || 'Bok_Skann').replace(/\.pdf$/i, '');
        a.download = `${cleanName}.txt`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      }
    });
  }

  modeRadios.forEach(radio => {
    radio.addEventListener('change', updateModeUI);
  });

  function updateModeUI() {
    const mode = document.querySelector('input[name="scanMode"]:checked')?.value || 'continuous';

    if (boxContinuous) boxContinuous.classList.add('hidden');
    if (boxSubchapter) boxSubchapter.classList.add('hidden');
    if (boxAutoChapter) boxAutoChapter.classList.add('hidden');
    if (groupTargetPages) groupTargetPages.classList.add('hidden');
    if (groupTargetHeading) groupTargetHeading.classList.add('hidden');

    if (mode === 'continuous' && boxContinuous) {
      boxContinuous.classList.remove('hidden');
    } else if (mode === 'subchapter') {
      if (boxSubchapter) boxSubchapter.classList.remove('hidden');
      if (groupTargetHeading) groupTargetHeading.classList.remove('hidden');
    } else if (mode === 'auto_chapter' && boxAutoChapter) {
      boxAutoChapter.classList.remove('hidden');
    } else if (mode === 'chapter' && groupTargetPages) {
      groupTargetPages.classList.remove('hidden');
    }
  }

  if (btnPagesDec) {
    btnPagesDec.addEventListener('click', () => {
      let val = parseInt(targetPagesInput.value, 10) || 1;
      if (val > 1) {
        targetPagesInput.value = val - 1;
        updateCalcHint();
      }
    });
  }

  if (btnPagesInc) {
    btnPagesInc.addEventListener('click', () => {
      let val = parseInt(targetPagesInput.value, 10) || 1;
      if (val < 500) {
        targetPagesInput.value = val + 1;
        updateCalcHint();
      }
    });
  }

  if (targetPagesInput) targetPagesInput.addEventListener('input', updateCalcHint);

  if (delaySlider && delayValue) {
    delaySlider.addEventListener('input', () => {
      delayValue.textContent = parseFloat(delaySlider.value).toFixed(1) + 's';
    });
  }

  if (previewBeforeSaveCheckbox) {
    previewBeforeSaveCheckbox.addEventListener('change', () => {
      chrome.storage.local.set({ previewBeforeSave: previewBeforeSaveCheckbox.checked });
    });
  }

  if (autoDownloadTxtCheckbox) {
    autoDownloadTxtCheckbox.addEventListener('change', () => {
      chrome.storage.local.set({ autoDownloadTxt: autoDownloadTxtCheckbox.checked });
    });
  }

  if (pdfQualitySelect) {
    pdfQualitySelect.addEventListener('change', () => {
      chrome.storage.local.set({ pdfQuality: pdfQualitySelect.value });
    });
  }

  async function handleStartScan(e) {
    if (e) e.preventDefault();
    const t = TRANSLATIONS[currentLang] || TRANSLATIONS.no;

    let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.id) {
      [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    }
    if (!tab || !tab.id) {
      alert(t.alertOpenTab);
      return;
    }

    const selectedMode = document.querySelector('input[name="scanMode"]:checked')?.value || 'continuous';
    const navMode = navModeSelect ? navModeSelect.value : 'auto';
    const targetPages = targetPagesInput ? parseInt(targetPagesInput.value, 10) || 15 : 15;
    const targetHeading = targetHeadingInput ? targetHeadingInput.value.trim() : '';
    const delayMs = delaySlider ? Math.round(parseFloat(delaySlider.value) * 1000) : 1200;
    const pdfFilename = (pdfNameInput && pdfNameInput.value.trim()) || (currentLang === 'en' ? 'Book_Scan' : 'Bok_Skann');
    const previewBeforeSave = previewBeforeSaveCheckbox ? previewBeforeSaveCheckbox.checked : false;
    const autoDownloadTxt = autoDownloadTxtCheckbox ? autoDownloadTxtCheckbox.checked : false;
    const quality = pdfQualitySelect ? pdfQualitySelect.value : 'high';

    await chrome.runtime.sendMessage({
      type: 'START_SCAN',
      config: {
        tabId: tab.id,
        windowId: tab.windowId,
        mode: selectedMode,
        navMode: navMode,
        targetPages: targetPages,
        targetHeading: targetHeading,
        delayMs: delayMs,
        pdfFilename: pdfFilename,
        previewBeforeSave: previewBeforeSave,
        autoDownloadTxt: autoDownloadTxt,
        quality: quality
      }
    });
  }

  if (configForm) configForm.addEventListener('submit', handleStartScan);
  if (btnStart) btnStart.addEventListener('click', handleStartScan);

  if (btnOpenReview) {
    btnOpenReview.addEventListener('click', async () => {
      await chrome.runtime.sendMessage({ type: 'OPEN_REVIEW_PAGE' });
    });
  }

  if (btnPause) {
    btnPause.addEventListener('click', async () => {
      await chrome.runtime.sendMessage({ type: 'SCAN_TOGGLE_PAUSE' });
    });
  }

  if (btnFinishPdf) {
    btnFinishPdf.addEventListener('click', async () => {
      const t = TRANSLATIONS[currentLang] || TRANSLATIONS.no;
      if (previewBeforeSaveCheckbox && previewBeforeSaveCheckbox.checked) {
        await chrome.runtime.sendMessage({ type: 'OPEN_REVIEW_PAGE' });
      } else {
        btnFinishPdf.disabled = true;
        btnFinishPdf.textContent = t.statusBuildingPdf;
        await chrome.runtime.sendMessage({
          type: 'SCAN_FINISH_PDF',
          quality: pdfQualitySelect ? pdfQualitySelect.value : 'high'
        });
      }
    });
  }

  if (btnCancel) {
    btnCancel.addEventListener('click', async () => {
      const t = TRANSLATIONS[currentLang] || TRANSLATIONS.no;
      if (confirm(t.confirmCancel)) {
        await chrome.runtime.sendMessage({ type: 'CANCEL_SCAN' });
      }
    });
  }

  // ==========================================
  // 3. ASYNC STATE AND STORAGE INITIALIZATION
  // ==========================================
  async function checkLastScanMemory() {
    try {
      const data = await chrome.storage.local.get(['lastScanText', 'lastScanFilename']);
      if (data && data.lastScanText && data.lastScanText.trim().length > 0) {
        if (lastScanTitle) lastScanTitle.textContent = (data.lastScanFilename || 'Bok_Skann').replace(/\.pdf$/i, '');
        if (lastScanCard) lastScanCard.classList.remove('hidden');
      } else {
        if (lastScanCard) lastScanCard.classList.add('hidden');
      }
    } catch (e) {}
  }

  function renderState(state) {
    const t = TRANSLATIONS[currentLang] || TRANSLATIONS.no;
    if (!state || !state.active) {
      if (configForm) configForm.classList.remove('hidden');
      if (progressPanel) progressPanel.classList.add('hidden');
      if (badgeStatus) {
        badgeStatus.className = 'status-pill idle';
        badgeStatus.textContent = t.statusIdle;
      }
      checkLastScanMemory();
      return;
    }

    if (configForm) configForm.classList.add('hidden');
    if (lastScanCard) lastScanCard.classList.add('hidden');
    if (progressPanel) progressPanel.classList.remove('hidden');

    if (state.status === 'paused') {
      if (badgeStatus) {
        badgeStatus.className = 'status-pill paused';
        badgeStatus.textContent = t.statusPaused;
      }
      if (btnPause) {
        btnPause.textContent = t.btnResume;
        btnPause.classList.add('btn-primary');
      }
    } else if (state.status === 'generating_pdf') {
      if (badgeStatus) {
        badgeStatus.className = 'status-pill pdf';
        badgeStatus.textContent = 'PDF...';
      }
      if (btnFinishPdf) {
        btnFinishPdf.disabled = true;
        btnFinishPdf.textContent = t.buildingPdfWait;
      }
    } else {
      if (badgeStatus) {
        badgeStatus.className = 'status-pill scanning';
        badgeStatus.textContent = t.statusScanning;
      }
      if (btnPause) {
        btnPause.textContent = t.btnPause;
        btnPause.classList.remove('btn-primary');
      }
    }

    const current = state.currentCount || 0;
    const target = state.targetCount || 0;

    if (progressText && progressPercent && progressBar) {
      if (state.mode === 'chapter' && target > 0) {
        const pct = Math.min(100, Math.round((current / target) * 100));
        progressText.textContent = t.progressScanText.replace('{current}', current).replace('{target}', target);
        progressPercent.textContent = `${pct}%`;
        progressBar.style.width = `${pct}%`;
      } else if (state.mode === 'subchapter') {
        progressText.textContent = t.progressSubchapterText.replace('{current}', current);
        progressPercent.textContent = t.statusActive;
        progressBar.style.width = '100%';
      } else if (state.mode === 'auto_chapter') {
        progressText.textContent = t.progressChapterText.replace('{current}', current);
        progressPercent.textContent = t.statusActive;
        progressBar.style.width = '100%';
      } else {
        progressText.textContent = t.progressContinuousText.replace('{current}', current);
        progressPercent.textContent = t.statusContinuous;
        progressBar.style.width = '100%';
      }
    }
  }

  // Real-time Storage Listener
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local') {
      if (changes.scanState) {
        renderState(changes.scanState.newValue);
      }
      if (changes.lastScanText) {
        checkLastScanMemory();
      }
    }
  });

  // Run Async Initializer
  (async function initAsync() {
    try {
      const storedLang = await chrome.storage.local.get('uiLang');
      if (storedLang && storedLang.uiLang) {
        applyLanguage(storedLang.uiLang);
      } else {
        const navLang = (navigator.language || 'no').toLowerCase();
        if (navLang.startsWith('no') || navLang.startsWith('nb') || navLang.startsWith('nn')) {
          applyLanguage('no');
        } else {
          applyLanguage('en');
        }
      }
    } catch (e) {}

    await checkLastScanMemory();

    try {
      const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
      if (tab && tab.title && pdfNameInput) {
        const sanitized = tab.title
          .replace(/[/\\?%*:|"<>]/g, '_')
          .replace(/\s+/g, '_')
          .substring(0, 30);
        if (sanitized && pdfNameInput.value === 'Bok_Skann') {
          pdfNameInput.value = sanitized;
        }
      }
    } catch (e) {}

    try {
      const storedConfig = await chrome.storage.local.get([
        'scanMode',
        'navMode',
        'delaySec',
        'previewBeforeSave',
        'autoDownloadTxt',
        'pdfQuality'
      ]);

      if (storedConfig.scanMode) {
        const radio = document.querySelector(`input[name="scanMode"][value="${storedConfig.scanMode}"]`);
        if (radio) radio.checked = true;
      }
      if (storedConfig.navMode && navModeSelect) {
        navModeSelect.value = storedConfig.navMode;
      }
      if (storedConfig.delaySec && delaySlider && delayValue) {
        delaySlider.value = storedConfig.delaySec;
        delayValue.textContent = parseFloat(storedConfig.delaySec).toFixed(1) + 's';
      }
      if (storedConfig.previewBeforeSave !== undefined && previewBeforeSaveCheckbox) {
        previewBeforeSaveCheckbox.checked = storedConfig.previewBeforeSave;
      }
      if (storedConfig.autoDownloadTxt !== undefined && autoDownloadTxtCheckbox) {
        autoDownloadTxtCheckbox.checked = storedConfig.autoDownloadTxt;
      }
      if (storedConfig.pdfQuality && pdfQualitySelect) {
        pdfQualitySelect.value = storedConfig.pdfQuality;
      }
    } catch (e) {}

    try {
      const storageData = await chrome.storage.local.get('scanState');
      if (storageData && storageData.scanState) {
        renderState(storageData.scanState);
      }
    } catch (e) {}

    updateModeUI();
    updateCalcHint();
  })();
});
