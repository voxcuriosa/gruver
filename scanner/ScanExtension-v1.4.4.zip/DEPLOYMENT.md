# Automatisk Publisering til Chrome Web Store med GitHub Actions

Denne guiden viser hvordan du setter opp engangs-nøklene fra Google slik at hver gang du lager en ny tag (f.eks. `v1.4.0`) på GitHub, vil GitHub Actions automatisk bygge zip-filen og laste den opp direkte til Chrome Web Store!

---

## 🔑 Nødvendige Secrets i GitHub Repository

Gå til GitHub-repoet ditt ➡️ **Settings** ➡️ **Secrets and variables** ➡️ **Actions** ➡️ **New repository secret**:

| Secret Navn | Forklaring | Standard / Eksempel |
|---|---|---|
| `CHROME_EXTENSION_ID` | Utvidelsens ID i Chrome Web Store | `fgcpdieiiammegcpfdjkhkdggfjoimll` |
| `CHROME_CLIENT_ID` | OAuth2 Client ID fra Google Cloud | `xxxxxx.apps.googleusercontent.com` |
| `CHROME_CLIENT_SECRET` | OAuth2 Client Secret fra Google Cloud | `GOCSPX-xxxxxx` |
| `CHROME_REFRESH_TOKEN` | OAuth2 Refresh Token med Web Store tilgang | `1//04xxxxxx...` |

---

## 🛠️ Steg-for-steg: Hvordan hente Google API-nøklene (Engangsoppsett)

### Steg 1: Aktiver Chrome Web Store API i Google Cloud Console
1. Gå til [Google Cloud Console](https://console.cloud.google.com/).
2. Velg eller opprett et prosjekt (f.eks. `ScanExtension-Deploy`).
3. Gå til **APIs & Services** ➡️ **Library**.
4. Søk etter **Chrome Web Store API** og trykk **Enable (Aktiver)**.

### Steg 2: Opprett OAuth2 Credentials (Client ID & Secret)
1. Gå til **APIs & Services** ➡️ **OAuth consent screen**.
2. Velg **External** og fyll inn Appnavn (`ScanExtension`) og e-postadressen din (`borchgrevink@gmail.com`).
3. Under **Test users**, legg til din egen Google-konto (den du bruker for Chrome Web Store Developer Dashboard).
4. Gå deretter til **APIs & Services** ➡️ **Credentials**.
5. Trykk **+ CREATE CREDENTIALS** ➡️ **OAuth client ID**.
6. Velg **Application type: Web application**.
7. Under **Authorized redirect URIs**, legg til:
   `https://developers.google.com/oauthplayground`
8. Trykk **Create**.
9. Kopier **Client ID** og **Client Secret** (dette er `CHROME_CLIENT_ID` og `CHROME_CLIENT_SECRET`).

### Steg 3: Hent Refresh Token via OAuth2 Playground
1. Åpne [Google OAuth 2.0 Playground](https://developers.google.com/oauthplayground).
2. Trykk på **Tannhjulet ⚙️** oppe til høyre:
   - Huk av for **Use your own OAuth credentials**.
   - Lim inn **OAuth Client ID** og **OAuth Client Secret** fra Steg 2.
3. I venstremenyen under **Step 1 (Select & authorize APIs)**, finn tekstfeltet nederst: *«Input your own scopes»*.
4. Lim inn dette skopet og trykk **Authorize APIs**:
   `https://www.googleapis.com/auth/chromewebstore`
5. Logg inn med Google-kontoen som eier utvidelsen i Chrome Web Store.
6. Trykk **Exchange authorization code for tokens** under **Step 2**.
7. Kopier verdien i **Refresh token**-feltet (dette er `CHROME_REFRESH_TOKEN`).

### Steg 4: Legg inn nøklene på GitHub
1. Gå til repoet: `https://github.com/voxcuriosa/ScanExtension/settings/secrets/actions`
2. Legg til de 4 secrets:
   - `CHROME_EXTENSION_ID`: `fgcpdieiiammegcpfdjkhkdggfjoimll`
   - `CHROME_CLIENT_ID`
   - `CHROME_CLIENT_SECRET`
   - `CHROME_REFRESH_TOKEN`

---

## 🚀 Hvordan publisere nye versjoner heretter:

Når nøklene er lagt inn, er det **superenkelt** å rulle ut nye versjoner:

1. Endre versjonsnummer i `manifest.json` (f.eks. til `1.4.1`).
2. Kjør:
   ```bash
   git add .
   git commit -m "Release v1.4.1"
   git tag v1.4.1
   git push origin main --tags
   ```
3. GitHub Actions vil da automatisk:
   - Pakke extension-koden som `.zip`
   - Laste opp og publisere direkte til Chrome Web Store!
   - Lage en offisiell GitHub Release med zip-filen tilgjengelig for nedlasting!
