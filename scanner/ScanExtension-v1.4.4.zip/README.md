# ScanExtension - Bok & PDF Skanner (Chrome Extension MV3)

En moderne Chrome-utvidelse bygget med Manifest V3 for automatisk blaing, høyoppløselig bildeopptak og direkte generering av samlede, søkbare PDF-dokumenter fra nettbaserte e-bøker og lesere.

## Funksjoner
- 📖 **Kapittelmodus**: Sett et bestemt antall sider (f.eks. 20 sider til neste kapittel), så stopper den automatisk og laster ned PDF.
- ⚡ **Løpende modus**: Skann så mange sider du vil og trykk "Fullfør PDF" når du er klar.
- ⏱ **Justerbar forsinkelse**: Sett ventetid per side (f.eks. 1.2–2.0 sek) slik at vektorer og høyoppløselige bilder rekker å laste ferdig.
- 🖨 **Automatisk PDF-generering**: Setter sammen alle sidene i originaloppløsning og laster ned en ferdig `.pdf`-fil med søkbart tekstlag.
- 🎯 **Usynlig tekstlag (Searchable PDF)**: Teksten kan markeres, kopieres og søkes i med Cmd+F.
- 🔒 **100% Lokalt**: Ingen data sendes til eksterne servere.

## Installasjon i Chrome (Utviklermodus)

1. Åpne Google Chrome og naviger til:
   ```text
   chrome://extensions
   ```
2. Skru på **«Utviklermodus»** (**Developer mode**) øverst til høyre.
3. Klikk på **«Last inn uemballert»** (**Load unpacked**) øverst til venstre.
4. Velg mappen `ScanExtension` (eller den utpakkede mappen fra ZIP-filen).
5. Åpne e-boken din i nettleseren, klikk på utvidelsesikonet i verktøylinjen, velg innstillinger og trykk **«Start Skanning»**!

## Struktur
```
ScanExtension/
├── manifest.json              # Manifest V3 konfigurasjon
├── popup/
│   ├── popup.html             # Popup brukergrensesnitt
│   ├── popup.css              # Styling
│   └── popup.js               # Kontrollogikk og synkronisering
├── background/
│   └── service-worker.js      # Hovedmotor for opptak og PDF-bygging
├── content/
│   ├── content.js             # Boksidestyring (piltast/knapp-triggere)
│   └── content.css            # Svevende statusbanner på boksiden
├── lib/
│   └── jspdf.umd.min.js       # PDF-motor
├── icons/                     # Utvidelsesikoner (16x16, 48x48, 128x128)
├── CHROMEWEBSTORE.md          # Info og tillatelser for publisering
└── README.md
```
