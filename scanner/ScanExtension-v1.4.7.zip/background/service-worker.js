// Background Service Worker for ScanExtension

// Resilient IndexedDB & In-Memory Fallback Storage Engine
const ScanDB = {
  dbInstance: null,
  memoryFallback: [],

  async getDB() {
    if (this.dbInstance) return this.dbInstance;
    return new Promise((resolve, reject) => {
      if (typeof indexedDB === 'undefined') {
        return reject(new Error('IndexedDB not supported'));
      }
      const req = indexedDB.open('ScanExtensionDB', 1);
      req.onupgradeneeded = (e) => {
        const db = e.target.result;
        if (!db.objectStoreNames.contains('session_pages')) {
          db.createObjectStore('session_pages', { keyPath: 'id', autoIncrement: true });
        }
      };
      req.onsuccess = (e) => {
        this.dbInstance = e.target.result;
        this.dbInstance.onversionchange = () => {
          this.dbInstance.close();
          this.dbInstance = null;
        };
        resolve(this.dbInstance);
      };
      req.onerror = (e) => reject(e.target.error);
      req.onblocked = () => {
        console.warn('ScanExtension: IndexedDB open blocked');
        resolve(null);
      };
    });
  },

  async clearSession() {
    this.memoryFallback = [];
    try {
      const db = await this.getDB();
      if (!db) return true;
      return new Promise((resolve) => {
        const tx = db.transaction('session_pages', 'readwrite');
        const store = tx.objectStore('session_pages');
        const req = store.clear();
        req.onsuccess = () => resolve(true);
        req.onerror = () => resolve(false);
      });
    } catch (e) {
      console.warn('ScanExtension: Clear DB fallback to memory', e);
      return true;
    }
  },

  async addPage(pageRecord) {
    try {
      const db = await this.getDB();
      if (db) {
        return new Promise((resolve, reject) => {
          const tx = db.transaction('session_pages', 'readwrite');
          const store = tx.objectStore('session_pages');
          const req = store.add({
            image: pageRecord.image,
            textNodes: pageRecord.textNodes || [],
            bookBounds: pageRecord.bookBounds || null,
            timestamp: Date.now()
          });
          req.onsuccess = (e) => resolve(e.target.result);
          req.onerror = (e) => reject(e.target.error);
        });
      }
    } catch (e) {
      console.warn('ScanExtension: addPage fallback to memory', e);
    }
    const id = this.memoryFallback.length + 1;
    this.memoryFallback.push({
      id: id,
      image: pageRecord.image,
      textNodes: pageRecord.textNodes || [],
      bookBounds: pageRecord.bookBounds || null,
      timestamp: Date.now()
    });
    return id;
  },

  async getPage(id) {
    try {
      const db = await this.getDB();
      if (db) {
        return new Promise((resolve, reject) => {
          const tx = db.transaction('session_pages', 'readonly');
          const store = tx.objectStore('session_pages');
          const req = store.get(id);
          req.onsuccess = (e) => resolve(e.target.result || null);
          req.onerror = (e) => reject(e.target.error);
        });
      }
    } catch (e) {}
    return this.memoryFallback.find(p => p.id === id) || null;
  },

  async getAllPageSummaries() {
    try {
      const db = await this.getDB();
      if (db) {
        return new Promise((resolve, reject) => {
          const tx = db.transaction('session_pages', 'readonly');
          const store = tx.objectStore('session_pages');
          const summaries = [];
          const req = store.openCursor();
          req.onsuccess = (e) => {
            const cursor = e.target.result;
            if (cursor) {
              summaries.push({
                id: cursor.key,
                textNodes: cursor.value.textNodes || [],
                bookBounds: cursor.value.bookBounds || null,
                timestamp: cursor.value.timestamp
              });
              cursor.continue();
            } else {
              resolve(summaries);
            }
          };
          req.onerror = (e) => reject(e.target.error);
        });
      }
    } catch (e) {}
    return this.memoryFallback.map(p => ({
      id: p.id,
      textNodes: p.textNodes || [],
      bookBounds: p.bookBounds || null,
      timestamp: p.timestamp
    }));
  },

  async getAllPages() {
    try {
      const db = await this.getDB();
      if (db) {
        return new Promise((resolve, reject) => {
          const tx = db.transaction('session_pages', 'readonly');
          const store = tx.objectStore('session_pages');
          const req = store.getAll();
          req.onsuccess = (e) => resolve(e.target.result || []);
          req.onerror = (e) => reject(e.target.error);
        });
      }
    } catch (e) {}
    return [...this.memoryFallback];
  },

  async deletePage(id) {
    try {
      const db = await this.getDB();
      if (db) {
        return new Promise((resolve) => {
          const tx = db.transaction('session_pages', 'readwrite');
          const store = tx.objectStore('session_pages');
          const req = store.delete(id);
          req.onsuccess = () => resolve(true);
          req.onerror = () => resolve(false);
        });
      }
    } catch (e) {}
    this.memoryFallback = this.memoryFallback.filter(p => p.id !== id);
    return true;
  },

  async getCount() {
    try {
      const db = await this.getDB();
      if (db) {
        return new Promise((resolve, reject) => {
          const tx = db.transaction('session_pages', 'readonly');
          const store = tx.objectStore('session_pages');
          const req = store.count();
          req.onsuccess = (e) => resolve(e.target.result);
          req.onerror = (e) => reject(e.target.error);
        });
      }
    } catch (e) {}
    return this.memoryFallback.length;
  }
};

let scanSession = {
  active: false,
  status: 'idle',
  mode: 'continuous',
  navMode: 'auto',
  tabId: null,
  windowId: null,
  currentCount: 0,
  targetCount: 0,
  targetHeading: '',
  delayMs: 2000,
  pdfFilename: 'Bok_Skann.pdf',
  previewBeforeSave: false,
  autoDownloadTxt: false,
  quality: 'compact',
  lastFrameSig: null,
  initialHeadings: [],
  lastPageCropBottomY: null,
  lastPageCropAction: null
};

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

function reconstructPageLines(nodes) {
  if (!nodes || nodes.length === 0) return [];
  const lines = [];
  let currentLine = '';
  let prev = null;

  for (const curr of nodes) {
    const str = (curr.text || '').trim();
    if (!str) continue;

    if (!prev) {
      currentLine = str;
      prev = curr;
      continue;
    }

    const fs = curr.fontSize || prev.fontSize || 14;
    const yDiff = curr.y - prev.y;

    if (currentLine.endsWith('-') && !currentLine.endsWith(' -') && !currentLine.endsWith('--')) {
      currentLine = currentLine.slice(0, -1) + str;
    } else if (yDiff > fs * 1.5 || yDiff < -fs) {
      if (currentLine.trim()) lines.push(currentLine.trim());
      currentLine = '\n' + str;
    } else {
      if (currentLine.trim()) lines.push(currentLine.trim());
      currentLine = str;
    }
    prev = curr;
  }
  if (currentLine.trim()) lines.push(currentLine.trim());
  return lines;
}

function normalizeStr(s) {
  return (s || '').toLowerCase().replace(/[^a-z0-9æøåáéíóú]/gi, '');
}

// Deduplicate sequential overlapping lines across scroll captures
function deduplicatePageLines(allPagesLines) {
  const deduplicatedPages = [];
  let accumulatedAllLines = [];

  for (let pIdx = 0; pIdx < allPagesLines.length; pIdx++) {
    let pageLines = [...allPagesLines[pIdx]];

    if (pIdx > 0 && accumulatedAllLines.length > 0 && pageLines.length > 0) {
      const tail = accumulatedAllLines.slice(-35);
      let bestOverlapCount = 0;

      for (let k = Math.min(pageLines.length, tail.length); k >= 1; k--) {
        let isMatch = true;
        for (let j = 0; j < k; j++) {
          const tailLine = normalizeStr(tail[tail.length - k + j]);
          const currLine = normalizeStr(pageLines[j]);
          if (!tailLine || !currLine || tailLine !== currLine) {
            isMatch = false;
            break;
          }
        }

        if (isMatch) {
          if (k === 1) {
            const sample = normalizeStr(pageLines[0]);
            if (sample.length >= 10) {
              bestOverlapCount = k;
              break;
            }
          } else {
            bestOverlapCount = k;
            break;
          }
        }
      }

      if (bestOverlapCount > 0) {
        pageLines = pageLines.slice(bestOverlapCount);
      }
    }

    deduplicatedPages.push(pageLines);
    accumulatedAllLines.push(...pageLines);
  }

  return deduplicatedPages;
}

function buildCleanExportText(pages) {
  if (!pages || pages.length === 0) return '';
  const rawPagesLines = pages.map(p => reconstructPageLines(p.textNodes));
  const cleanPagesLines = deduplicatePageLines(rawPagesLines);

  let combinedText = '';
  cleanPagesLines.forEach((lines, idx) => {
    const pageContent = lines.join('\n').replace(/\n{3,}/g, '\n\n').trim();
    if (pageContent) {
      combinedText += `=== OPPTAK / SIDE ${idx + 1} ===\n\n`;
      combinedText += pageContent + '\n\n';
    }
  });

  return combinedText.trim();
}

async function updateStoredState() {
  const safeState = {
    active: scanSession.active,
    status: scanSession.status,
    mode: scanSession.mode,
    navMode: scanSession.navMode,
    tabId: scanSession.tabId,
    currentCount: scanSession.currentCount,
    targetCount: scanSession.targetCount,
    targetHeading: scanSession.targetHeading,
    delayMs: scanSession.delayMs,
    pdfFilename: scanSession.pdfFilename,
    pageCount: scanSession.pages.length
  };
  await chrome.storage.local.set({ scanState: safeState });

  if (scanSession.status === 'scanning') {
    await chrome.action.setBadgeText({ text: String(scanSession.currentCount) });
    await chrome.action.setBadgeBackgroundColor({ color: '#4F46E5' });
  } else if (scanSession.status === 'paused') {
    await chrome.action.setBadgeText({ text: '⏸' });
    await chrome.action.setBadgeBackgroundColor({ color: '#F59E0B' });
  } else if (scanSession.status === 'generating_pdf') {
    await chrome.action.setBadgeText({ text: 'PDF' });
    await chrome.action.setBadgeBackgroundColor({ color: '#10B981' });
  } else {
    await chrome.action.setBadgeText({ text: '' });
  }
}

async function captureCurrentTab() {
  try {
    let dataUrl = null;
    try {
      dataUrl = await chrome.tabs.captureVisibleTab(scanSession.windowId, { format: 'png' });
    } catch (winErr) {
      dataUrl = await chrome.tabs.captureVisibleTab(null, { format: 'png' });
    }

    if (dataUrl) {
      // Duplicate frame detection (e.g. End of Book reached or page failed to flip)
      const currentSig = dataUrl.length + '_' + dataUrl.slice(0, 1000);
      if (scanSession.lastFrameSig && scanSession.lastFrameSig === currentSig) {
        console.log('Duplikat fanget (siste side i boken nådd).');
        return 'duplicate';
      }
      scanSession.lastFrameSig = currentSig;

      let textNodes = [];
      let bookBounds = null;
      try {
        const textRes = await chrome.tabs.sendMessage(scanSession.tabId, { action: 'EXTRACT_PAGE_TEXT' });
        if (textRes) {
          if (textRes.textNodes) textNodes = textRes.textNodes;
          if (textRes.bookBounds) bookBounds = textRes.bookBounds;
        }
      } catch (e) {}

      await ScanDB.addPage({
        image: dataUrl,
        textNodes: textNodes,
        bookBounds: bookBounds
      });
      scanSession.currentCount = await ScanDB.getCount();
      await updateStoredState();
      return true;
    }
  } catch (err) {
    console.error('Failed to capture tab screenshot:', err);
  }
  return false;
}

const CURRENT_VERSION = '1.4.7';

// Ensure content script is active and matches current version (re-injects dynamically if outdated)
async function ensureContentScriptInjected(tabId) {
  try {
    const res = await chrome.tabs.sendMessage(tabId, { action: 'PING' });
    if (res && res.pong && res.version === CURRENT_VERSION) {
      return true;
    }
  } catch (err) {}

  console.log('Injecting updated content script into tab:', tabId);
  try {
    await chrome.scripting.insertCSS({
      target: { tabId: tabId },
      files: ['content/content.css']
    }).catch(() => {});
    await chrome.scripting.executeScript({
      target: { tabId: tabId },
      files: ['content/content.js']
    });
    await sleep(150);
    return true;
  } catch (injectErr) {
    console.error('Failed to inject content script:', injectErr);
  }
  return false;
}

async function startScan(config) {
  let tab = null;
  if (config.tabId) {
    try {
      tab = await chrome.tabs.get(config.tabId);
    } catch (e) {}
  }

  scanSession = {
    active: true,
    status: 'scanning',
    mode: config.mode || 'continuous',
    navMode: config.navMode || 'auto',
    tabId: config.tabId,
    windowId: (tab && tab.windowId) ? tab.windowId : config.windowId,
    currentCount: 0,
    targetCount: config.mode === 'chapter' ? parseInt(config.targetPages, 10) : 0,
    targetHeading: config.targetHeading || '',
    delayMs: Math.max(500, parseInt(config.delayMs, 10) || 1200),
    pdfFilename: config.pdfFilename || 'Bok_Skann.pdf',
    previewBeforeSave: config.previewBeforeSave || false,
    autoDownloadTxt: config.autoDownloadTxt || false,
    quality: config.quality || 'compact',
    lastFrameSig: null,
    initialHeadings: [],
    lastPageCropBottomY: null,
    lastPageCropAction: null
  };

  // 1. Immediately switch stored state so popup and badge show active scanning
  await updateStoredState();

  // 2. Clear database storage safely
  try {
    await ScanDB.clearSession();
  } catch (dbErr) {
    console.warn('ScanExtension: Could not clear previous session DB:', dbErr);
  }

  // 3. Ensure content script is injected
  try {
    await ensureContentScriptInjected(config.tabId);
  } catch (injectErr) {
    console.warn('ScanExtension: Content script injection warning:', injectErr);
  }

  // 4. Retrieve initial headings if supported
  try {
    const res = await chrome.tabs.sendMessage(scanSession.tabId, { action: 'GET_HEADINGS' });
    if (res && res.headings) {
      scanSession.initialHeadings = res.headings;
    }
  } catch (e) {}

  // 5. Start scanning loop
  runScanLoop();
}

async function openReviewPage() {
  scanSession.status = 'paused';
  await updateStoredState();
  await chrome.tabs.create({ url: chrome.runtime.getURL('review/review.html') });
}

async function runScanLoop() {
  while (scanSession.active && scanSession.status === 'scanning') {
    await sleep(scanSession.delayMs);

    if (!scanSession.active || scanSession.status !== 'scanning') break;

    const capRes = await captureCurrentTab();
    if (capRes === 'duplicate') {
      console.log('Duplikat fanget. Siste side i boken er nådd.');
      if (scanSession.previewBeforeSave) {
        await openReviewPage();
      } else {
        await finishAndGeneratePDF();
      }
      break;
    }

    if (scanSession.mode === 'chapter' && scanSession.targetCount > 0 && scanSession.currentCount >= scanSession.targetCount) {
      if (scanSession.previewBeforeSave) {
        await openReviewPage();
      } else {
        await finishAndGeneratePDF();
      }
      break;
    }

    try {
      const res = await chrome.tabs.sendMessage(scanSession.tabId, {
        action: 'TRIGGER_NEXT_PAGE',
        navMode: scanSession.navMode,
        scanMode: scanSession.mode,
        initialHeadings: scanSession.initialHeadings,
        targetHeading: scanSession.targetHeading,
        currentCount: scanSession.currentCount
      });

      if (res && (res.method === 'subchapter_finished' || res.method === 'chapter_finished')) {
        console.log('Skanning ferdig! Ny overskrift nådd:', res.reachedHeading, 'Handling:', res.cropAction);
        if (res.cropBottomY) {
          scanSession.lastPageCropBottomY = res.cropBottomY;
        }
        if (res.cropAction) {
          scanSession.lastPageCropAction = res.cropAction;
        }

        if (scanSession.previewBeforeSave) {
          await openReviewPage();
        } else {
          await finishAndGeneratePDF();
        }
        break;
      }

      if (res && res.atBottom && (scanSession.mode === 'auto_chapter' || scanSession.mode === 'subchapter')) {
        console.log('Nådde bunnen av kapittelet. Tar siste opptak av bunnen...');
        await sleep(scanSession.delayMs);
        await captureCurrentTab();
        if (scanSession.previewBeforeSave) {
          await openReviewPage();
        } else {
          await finishAndGeneratePDF();
        }
        break;
      }
    } catch (e) {
      console.warn('Could not trigger navigation on tab:', e);
    }
  }
}

// Compile captured images to PDF via Stream Pipeline (1 page at a time to prevent OOM)
async function finishAndGeneratePDF() {
  const summaries = await ScanDB.getAllPageSummaries();
  if (summaries.length === 0) {
    scanSession.status = 'idle';
    scanSession.active = false;
    await updateStoredState();
    return;
  }

  scanSession.status = 'generating_pdf';
  await updateStoredState();

  try {
    let tabId = scanSession.tabId;
    try {
      const t = await chrome.tabs.get(tabId);
      if (!t) tabId = null;
    } catch (e) {
      tabId = null;
    }
    if (!tabId) {
      const [activeTab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
      if (activeTab) tabId = activeTab.id;
    }
    if (!tabId) {
      throw new Error('No active browser tab found to render PDF');
    }

    const isVerticalScroll = scanSession.navMode === 'scroll' || scanSession.navMode === 'auto';
    const lastCropY = scanSession.lastPageCropBottomY;
    const lastCropAction = scanSession.lastPageCropAction;
    const filename = scanSession.pdfFilename.endsWith('.pdf')
      ? scanSession.pdfFilename
      : `${scanSession.pdfFilename}.pdf`;
    const pdfQuality = scanSession.quality || 'compact';

    // Extract and store clean text in memory / local storage for last scan
    try {
      const exportedText = buildCleanExportText(summaries);
      if (exportedText) {
        await chrome.storage.local.set({
          lastScanText: exportedText,
          lastScanFilename: scanSession.pdfFilename || 'Bok_Skann',
          lastScanTimestamp: Date.now()
        });

        if (scanSession.autoDownloadTxt) {
          const txtFilename = (scanSession.pdfFilename || 'Bok_Skann').replace(/\.pdf$/i, '') + '.txt';
          await chrome.scripting.executeScript({
            target: { tabId: tabId },
            func: (textContent, downloadName) => {
              const blob = new Blob([textContent], { type: 'text/plain;charset=utf-8' });
              const url = URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = downloadName;
              document.body.appendChild(a);
              a.click();
              document.body.removeChild(a);
              URL.revokeObjectURL(url);
            },
            args: [exportedText, txtFilename]
          });
        }
      }
    } catch (txtErr) {
      console.warn('Could not extract text during PDF finish:', txtErr);
    }

    // Handle 2-page spread chapter boundary: If the new chapter started on the left page, drop the last spread
    if (lastCropAction === 'discard_last_spread' && summaries.length > 1) {
      console.log('Dropper siste opptak fordi nytt kapittel startet på venstre side');
      const dropped = summaries.pop();
      if (dropped && dropped.id) {
        await ScanDB.deletePage(dropped.id);
      }
    }

    const keepLeftHalfOnlyOnLast = (lastCropAction === 'keep_left_half_only');

    // Ensure content script and jsPDF are loaded in the tab
    await ensureContentScriptInjected(tabId);
    await chrome.scripting.executeScript({
      target: { tabId: tabId },
      files: ['lib/jspdf.umd.min.js']
    });

    // Start stream on tab
    await chrome.tabs.sendMessage(tabId, {
      action: 'START_PDF_STREAM',
      outputFilename: filename,
      isVertical: isVerticalScroll,
      lastPageCropY: lastCropY,
      keepLeftHalf: keepLeftHalfOnlyOnLast,
      qualityMode: pdfQuality,
      totalCount: summaries.length
    });

    // Stream pages one-by-one from IndexedDB into the tab
    for (let i = 0; i < summaries.length; i++) {
      const pageRecord = await ScanDB.getPage(summaries[i].id);
      if (!pageRecord) continue;
      const isLast = (i === summaries.length - 1);

      await chrome.tabs.sendMessage(tabId, {
        action: 'STREAM_PDF_PAGE',
        pageIndex: i,
        isLast: isLast,
        page: {
          image: pageRecord.image,
          textNodes: summaries[i].textNodes || [],
          bookBounds: summaries[i].bookBounds || null
        }
      });
    }

    // Finalize PDF stream (triggers doc.save)
    await chrome.tabs.sendMessage(tabId, {
      action: 'FINISH_PDF_STREAM',
      outputFilename: filename
    });

  } catch (err) {
    console.error('Error generating PDF via stream:', err);
  } finally {
    await ScanDB.clearSession();
    scanSession.status = 'idle';
    scanSession.active = false;
    scanSession.currentCount = 0;
    scanSession.lastPageCropBottomY = null;
    scanSession.lastPageCropAction = null;
    scanSession.lastFrameSig = null;
    await updateStoredState();
  }
}

async function cancelScan() {
  scanSession.active = false;
  scanSession.status = 'idle';
  scanSession.currentCount = 0;
  scanSession.lastPageCropBottomY = null;
  scanSession.lastPageCropAction = null;
  scanSession.lastFrameSig = null;
  await ScanDB.clearSession();
  await updateStoredState();
}

async function togglePause() {
  if (scanSession.status === 'scanning') {
    scanSession.status = 'paused';
    await updateStoredState();
  } else if (scanSession.status === 'paused') {
    scanSession.status = 'scanning';
    await updateStoredState();
    runScanLoop();
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    switch (message.type) {
      case 'START_SCAN':
        await startScan(message.config);
        sendResponse({ success: true });
        break;

      case 'SCAN_TOGGLE_PAUSE':
        await togglePause();
        sendResponse({ success: true, status: scanSession.status });
        break;

      case 'OPEN_REVIEW_PAGE':
        await openReviewPage();
        sendResponse({ success: true });
        break;

      case 'GET_SESSION_PAGES': {
        const pages = await ScanDB.getAllPages();
        sendResponse({
          pages: pages,
          count: pages.length,
          pdfFilename: scanSession.pdfFilename
        });
        break;
      }

      case 'DELETE_PAGE_FROM_SESSION': {
        if (typeof message.id === 'number') {
          await ScanDB.deletePage(message.id);
        } else if (typeof message.index === 'number') {
          const summaries = await ScanDB.getAllPageSummaries();
          if (summaries[message.index]) {
            await ScanDB.deletePage(summaries[message.index].id);
          }
        }
        const updatedCount = await ScanDB.getCount();
        scanSession.currentCount = updatedCount;
        await updateStoredState();
        sendResponse({
          success: true,
          count: updatedCount
        });
        break;
      }

      case 'EXPORT_ALL_TEXT': {
        const summaries = await ScanDB.getAllPageSummaries();
        const text = buildCleanExportText(summaries);
        sendResponse({ success: true, text: text });
        break;
      }

      case 'GET_LAST_SCAN_TEXT': {
        const data = await chrome.storage.local.get(['lastScanText', 'lastScanFilename', 'lastScanTimestamp']);
        sendResponse({
          success: true,
          text: data.lastScanText || '',
          filename: data.lastScanFilename || 'Bok_Skann',
          timestamp: data.lastScanTimestamp || 0
        });
        break;
      }

      case 'SET_PDF_QUALITY':
        if (message.quality) {
          scanSession.quality = message.quality;
          chrome.storage.local.set({ pdfQuality: message.quality });
        }
        sendResponse({ success: true });
        break;

      case 'SCAN_FINISH_PDF':
        if (message.quality) {
          scanSession.quality = message.quality;
        }
        await finishAndGeneratePDF();
        sendResponse({ success: true });
        break;

      case 'CANCEL_SCAN':
        await cancelScan();
        sendResponse({ success: true });
        break;

      case 'CAPTURE_FOR_SNIP': {
        try {
          const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
          const winId = tab ? tab.windowId : undefined;
          const dataUrl = await chrome.tabs.captureVisibleTab(winId, { format: 'png' });
          sendResponse({ success: true, dataUrl: dataUrl });
        } catch (e) {
          sendResponse({ error: e.message });
        }
        break;
      }

      case 'START_SNIPPER_FROM_POPUP': {
        let targetTabId = message.tabId;
        if (!targetTabId) {
          const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
          if (tab) targetTabId = tab.id;
        }
        sendResponse({ success: true });
        if (targetTabId) {
          triggerSnippingTool(targetTabId);
        }
        break;
      }

      case 'START_DESKTOP_SNIPPER_FROM_POPUP': {
        let targetTabId = message.tabId;
        if (!targetTabId) {
          const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
          if (tab) targetTabId = tab.id;
        }
        sendResponse({ success: true });
        if (targetTabId) {
          triggerDesktopSnippingTool(targetTabId);
        }
        break;
      }

      case 'OPEN_DESKTOP_EDITOR': {
        chrome.windows.create({
          url: chrome.runtime.getURL('editor/editor.html'),
          type: 'popup',
          state: 'fullscreen',
          focused: true
        });
        sendResponse({ success: true });
        break;
      }

      case 'GET_SCAN_STATUS':
        sendResponse({
          active: scanSession.active,
          status: scanSession.status,
          mode: scanSession.mode,
          navMode: scanSession.navMode,
          currentCount: scanSession.currentCount,
          targetCount: scanSession.targetCount,
          targetHeading: scanSession.targetHeading,
          delayMs: scanSession.delayMs,
          pdfFilename: scanSession.pdfFilename,
          quality: scanSession.quality,
          pageCount: scanSession.pages.length
        });
        break;

      default:
        sendResponse({ error: 'Unknown message type' });
    }
  })();
  return true;
});

async function triggerSnippingTool(tabId) {
  try {
    await chrome.tabs.sendMessage(tabId, { action: 'START_SNIPPER' });
  } catch (err) {
    try {
      await ensureContentScriptInjected(tabId);
      await chrome.tabs.sendMessage(tabId, { action: 'START_SNIPPER' });
    } catch (e) {
      console.warn('ScanExtension: Failed to launch snipping tool:', e);
    }
  }
}

async function triggerDesktopSnippingTool(tabId) {
  try {
    await chrome.tabs.sendMessage(tabId, { action: 'START_DESKTOP_SNIPPER' });
  } catch (err) {
    try {
      await ensureContentScriptInjected(tabId);
      await chrome.tabs.sendMessage(tabId, { action: 'START_DESKTOP_SNIPPER' });
    } catch (e) {
      console.warn('ScanExtension: Failed to launch desktop snipper:', e);
    }
  }
}

// Global Keyboard Shortcut Commands Listener
chrome.commands.onCommand.addListener(async (command) => {
  console.log('Tastatursnarvei trigget:', command);

  if (command === 'snipping_tool') {
    const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    if (tab && tab.id) {
      await triggerSnippingTool(tab.id);
    }
  } else if (command === 'desktop_snipping_tool') {
    const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    if (tab && tab.id) {
      await triggerDesktopSnippingTool(tab.id);
    }
  } else if (command === 'start_stop_scan') {
    if (scanSession.active && (scanSession.status === 'scanning' || scanSession.status === 'paused')) {
      if (scanSession.previewBeforeSave) {
        await openReviewPage();
      } else {
        await finishAndGeneratePDF();
      }
    } else {
      const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
      if (tab && tab.id) {
        const stored = await chrome.storage.local.get(['previewBeforeSave', 'autoDownloadTxt', 'pdfQuality']);
        await startScan({
          tabId: tab.id,
          windowId: tab.windowId,
          mode: 'auto_chapter',
          navMode: 'auto',
          delayMs: 2000,
          previewBeforeSave: stored.previewBeforeSave || false,
          autoDownloadTxt: stored.autoDownloadTxt || false,
          quality: stored.pdfQuality || 'high',
          pdfFilename: 'Bok_Skann'
        });
      }
    }
  } else if (command === 'toggle_pause_scan') {
    if (scanSession.active) {
      await togglePause();
    }
  } else if (command === 'open_gallery') {
    await openReviewPage();
  }
});
