#!/bin/bash
set -e

# 1. Read current version from manifest.json
VERSION=$(node -p "require('./manifest.json').version")
echo "=========================================="
echo "🚀 Deploying ScanExtension v$VERSION"
echo "=========================================="

# 2. Syntax Validation
echo "🔍 Validating syntax..."
node --check popup/popup.js
node --check content/content.js
node --check background/service-worker.js
node --check editor/editor.js
node --check review/review.js
node --check lib/storage.js

# 3. Git commit & tag push (Triggers GitHub Actions -> Chrome Web Store)
echo "📦 Pushing to GitHub & triggering Chrome Web Store deployment..."
git add .
git commit -m "Deploy v$VERSION" || true
git tag -f "v$VERSION"
git push origin main
git push origin "v$VERSION" --force

# 4. Package Extension ZIPs
echo "🗜️ Packaging ZIP files..."
zip -r ../ScanExtension-v$VERSION.zip . -x "*.git*"
cp ../ScanExtension-v$VERSION.zip ../ScanExtension.zip
cp ../ScanExtension-v$VERSION.zip ../vox_portal/scanner/ScanExtension-v$VERSION.zip
cp ../ScanExtension-v$VERSION.zip ../vox_portal/scanner/ScanExtension.zip

# 4b. Update website download links and version badge
echo "📝 Updating vox_portal/scanner/index.html to v$VERSION..."
node -e '
  const fs = require("fs");
  const ver = process.argv[1];
  const file = "../vox_portal/scanner/index.html";
  if (fs.existsSync(file)) {
    let content = fs.readFileSync(file, "utf8");
    content = content.replace(/v[0-9]+\.[0-9]+\.[0-9]+/g, "v" + ver);
    content = content.replace(/ScanExtension-v[0-9]+\.[0-9]+\.[0-9]+\.zip/g, "ScanExtension-v" + ver + ".zip");
    fs.writeFileSync(file, content, "utf8");
    console.log("✅ Updated index.html with v" + ver);
  }
' "$VERSION"

# 5. Upload to voxcuriosa.no via FTP
echo "🌐 Uploading to voxcuriosa.no via FTP..."
cd ../vox_portal
python3 upload_ftp.py scanner/ scanner/

# 6. Push vox_portal repository
echo "💾 Syncing vox_portal repository..."
git add .
git commit -m "Sync ScanExtension v$VERSION release" || true
git push origin feature/animert-laering || true

echo "=========================================="
echo "✅ SUCCESS! v$VERSION packaged & deployed to:"
echo "   1. voxcuriosa.no (via FTP)"
echo "   2. GitHub Releases & Repositories"
echo "   📦 ZIP ready for Chrome Web Store: ../ScanExtension-v$VERSION.zip"
echo "=========================================="
