document.addEventListener('DOMContentLoaded', async () => {
  // DOM Elements
  const configForm = document.getElementById('config-form');
  const progressPanel = document.getElementById('progress-panel');
  const badgeStatus = document.getElementById('badge-status');

  const modeRadios = document.getElementsByName('scanMode');
  const groupTargetPages = document.getElementById('group-target-pages');
  const groupTargetHeading = document.getElementById('group-target-heading');
  const targetHeadingInput = document.getElementById('target-heading');

  const boxContinuous = document.getElementById('box-continuous');
  const boxSubchapter = document.getElementById('box-subchapter');
  const boxAutoChapter = document.getElementById('box-auto-chapter');

  const targetPagesInput = document.getElementById('target-pages');
  const pagesCalcHint = document.getElementById('pages-calc-hint');
  const btnPagesDec = document.getElementById('btn-pages-dec');
  const btnPagesInc = document.getElementById('btn-pages-inc');

  const navModeSelect = document.getElementById('nav-mode');
  const delaySlider = document.getElementById('delay-sec');
  const delayValue = document.getElementById('delay-value');
  const pdfQualitySelect = document.getElementById('pdf-quality');
  const pdfNameInput = document.getElementById('pdf-name');
  const previewBeforeSaveCheckbox = document.getElementById('preview-before-save');
  const autoDownloadTxtCheckbox = document.getElementById('auto-download-txt');

  const lastScanCard = document.getElementById('last-scan-card');
  const lastScanTitle = document.getElementById('last-scan-title');
  const btnCopyLastText = document.getElementById('btn-copy-last-text');
  const btnDownloadLastTxt = document.getElementById('btn-download-last-txt');

  const btnStart = document.getElementById('btn-start');
  const btnPause = document.getElementById('btn-pause');
  const btnFinishPdf = document.getElementById('btn-finish-pdf');
  const btnCancel = document.getElementById('btn-cancel');
  const btnOpenReview = document.getElementById('btn-open-review');
  const btnOpenSnipper = document.getElementById('btn-open-snipper');
  const btnOpenDesktopSnipper = document.getElementById('btn-open-desktop-snipper');

  const progressText = document.getElementById('progress-text');
  const progressPercent = document.getElementById('progress-percent');
  const progressBar = document.getElementById('progress-bar');

  const langBtnNo = document.getElementById('lang-no');
  const langBtnEn = document.getElementById('lang-en');

  // --- i18n Translations Dictionary ---
  const TRANSLATIONS = {
    no: {
      headerSubtitle: "Digital Bok & Dokument Skanner",
      btnSnipTab: "Fane",
      btnSnipDesktop: "Hele PC-en",
      statusIdle: "Klar",
      statusScanning: "Skanner",
      statusPaused: "Pauset",
      statusBuildingPdf: "Lager PDF...",
      btnStopAndSave: "STOPP & LAST NED PDF",
      btnPause: "Pause",
      btnResume: "Fortsett",
      btnCancel: "Forkast",
      btnReviewCaptures: "Se / Rediger opptak",
      labelPreviewBeforeSave: "Forhåndsvis og slett sider før PDF lagres",
      labelAutoDownloadTxt: "Last også ned .TXT-fil automatisk",
      lastScanLabel: "Siste skanning:",
      btnCopyLastText: "Kopier tekst",
      textCopied: "Kopiert!",
      labelScanMode: "Skannemodus",
      modeContinuousTitle: "Løpende",
      modeContinuousDesc: "Til du trykker stopp",
      modeSubchapterTitle: "Undertema",
      modeSubchapterDesc: "Stopp ved undertittel",
      modeAutoChapterTitle: "Helt kapittel",
      modeAutoChapterDesc: "Til bunnen av kapittelet",
      modeFixedPagesTitle: "Fast antall",
      modeFixedPagesDesc: "F.eks. 15 opptak",
      labelTargetHeading: "Stopp ved overskrift",
      hintTargetHeading: "f.eks. Livet som jegere",
      placeholderTargetHeading: "Skriv tittel på neste tema å stoppe ved",
      labelTargetPages: "Antall opptak",
      calcHint: "{n} opptak",
      infoContinuous: "Blar automatisk. Trykk <b>«STOPP & LAST NED PDF»</b> når ferdig.",
      infoSubchapter: "Stopper automatisk når neste store hovedtittel nås.",
      infoAutoChapter: "Ruller gjennom hele kapittelet til bunnen og lagrer PDF automatisk.",
      labelNavMode: "Boktype",
      navOptionAuto: "Auto-deteksjon",
      navOptionScroll: "Rulling (EPUB)",
      navOptionFlip: "Blaing (Oppslag)",
      labelDelay: "Ventetid per opptak",
      labelPdfQuality: "Kvalitet & Størrelse",
      qualityHigh: "💎 Maks (300 DPI)",
      qualityCompact: "⚡ Kompakt (150 DPI)",
      labelPdfName: "PDF Filnavn",
      placeholderPdfName: "Filnavn",
      btnStart: "Start Skanning",
      privacyLink: "Personvern",
      alertOpenTab: "Vennligst åpne boksiden i den aktive fanen før du starter.",
      confirmCancel: "Er du sikker på at du vil avbryte og forkaste opptaket?",
      buildingPdfWait: "Bygger PDF, vennligst vent...",
      progressScanText: "Opptak {current} av {target}",
      progressSubchapterText: "Opptak {current} (Undertema)",
      progressChapterText: "Opptak {current} (Helt kapittel)",
      progressContinuousText: "Opptak {current}",
      statusActive: "Aktiv",
      statusContinuous: "Løpende"
    },
    en: {
      headerSubtitle: "Digital E-Book & Document Scanner",
      btnSnipTab: "Tab",
      btnSnipDesktop: "Entire PC",
      statusIdle: "Ready",
      statusScanning: "Scanning",
      statusPaused: "Paused",
      statusBuildingPdf: "Building PDF...",
      btnStopAndSave: "STOP & DOWNLOAD PDF",
      btnPause: "Pause",
      btnResume: "Resume",
      btnCancel: "Discard",
      btnReviewCaptures: "View / Edit Captures",
      labelPreviewBeforeSave: "Preview and delete pages before saving PDF",
      labelAutoDownloadTxt: "Also download .TXT file automatically",
      lastScanLabel: "Last scan:",
      btnCopyLastText: "Copy Text",
      textCopied: "Copied!",
      labelScanMode: "Scanning Mode",
      modeContinuousTitle: "Continuous",
      modeContinuousDesc: "Until you press stop",
      modeSubchapterTitle: "Subchapter",
      modeSubchapterDesc: "Stops at next subsection",
      modeAutoChapterTitle: "Full Chapter",
      modeAutoChapterDesc: "Until end of chapter",
      modeFixedPagesTitle: "Fixed Count",
      modeFixedPagesDesc: "e.g. 15 captures",
      labelTargetHeading: "Stop at heading",
      hintTargetHeading: "e.g. Life as hunters",
      placeholderTargetHeading: "Enter heading text to stop at",
      labelTargetPages: "Number of captures",
      calcHint: "{n} captures",
      infoContinuous: "Automatically flips/scrolls. Press <b>\"STOP & DOWNLOAD PDF\"</b> when finished.",
      infoSubchapter: "Automatically stops when next major heading is reached.",
      infoAutoChapter: "Scrolls through entire chapter to bottom and generates PDF automatically.",
      labelNavMode: "Reader Type",
      navOptionAuto: "Auto-detection",
      navOptionScroll: "Scrolling (EPUB)",
      navOptionFlip: "Flipping (Spread)",
      labelDelay: "Delay per capture",
      labelPdfQuality: "Quality & Size",
      qualityHigh: "💎 Max (300 DPI)",
      qualityCompact: "⚡ Compact (150 DPI)",
      labelPdfName: "PDF Filename",
      placeholderPdfName: "Filename",
      btnStart: "Start Scanning",
      privacyLink: "Privacy",
      alertOpenTab: "Please navigate to the book tab in your active browser window before starting.",
      confirmCancel: "Are you sure you want to cancel and discard captures?",
      buildingPdfWait: "Building PDF, please wait...",
      progressScanText: "Capture {current} of {target}",
      progressSubchapterText: "Capture {current} (Subchapter)",
      progressChapterText: "Capture {current} (Full Chapter)",
      progressContinuousText: "Capture {current}",
      statusActive: "Active",
      statusContinuous: "Continuous"
    }
  };

  let currentLang = 'no';

  function applyLanguage(lang) {
    currentLang = lang;
    const t = TRANSLATIONS[lang] || TRANSLATIONS.no;

    if (lang === 'en') {
      langBtnEn.classList.add('active');
      langBtnNo.classList.remove('active');
    } else {
      langBtnNo.classList.add('active');
      langBtnEn.classList.remove('active');
    }

    document.querySelectorAll('[data-i18n]').forEach(el => {
      const key = el.getAttribute('data-i18n');
      if (t[key]) {
        el.innerHTML = t[key];
      }
    });

    document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
      const key = el.getAttribute('data-i18n-placeholder');
      if (t[key]) {
        el.placeholder = t[key];
      }
    });

    updateCalcHint();
    chrome.storage.local.set({ uiLang: lang });
  }

  langBtnNo.addEventListener('click', () => applyLanguage('no'));
  langBtnEn.addEventListener('click', () => applyLanguage('en'));

  // Load language preference
  const storedLang = await chrome.storage.local.get('uiLang');
  if (storedLang && storedLang.uiLang) {
    applyLanguage(storedLang.uiLang);
  } else {
    const navLang = (navigator.language || 'no').toLowerCase();
    if (navLang.startsWith('no') || navLang.startsWith('nb') || navLang.startsWith('nn')) {
      applyLanguage('no');
    } else {
      applyLanguage('en');
    }
  }

  // Load Last Scan Text Memory
  async function checkLastScanMemory() {
    const data = await chrome.storage.local.get(['lastScanText', 'lastScanFilename']);
    if (data && data.lastScanText && data.lastScanText.trim().length > 0) {
      lastScanTitle.textContent = (data.lastScanFilename || 'Bok_Skann').replace(/\.pdf$/i, '');
      lastScanCard.classList.remove('hidden');
    } else {
      lastScanCard.classList.add('hidden');
    }
  }
  await checkLastScanMemory();

  // Copy Last Text Click
  btnCopyLastText.addEventListener('click', async () => {
    const t = TRANSLATIONS[currentLang] || TRANSLATIONS.no;
    const data = await chrome.storage.local.get('lastScanText');
    if (data && data.lastScanText) {
      await navigator.clipboard.writeText(data.lastScanText);
      const span = btnCopyLastText.querySelector('span');
      const originalText = span.textContent;
      span.textContent = t.textCopied;
      setTimeout(() => {
        span.textContent = originalText;
      }, 1800);
    }
  });

  // Download Last TXT Click
  btnDownloadLastTxt.addEventListener('click', async () => {
    const data = await chrome.storage.local.get(['lastScanText', 'lastScanFilename']);
    if (data && data.lastScanText) {
      const blob = new Blob([data.lastScanText], { type: 'text/plain;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      const cleanName = (data.lastScanFilename || 'Bok_Skann').replace(/\.pdf$/i, '');
      a.download = `${cleanName}.txt`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }
  });

  // Open Help Button
  btnOpenHelp.addEventListener('click', () => {
    chrome.tabs.create({ url: chrome.runtime.getURL('help/help.html') });
  });

  // Open Snipping Tool Button (Active Tab)
  btnOpenSnipper.addEventListener('click', async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    chrome.runtime.sendMessage({ type: 'START_SNIPPER_FROM_POPUP', tabId: tab?.id });
    window.close();
  });

  // Open Desktop / Multi-App Snipping Tool Button (Entire PC)
  btnOpenDesktopSnipper.addEventListener('click', async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    chrome.runtime.sendMessage({ type: 'START_DESKTOP_SNIPPER_FROM_POPUP', tabId: tab?.id });
    window.close();
  });

  // Mode Selection Changes
  modeRadios.forEach(radio => {
    radio.addEventListener('change', updateModeUI);
  });

  function updateModeUI() {
    const mode = document.querySelector('input[name="scanMode"]:checked')?.value || 'continuous';

    boxContinuous.classList.add('hidden');
    boxSubchapter.classList.add('hidden');
    boxAutoChapter.classList.add('hidden');
    groupTargetPages.classList.add('hidden');
    groupTargetHeading.classList.add('hidden');

    if (mode === 'continuous') {
      boxContinuous.classList.remove('hidden');
    } else if (mode === 'subchapter') {
      boxSubchapter.classList.remove('hidden');
      groupTargetHeading.classList.remove('hidden');
    } else if (mode === 'auto_chapter') {
      boxAutoChapter.classList.remove('hidden');
    } else if (mode === 'chapter') {
      groupTargetPages.classList.remove('hidden');
    }
  }

  // Stepper Controls
  btnPagesDec.addEventListener('click', () => {
    let val = parseInt(targetPagesInput.value, 10) || 1;
    if (val > 1) {
      targetPagesInput.value = val - 1;
      updateCalcHint();
    }
  });

  btnPagesInc.addEventListener('click', () => {
    let val = parseInt(targetPagesInput.value, 10) || 1;
    if (val < 500) {
      targetPagesInput.value = val + 1;
      updateCalcHint();
    }
  });

  targetPagesInput.addEventListener('input', updateCalcHint);

  function updateCalcHint() {
    const t = TRANSLATIONS[currentLang] || TRANSLATIONS.no;
    const count = parseInt(targetPagesInput.value, 10) || 0;
    pagesCalcHint.textContent = t.calcHint.replace('{n}', count);
  }

  // Slider Delay Live Text Update
  delaySlider.addEventListener('input', () => {
    delayValue.textContent = parseFloat(delaySlider.value).toFixed(1) + 's';
  });

  // Auto-detect page title on launch
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab && tab.title) {
      const sanitized = tab.title
        .replace(/[/\\?%*:|"<>]/g, '_')
        .replace(/\s+/g, '_')
        .substring(0, 30);
      if (sanitized && pdfNameInput.value === 'Bok_Skann') {
        pdfNameInput.value = sanitized;
      }
    }
  } catch (err) {}

  // Load Saved Preferences
  const storedConfig = await chrome.storage.local.get([
    'scanMode',
    'navMode',
    'delaySec',
    'previewBeforeSave',
    'autoDownloadTxt',
    'pdfQuality'
  ]);

  if (storedConfig.scanMode) {
    const radio = document.querySelector(`input[name="scanMode"][value="${storedConfig.scanMode}"]`);
    if (radio) radio.checked = true;
  }
  if (storedConfig.navMode) {
    navModeSelect.value = storedConfig.navMode;
  }
  if (storedConfig.delaySec) {
    delaySlider.value = storedConfig.delaySec;
    delayValue.textContent = parseFloat(storedConfig.delaySec).toFixed(1) + 's';
  }
  if (storedConfig.previewBeforeSave !== undefined) {
    previewBeforeSaveCheckbox.checked = storedConfig.previewBeforeSave;
  }
  if (storedConfig.autoDownloadTxt !== undefined) {
    autoDownloadTxtCheckbox.checked = storedConfig.autoDownloadTxt;
  }
  if (storedConfig.pdfQuality) {
    pdfQualitySelect.value = storedConfig.pdfQuality;
  }

  // Save changes to storage
  previewBeforeSaveCheckbox.addEventListener('change', () => {
    chrome.storage.local.set({ previewBeforeSave: previewBeforeSaveCheckbox.checked });
  });

  autoDownloadTxtCheckbox.addEventListener('change', () => {
    chrome.storage.local.set({ autoDownloadTxt: autoDownloadTxtCheckbox.checked });
  });

  pdfQualitySelect.addEventListener('change', () => {
    chrome.storage.local.set({ pdfQuality: pdfQualitySelect.value });
  });

  // Render State
  function renderState(state) {
    const t = TRANSLATIONS[currentLang] || TRANSLATIONS.no;
    if (!state || !state.active) {
      configForm.classList.remove('hidden');
      progressPanel.classList.add('hidden');
      badgeStatus.className = 'status-pill idle';
      badgeStatus.textContent = t.statusIdle;
      checkLastScanMemory();
      return;
    }

    configForm.classList.add('hidden');
    lastScanCard.classList.add('hidden');
    progressPanel.classList.remove('hidden');

    if (state.status === 'paused') {
      badgeStatus.className = 'status-pill paused';
      badgeStatus.textContent = t.statusPaused;
      btnPause.textContent = t.btnResume;
      btnPause.classList.add('btn-primary');
    } else if (state.status === 'generating_pdf') {
      badgeStatus.className = 'status-pill pdf';
      badgeStatus.textContent = 'PDF...';
      btnFinishPdf.disabled = true;
      btnFinishPdf.textContent = t.buildingPdfWait;
    } else {
      badgeStatus.className = 'status-pill scanning';
      badgeStatus.textContent = t.statusScanning;
      btnPause.textContent = t.btnPause;
      btnPause.classList.remove('btn-primary');
    }

    const current = state.currentCount || 0;
    const target = state.targetCount || 0;

    if (state.mode === 'chapter' && target > 0) {
      const pct = Math.min(100, Math.round((current / target) * 100));
      progressText.textContent = t.progressScanText.replace('{current}', current).replace('{target}', target);
      progressPercent.textContent = `${pct}%`;
      progressBar.style.width = `${pct}%`;
    } else if (state.mode === 'subchapter') {
      progressText.textContent = t.progressSubchapterText.replace('{current}', current);
      progressPercent.textContent = t.statusActive;
      progressBar.style.width = '100%';
    } else if (state.mode === 'auto_chapter') {
      progressText.textContent = t.progressChapterText.replace('{current}', current);
      progressPercent.textContent = t.statusActive;
      progressBar.style.width = '100%';
    } else {
      progressText.textContent = t.progressContinuousText.replace('{current}', current);
      progressPercent.textContent = t.statusContinuous;
      progressBar.style.width = '100%';
    }
  }

  // Initial Sync from Storage
  const storageData = await chrome.storage.local.get('scanState');
  if (storageData && storageData.scanState) {
    renderState(storageData.scanState);
  }

  // Real-time Storage Listener
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local') {
      if (changes.scanState) {
        renderState(changes.scanState.newValue);
      }
      if (changes.lastScanText) {
        checkLastScanMemory();
      }
    }
  });

  // Start Button Click
  configForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const t = TRANSLATIONS[currentLang] || TRANSLATIONS.no;

    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.id) {
      alert(t.alertOpenTab);
      return;
    }

    const selectedMode = document.querySelector('input[name="scanMode"]:checked')?.value || 'continuous';
    const navMode = navModeSelect.value || 'auto';
    const targetPages = parseInt(targetPagesInput.value, 10) || 15;
    const targetHeading = targetHeadingInput.value.trim();
    const delayMs = Math.round(parseFloat(delaySlider.value) * 1000);
    const pdfFilename = pdfNameInput.value.trim() || (currentLang === 'en' ? 'Book_Scan' : 'Bok_Skann');
    const previewBeforeSave = previewBeforeSaveCheckbox.checked;
    const autoDownloadTxt = autoDownloadTxtCheckbox.checked;
    const quality = pdfQualitySelect.value || 'high';

    await chrome.runtime.sendMessage({
      type: 'START_SCAN',
      config: {
        tabId: tab.id,
        windowId: tab.windowId,
        mode: selectedMode,
        navMode: navMode,
        targetPages: targetPages,
        targetHeading: targetHeading,
        delayMs: delayMs,
        pdfFilename: pdfFilename,
        previewBeforeSave: previewBeforeSave,
        autoDownloadTxt: autoDownloadTxt,
        quality: quality
      }
    });
  });

  // Open Review Gallery Button
  btnOpenReview.addEventListener('click', async () => {
    await chrome.runtime.sendMessage({ type: 'OPEN_REVIEW_PAGE' });
  });

  // Pause / Resume Button
  btnPause.addEventListener('click', async () => {
    await chrome.runtime.sendMessage({ type: 'SCAN_TOGGLE_PAUSE' });
  });

  // Finish & Generate PDF Button
  btnFinishPdf.addEventListener('click', async () => {
    const t = TRANSLATIONS[currentLang] || TRANSLATIONS.no;
    
    if (previewBeforeSaveCheckbox.checked) {
      await chrome.runtime.sendMessage({ type: 'OPEN_REVIEW_PAGE' });
    } else {
      btnFinishPdf.disabled = true;
      btnFinishPdf.textContent = t.statusBuildingPdf;
      await chrome.runtime.sendMessage({
        type: 'SCAN_FINISH_PDF',
        quality: pdfQualitySelect.value || 'high'
      });
    }
  });

  // Cancel Button
  btnCancel.addEventListener('click', async () => {
    const t = TRANSLATIONS[currentLang] || TRANSLATIONS.no;
    if (confirm(t.confirmCancel)) {
      await chrome.runtime.sendMessage({ type: 'CANCEL_SCAN' });
    }
  });

  // Initial Mode UI state
  updateModeUI();
  updateCalcHint();
});
