document.addEventListener('DOMContentLoaded', async () => {
  const pagesGrid = document.getElementById('pages-grid');
  const emptyState = document.getElementById('empty-state');
  const pageCountBadge = document.getElementById('page-count-badge');
  const btnGeneratePdf = document.getElementById('btn-generate-pdf');
  const btnGenerateText = document.getElementById('btn-generate-text');
  const btnCancel = document.getElementById('btn-cancel');
  const btnCopyText = document.getElementById('btn-copy-text');
  const btnDownloadTxt = document.getElementById('btn-download-txt');
  const reviewQualitySelect = document.getElementById('review-quality');
  const reviewCustomMaxMb = document.getElementById('review-custom-max-mb');
  const sizeGuidancePill = document.getElementById('size-guidance-pill');
  const btnOpenHelp = document.getElementById('btn-open-help');

  const langBtnNo = document.getElementById('lang-no');
  const langBtnEn = document.getElementById('lang-en');

  const lightboxModal = document.getElementById('lightbox-modal');
  const lightboxImg = document.getElementById('lightbox-img');
  const lightboxCaption = document.getElementById('lightbox-caption');
  const lightboxClose = document.getElementById('lightbox-close');

  const TRANSLATIONS = {
    no: {
      title: "ScanExtension Galleri",
      subtitle: "Forhåndsvis opptak og slett uønskede sider før PDF lagres",
      pagesLabel: "opptak",
      btnCancel: "Forkast alle",
      btnGenerate: "Generer & Last ned PDF",
      btnGenerateCount: "Generer PDF ({n} sider)",
      emptyTitle: "Ingen opptak tilgjengelig",
      emptyDesc: "Start et nytt skann i nettleseren for å fange sider.",
      cardCapture: "Opptak #{n}",
      btnDelete: "Slett",
      clickToZoom: "Klikk for å forstørre",
      btnCopyText: "Kopier tekst",
      textCopied: "Kopiert til utklippstavle!",
      confirmDeletePage: "Er du sikker på at du vil slette opptak #{n}?",
      confirmCancelAll: "Er du sikker på at du vil forkaste alle opptakene og avbryte?",
      generatingWait: "Bygger PDF, vennligst vent...",
      privacyLink: "Personvern",
      qualityHigh: "💎 Maks (300 DPI / PNG)",
      qualityCompact: "⚡ Balansert (150 DPI)",
      qualityEco: "🪶 Øko / Liten fil (100 DPI)",
      qualityUltra: "📦 Ekstrem (75 DPI / Minst)",
      groupMaxSize: "Begrens filstørrelse",
      maxSize10: "🎯 Maks 10 MB (E-post)",
      maxSize25: "🎯 Maks 25 MB (Skole/Teams)",
      maxSize50: "🎯 Maks 50 MB",
      maxSizeCustom: "✏️ Egendefinert maks MB...",
      sizeEstimate: "📊 Estimert: ~{size} MB",
      sizeFloorWarning: "💡 {pages} sider krever minst ~{min} MB for skarp tekst. Beskytter lesbarhet."
    },
    en: {
      title: "ScanExtension Gallery",
      subtitle: "Preview captures and remove unwanted pages before PDF is saved",
      pagesLabel: "captures",
      btnCancel: "Discard all",
      btnGenerate: "Generate & Download PDF",
      btnGenerateCount: "Generate PDF ({n} pages)",
      emptyTitle: "No captures available",
      emptyDesc: "Start a new scan from the browser extension to capture pages.",
      cardCapture: "Capture #{n}",
      btnDelete: "Delete",
      clickToZoom: "Click to zoom",
      btnCopyText: "Copy Text",
      textCopied: "Copied to clipboard!",
      confirmDeletePage: "Are you sure you want to delete capture #{n}?",
      confirmCancelAll: "Are you sure you want to discard all captures and cancel?",
      generatingWait: "Generating PDF, please wait...",
      privacyLink: "Privacy",
      qualityHigh: "💎 Max (300 DPI / PNG)",
      qualityCompact: "⚡ Balanced (150 DPI)",
      qualityEco: "🪶 Eco / Small File (100 DPI)",
      qualityUltra: "📦 Extreme (75 DPI / Smallest)",
      groupMaxSize: "Limit File Size",
      maxSize10: "🎯 Max 10 MB (Email)",
      maxSize25: "🎯 Max 25 MB (School/Teams)",
      maxSize50: "🎯 Max 50 MB",
      maxSizeCustom: "✏️ Custom max MB...",
      sizeEstimate: "📊 Estimated: ~{size} MB",
      sizeFloorWarning: "💡 {pages} pages require at least ~{min} MB for sharp text. Preserving clarity."
    }
  };

  let currentLang = 'no';
  let sessionPages = [];
  let pdfFilename = 'Bok_Skann';

  function applyLanguage(lang) {
    currentLang = lang;
    const t = TRANSLATIONS[lang] || TRANSLATIONS.no;

    if (lang === 'en') {
      langBtnEn.classList.add('active');
      langBtnNo.classList.remove('active');
    } else {
      langBtnNo.classList.add('active');
      langBtnEn.classList.remove('active');
    }

    document.querySelectorAll('[data-i18n]').forEach(el => {
      const key = el.getAttribute('data-i18n');
      if (t[key]) {
        el.textContent = t[key];
      }
    });

    document.querySelectorAll('[data-i18n-label]').forEach(el => {
      const key = el.getAttribute('data-i18n-label');
      if (t[key]) {
        el.label = t[key];
      }
    });

    renderGrid();
    updateSizeEstimate();
    chrome.storage.local.set({ uiLang: lang });
  }

  function updateCustomSizeVisibility() {
    if (!reviewQualitySelect || !reviewCustomMaxMb) return;
    if (reviewQualitySelect.value === 'max_custom') {
      reviewCustomMaxMb.classList.remove('hidden');
    } else {
      reviewCustomMaxMb.classList.add('hidden');
    }
  }

  function getQualityAndMaxMb() {
    const rawVal = reviewQualitySelect ? reviewQualitySelect.value : 'compact';
    let quality = 'compact';
    let maxMb = 0;

    if (rawVal === 'max_10') {
      quality = 'compact';
      maxMb = 10;
    } else if (rawVal === 'max_25') {
      quality = 'compact';
      maxMb = 25;
    } else if (rawVal === 'max_50') {
      quality = 'compact';
      maxMb = 50;
    } else if (rawVal === 'max_custom') {
      quality = 'compact';
      maxMb = parseInt(reviewCustomMaxMb?.value, 10) || 15;
    } else {
      quality = rawVal;
      maxMb = 0;
    }
    return { quality, maxMb, rawVal };
  }

  function updateSizeEstimate() {
    if (!sizeGuidancePill) return;
    const count = sessionPages.length;
    if (count === 0) {
      sizeGuidancePill.textContent = '';
      return;
    }

    const t = TRANSLATIONS[currentLang] || TRANSLATIONS.no;
    const { quality, maxMb } = getQualityAndMaxMb();

    let kbPerPage = 180;
    if (quality === 'high') kbPerPage = 1800;
    else if (quality === 'eco') kbPerPage = 110;
    else if (quality === 'ultra') kbPerPage = 75;

    const minSafeMb = ((count * 75) / 1024).toFixed(1);

    if (maxMb > 0) {
      if (maxMb < parseFloat(minSafeMb)) {
        sizeGuidancePill.innerHTML = `<span style="color: #f59e0b; padding: 2px 8px; background: rgba(245, 158, 11, 0.12); border-radius: 4px; border: 1px solid rgba(245, 158, 11, 0.25);" title="Kvalitetsgulvet beskytter lesbarheten">${t.sizeFloorWarning.replace('{pages}', count).replace('{min}', minSafeMb)}</span>`;
      } else {
        sizeGuidancePill.innerHTML = `<span style="color: #38bdf8; padding: 2px 8px; background: rgba(56, 189, 248, 0.12); border-radius: 4px; border: 1px solid rgba(56, 189, 248, 0.25);">🎯 Maks: ${maxMb} MB (~${Math.round((maxMb * 1024) / count)} KB/side)</span>`;
      }
    } else {
      const estimatedMb = ((count * kbPerPage) / 1024).toFixed(1);
      sizeGuidancePill.innerHTML = `<span style="color: #94a3b8; padding: 2px 8px; background: rgba(255, 255, 255, 0.05); border-radius: 4px;">${t.sizeEstimate.replace('{size}', estimatedMb)}</span>`;
    }
  }

  langBtnNo.addEventListener('click', () => applyLanguage('no'));
  langBtnEn.addEventListener('click', () => applyLanguage('en'));

  const storedData = await chrome.storage.local.get(['uiLang', 'pdfQuality', 'customMaxMb']);
  if (storedData && storedData.uiLang) {
    currentLang = storedData.uiLang;
  }
  if (storedData && storedData.pdfQuality) {
    reviewQualitySelect.value = storedData.pdfQuality;
  }
  if (storedData && storedData.customMaxMb && reviewCustomMaxMb) {
    reviewCustomMaxMb.value = storedData.customMaxMb;
  }
  updateCustomSizeVisibility();

  reviewQualitySelect.addEventListener('change', () => {
    updateCustomSizeVisibility();
    updateSizeEstimate();
    const { quality, maxMb, rawVal } = getQualityAndMaxMb();
    chrome.storage.local.set({ pdfQuality: rawVal });
    chrome.runtime.sendMessage({
      type: 'SET_PDF_QUALITY',
      quality: quality,
      maxMb: maxMb
    });
  });

  if (reviewCustomMaxMb) {
    reviewCustomMaxMb.addEventListener('input', () => {
      chrome.storage.local.set({ customMaxMb: reviewCustomMaxMb.value });
      updateSizeEstimate();
      const { quality, maxMb } = getQualityAndMaxMb();
      chrome.runtime.sendMessage({
        type: 'SET_PDF_QUALITY',
        quality: quality,
        maxMb: maxMb
      });
    });
  }

  btnOpenHelp.addEventListener('click', () => {
    chrome.tabs.create({ url: chrome.runtime.getURL('help/help.html') });
  });

  async function loadPages() {
    try {
      if (typeof ScanDB !== 'undefined') {
        sessionPages = await ScanDB.getAllPages();
      }
      if (!sessionPages || sessionPages.length === 0) {
        const res = await chrome.runtime.sendMessage({ type: 'GET_SESSION_PAGES' });
        if (res && res.pages) {
          sessionPages = res.pages;
          if (res.pdfFilename) pdfFilename = res.pdfFilename;
        }
      }
      applyLanguage(currentLang);
    } catch (e) {
      console.warn('Could not load session pages:', e);
    }
  }

  function renderGrid() {
    const t = TRANSLATIONS[currentLang] || TRANSLATIONS.no;
    pagesGrid.innerHTML = '';
    pageCountBadge.textContent = sessionPages.length;
    updateSizeEstimate();

    if (sessionPages.length === 0) {
      emptyState.classList.remove('hidden');
      btnGeneratePdf.disabled = true;
      btnCopyText.disabled = true;
      btnDownloadTxt.disabled = true;
      btnGenerateText.textContent = t.btnGenerate;
      return;
    }

    emptyState.classList.add('hidden');
    btnGeneratePdf.disabled = false;
    btnCopyText.disabled = false;
    btnDownloadTxt.disabled = false;
    btnGenerateText.textContent = t.btnGenerateCount.replace('{n}', sessionPages.length);

    sessionPages.forEach((page, index) => {
      const card = document.createElement('div');
      card.className = 'page-card';

      const cardTitle = t.cardCapture.replace('{n}', index + 1);

      card.innerHTML = `
        <div class="card-header">
          <span class="card-title">${cardTitle}</span>
        </div>
        <div class="card-img-wrapper" data-index="${index}">
          <img class="card-img" src="${page.image}" alt="Page ${index + 1}" loading="lazy">
          <div class="zoom-overlay">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <circle cx="11" cy="11" r="8"></circle>
              <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
              <line x1="11" y1="8" x2="11" y2="14"></line>
              <line x1="8" y1="11" x2="14" y2="11"></line>
            </svg>
            ${t.clickToZoom}
          </div>
        </div>
        <div class="card-footer">
          <span class="card-meta">${page.textNodes?.length || 0} tekstlinjer</span>
          <button class="btn-delete-card" data-index="${index}">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <polyline points="3 6 5 6 21 6"></polyline>
              <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
            </svg>
            ${t.btnDelete}
          </button>
        </div>
      `;

      // Zoom click handler
      card.querySelector('.card-img-wrapper').addEventListener('click', () => {
        lightboxImg.src = page.image;
        lightboxCaption.textContent = cardTitle;
        lightboxModal.classList.remove('hidden');
      });

      // Delete click handler
      card.querySelector('.btn-delete-card').addEventListener('click', async (e) => {
        e.stopPropagation();
        const idx = parseInt(e.currentTarget.getAttribute('data-index'), 10);
        if (confirm(t.confirmDeletePage.replace('{n}', idx + 1))) {
          await deletePage(idx);
        }
      });

      pagesGrid.appendChild(card);
    });
  }

  async function deletePage(index) {
    try {
      const page = sessionPages[index];
      const pageId = page ? page.id : null;
      if (typeof pageId === 'number' && typeof ScanDB !== 'undefined') {
        await ScanDB.deletePage(pageId);
      }
      await chrome.runtime.sendMessage({
        type: 'DELETE_PAGE_FROM_SESSION',
        id: pageId,
        index: index
      });
      sessionPages.splice(index, 1);
      renderGrid();
    } catch (e) {
      console.warn('Error deleting page:', e);
    }
  }

  // Lightbox Close Handlers
  lightboxClose.addEventListener('click', () => {
    lightboxModal.classList.add('hidden');
  });

  lightboxModal.addEventListener('click', (e) => {
    if (e.target === lightboxModal) {
      lightboxModal.classList.add('hidden');
    }
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && !lightboxModal.classList.contains('hidden')) {
      lightboxModal.classList.add('hidden');
    }
  });

  // Copy All Text Button
  btnCopyText.addEventListener('click', async () => {
    const t = TRANSLATIONS[currentLang] || TRANSLATIONS.no;
    try {
      const res = await chrome.runtime.sendMessage({ type: 'EXPORT_ALL_TEXT' });
      if (res && res.text) {
        await navigator.clipboard.writeText(res.text);
        const originalText = btnCopyText.querySelector('span').textContent;
        btnCopyText.querySelector('span').textContent = t.textCopied;
        setTimeout(() => {
          btnCopyText.querySelector('span').textContent = originalText;
        }, 2000);
      }
    } catch (err) {
      console.error('Failed to copy text:', err);
    }
  });

  // Download .TXT file Button
  btnDownloadTxt.addEventListener('click', async () => {
    try {
      const res = await chrome.runtime.sendMessage({ type: 'EXPORT_ALL_TEXT' });
      if (res && res.text) {
        const blob = new Blob([res.text], { type: 'text/plain;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        const cleanName = (pdfFilename || 'Bok_Skann').replace(/\.pdf$/i, '');
        a.download = `${cleanName}.txt`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      }
    } catch (err) {
      console.error('Failed to export TXT file:', err);
    }
  });

  // Generate PDF button
  btnGeneratePdf.addEventListener('click', async () => {
    const t = TRANSLATIONS[currentLang] || TRANSLATIONS.no;
    btnGeneratePdf.disabled = true;
    btnGenerateText.textContent = t.generatingWait;

    const { quality, maxMb } = getQualityAndMaxMb();
    await chrome.runtime.sendMessage({
      type: 'SCAN_FINISH_PDF',
      quality: quality,
      maxMb: maxMb
    });

    setTimeout(() => {
      window.close();
    }, 1500);
  });

  // Cancel button
  btnCancel.addEventListener('click', async () => {
    const t = TRANSLATIONS[currentLang] || TRANSLATIONS.no;
    if (confirm(t.confirmCancelAll)) {
      await chrome.runtime.sendMessage({ type: 'CANCEL_SCAN' });
      window.close();
    }
  });

  await loadPages();
});
